package com.pluribus.vcf.adminSettings;

import static com.pluribus.vcf.helper.AnalyticsConstants.ANALYTICS_REFRESH_BUTTON;
import static com.pluribus.vcf.helper.AnalyticsConstants.ANALYTICS_REFRESH_INTERVAL;
import static com.pluribus.vcf.helper.AnalyticsConstants.COMMON_IFRAME_TAG;
import static com.pluribus.vcf.helper.NavigationMenuConstants.MENU_SETTINGS;
import static com.pluribus.vcf.helper.PointFeatureConstants.ALERT_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.ERROR_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.PLURIBUS_WAIT_ICON;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.pagefactory.LicenseTypes;
import com.pluribus.vcf.pagefactory.ManageCollector;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;

public class ManageAuditLogs extends PageInfra {
	private String pncPwd = "test123";
	private String pncuName = "pn-vcf";
	private NavigationMenu menu;
	private ManageCollector manageCollector;
	private VcfSettingsPage vcfSetting;

	private static final Logger log = Logger.getLogger(ManageAuditLogs.class);

	public ManageAuditLogs(WebDriver driver) {
		super(driver);
		menu = new NavigationMenu(driver);
		vcfSetting = new VcfSettingsPage(driver);

	}

	@FindBy(how = How.CSS, using = "table.kbn-table.table")
	WebElement table;
	@FindBy(how = How.CSS, using = "ng-transclude")
	WebElement listLicense;

	String licenseName = "ng-transclude div.panel.panel-default";
	String licenseActivateButton = "button.btn.btn-xs.btn-primary";
	String searchBox = "//input[@placeholder='Filter by: License Key ...']";

	public boolean verifyAuditLogs(String collectorName) throws Exception {

		manageCollector = new ManageCollector(driver);

		try {
			log.info("Running stopCollector Test");
			// check Collector Management tab and current status of collector.
			if (menu.gotoMenu("Manage", "Fabric", "Manage Collector")) {
				manageCollector.waitForPageLoad();
				if (!manageCollector.stopCollector(collectorName)) {
					log.error("collector has not stopped");
				} else {
					log.info("collector has stopped");
				}
				if (!manageCollector.startCollector(collectorName)) {
					log.error("collector has not started");
				} else {
					log.info("collector has started");
				}
			} else {
				log.info("Collector not found");
			}
		} catch (Exception e) {
			log.error(e);
		}
		// Thread.sleep(60000);
		menu.gotoSettingsManageAuditLogs();
		frameToBeAvailable(By.xpath(COMMON_IFRAME_TAG));
		if (!verifyLogs("LOGIN")) {
			log.error("Login logs are not present");
			return false;
		}
		log.info("Login logs are present");
		if (!verifyLogs("LOGOUT")) {
			log.error("Logout logs are not present");
			return false;
		}
		log.info("Logout logs are present");

		if (!verifyLogs("LICENSE_INSTALL")) {
			log.error("License logs are not present");
			return false;
		}
		log.info("License logs are present");
		if (!verifyLogs("STOP_COLLECTOR")) {
			log.error("Stop Collector logs are not present");
			return false;
		}
		log.info("Stop Collector logs are present");
		if (!verifyLogs("START_COLLECTOR")) {
			log.error("Start Collector logs are not present");
			return false;
		}
		log.info("Start Collector logs are present");
		return true;

	}

	public boolean verifyLogs(String logs) throws InterruptedException {
		boolean status = true;
		String validationText = "//span[contains(text(),'" + logs + "')]";

		waitForElementVisibility(table);
		int limit = 0;
		while (limit <= 60) {
			if (isElementActive(By.xpath(validationText))) {
				return status;
			}
			Thread.sleep(1000);
			limit++;
		}
		return false;

	}
}
