package com.pluribus.vcf.adminSettings;

import static com.pluribus.vcf.helper.PointFeatureConstants.ALERT_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.DELETE_ICON;
import static com.pluribus.vcf.helper.PointFeatureConstants.FORM_SAVE_BUTTON;
import static com.pluribus.vcf.helper.PointFeatureConstants.PLURIBUS_WAIT_ICON;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;

public class ManageLdapUser extends PageInfra {
	private NavigationMenu menu;
	private TopologyPage topology;
	private VcfSettingsPage vcfsetting;
	private static final Logger log = Logger.getLogger(ManageLdapUser.class);

	public ManageLdapUser(WebDriver driver) {
		super(driver);
		menu = new NavigationMenu(driver);
		topology = new TopologyPage(driver);
		vcfsetting = new VcfSettingsPage(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(how = How.ID, using = "username")
	WebElement username;

	@FindBy(how = How.ID, using = "password")
	WebElement password;

	@FindBy(how = How.NAME, using = "ok")
	WebElement testButton;

	String TEST_BUTTON = "//button[contains(text(),'Test')]";
	String LDAP_FORM = "//div[@class='modal-content']";
	String LDAP_SETTING_ICON = "//span[@class='my-table-action fa fa-cog dropdown-toggle']";

	public boolean addLdapUser(String ldapUserName, String ldapUserPwd, String ldapGroup, String ldapServerIp)
			throws Exception {
		boolean status = false;
		String baseDn = "cn=" + ldapUserName + ",cn=" + ldapGroup + ",dc=unum,dc=com";
		vcfsetting.addAuthServer(ldapServerIp, baseDn, ldapUserPwd, "ldap");
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			status = true;
		}
		return status;

	}

	public boolean testLdapUser(String ldapUserName, String ldapUserPwd) {
		boolean status = false;
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}
		waitForElementToClick(By.xpath(TEST_BUTTON));
		clickOnWebElement(By.xpath(TEST_BUTTON));
		log.info("Test button is clicked");
		waitForVisibilityOfElementLocated(By.xpath(LDAP_FORM));
		setValue(username, ldapUserName);
		setValue(password, ldapUserPwd);
		testButton.click();
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			status = true;
		}
		return status;

	}

	public boolean deleteLdapUser() {
		boolean status = false;
		menu.gotoSettingsAuthServerMenu();
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}
		waitForElementToClick(By.xpath(LDAP_SETTING_ICON));
		retryingFindClick(By.xpath(LDAP_SETTING_ICON));
		retryingFindClick(By.xpath(DELETE_ICON));
		log.info("Clicked on delete icon");
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Confirm delete button");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			status = true;
		}
		return status;

	}
}
