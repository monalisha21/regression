package com.pluribus.vcf.adminSettings;

import static com.pluribus.vcf.helper.AnalyticsConstants.COMMON_IFRAME_TAG;
import static com.pluribus.vcf.helper.NavigationMenuConstants.MENU_SETTINGS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.jcraft.jsch.JSchException;
import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.helper.SshClient;
import com.pluribus.vcf.pagefactory.NavigationMenu;

public class ManageSystemHealth extends PageInfra {
	private NavigationMenu menu;
	SshClient sshHelper;

	private static final Logger log = Logger.getLogger(ManageSystemHealth.class);

	public ManageSystemHealth(WebDriver driver, String vcfIp, String vmUser, String vmPwd) throws Exception {
		super(driver);
		menu = new NavigationMenu(driver);
		sshHelper = new SshClient();
		try {
			sshHelper.establishConnection(vcfIp, vmUser, vmPwd);
		} catch (Exception e) {

			throw new Exception(e.getMessage());
		}
	}

	@FindBy(how = How.CSS, using = "table.table.monitoring-view-listing-table")
	WebElement table;

	String indicesTab = ".//a[contains(@href,'/elasticsearch/indices')]";
	String iFrame = "//iframe[contains(@src,'elasticsearch')]";
	String checkbox = "//input[@type='checkbox']";
	String uiStatus = "div.monitoring-summary-status__status-indicator";
	String tablerow = "//div[@class='paginated-table']//tbody/tr[@class='big']";
	String row = ".//tr";
	String header = ".//th";
	String cell = ".//td";

	public boolean verifySystemHealthIndicesData() {
		clickOnWebElement(By.xpath(indicesTab));
		waitForVisibilityOfElementLocated(By.xpath(checkbox));
		clickOnWebElement(By.xpath(checkbox));
		waitForElementVisibility(table);

		ArrayList<HashMap<String, WebElement>> tabledata = getTheTableData();
		if (!verifyNames("indices", "index", tabledata, "Name")) {
			log.error("Name of the indices does not matched");
			return false;
		}
		if (!verifyCountCol("indices", "pri", tabledata, "Unassigned Shards")) {
			log.error("Unassigned Shards count of the indices does not matched");
			return false;
		}
		if (!verifyCountCol("indices", "docs.count", tabledata, "Document Count")) {
			log.error("Document Count of the indices does not matched");
			return false;
		}
		if (!verifyNames("indices", "health", tabledata, "Status")) {
			log.error("Status of the indices does not matched");
		}
		return true;

	}

	public boolean verifySystemHealthNodeData() {
		driver.switchTo().parentFrame();
		waitForVisibilityOfElementLocated(By.cssSelector(MENU_SETTINGS));
		menu.gotoSettingsManageSystemHealth();
		frameToBeAvailable(By.xpath(iFrame));
		waitForElementVisibility(table);
		waitForVisibilityOfElementLocated(By.xpath(tablerow));
		ArrayList<HashMap<String, WebElement>> tabledata = getTheTableData();
		if (!verifyNames("nodes", "ip", tabledata, "Name")) {
			log.error("Name of the nodes does not matched");
			return false;
		}
		if (!verifyCountCol("health", "shards", tabledata, "Shards")) {
			log.error("Shards count of the nodes does not matched");
			return false;
		}
		if (!verifyNodeStatus(uiStatus, "health", "status")) {
			log.error("Status  of the nodes does not matched");
			return false;
		}

		return true;

	}

	public String[] getColData(ArrayList<HashMap<String, WebElement>> tabledata, String colname) {

		String[] listofnames = new String[(tabledata.size())];
		int j = 0;
		for (int i = 0; i < tabledata.size(); i++) {
			listofnames[j] = (tabledata.get(i).get(colname)).getText().replaceAll("\n.+$", "").trim();
			log.info("listofnames[j]" + listofnames[j]);

			j++;

		}
		return listofnames;

	}

	public String[] getCommandOutput(String api, String parameter) {

		String out = sshHelper
				.execCmd("docker exec -t vcf-elastic curl localhost:9200/_cat/" + api + "?h=" + parameter);
		log.info("output is " + out);
		String[] out1 = out.split("\n");
		// log.info("command out put "+ out1);
		int i = 0;
		for (String s : out1) {
			out1[i] = s.trim();
			i++;
		}
		return out1;

	}

	public boolean verifyNames(String api, String parameter, ArrayList<HashMap<String, WebElement>> tabledata,
			String colname) {
		String[] Uinameslist = getColData(tabledata, colname);
		String[] Clinameslist = getCommandOutput(api, parameter);
		int n = Clinameslist.length;
		if (n != Uinameslist.length) {
			log.info("length is not matching" + Clinameslist.length + "ui length" + Uinameslist.length);
			return false;
		} else
			Arrays.sort(Uinameslist);
		Arrays.sort(Clinameslist);

		if (colname == "Status") {
			for (int i = 0; i < n; i++) {
				Uinameslist[i] = Uinameslist[i].toLowerCase();
			}

		}
		/*
		 * if (!((Arrays.equals(Uinameslist, Clinameslist)))) {
		 * log.info("text is not matching"); return false; }
		 */
		for (int i = 0; i < n; i++) {
			if (!(Uinameslist[i].equals(Clinameslist[i]))) {
				log.error("text is not matching " + "Ui list name is " + Uinameslist[i] + "Cli list name is "
						+ Clinameslist[i]);
				return false;
			}
		}

		return true;

	}

	public boolean verifyCountCol(String api, String parameter, ArrayList<HashMap<String, WebElement>> tabledata,
			String colname) {
		String[] Uishardslist = getColData(tabledata, colname);
		String[] Clishardslist = getCommandOutput(api, parameter);
		float UitotalCount = getTotalCount(Uishardslist);
		log.info("ui count is " + UitotalCount);
		float ClitotalCount = getTotalCount(Clishardslist);
		log.info("cli count is " + ClitotalCount);
		float delta = (float) (ClitotalCount * 0.2);
		if (colname == "Document Count") {
			if (!((ClitotalCount - delta) < UitotalCount && UitotalCount < (ClitotalCount + delta))) {
				log.error("Count is not matched Ui count is " + UitotalCount + " Cli count is " + ClitotalCount);
				return false;
			}
		} else if (!(ClitotalCount == UitotalCount)) {
			log.error("Count is not matched Ui count is " + UitotalCount + " Cli count is " + ClitotalCount);
			return false;
		}
		return true;

	}

	public float getTotalCount(String[] list) {
		float count = 0;
		for (int i = 0; i < list.length; i++) {
			if (list[i].contains("k")) {
				list[i] = list[i].replaceAll(".$", "");
				count = count + ((Float.parseFloat(list[i])) * 1000);
				// log.info("count is" + count);
			} else {
				count = count + Float.parseFloat(list[i]);
				// log.info("Total count is " + count);
			}
		}
		return count;

	}

	public String getNodeHeadPannelValues(String value) {
		String str = driver.findElement(By.cssSelector(value)).getText().trim().toLowerCase();
		return str;

	}

	public boolean verifyNodeStatus(String value, String api, String parameter) {
		String Uivalue = getNodeHeadPannelValues(value);
		String[] Clivalue = getCommandOutput(api, parameter);
		if (!Uivalue.contains("red")) {
			log.info(" The Status of the nodes is " + Uivalue);

			if (!Uivalue.contains(Clivalue[0])) {
				return false;
			}
			return true;
		}
		log.error("Nodes status is red");
		return false;

	}

	public ArrayList<HashMap<String, WebElement>> getTheTableData() {
		// simplified: find table which contains the keyword
		WebElement tableElement = driver.findElement(By.xpath("//table[@class='table monitoring-view-listing-table']"));

		ArrayList<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
		List<WebElement> tbody = tableElement.findElements(By.xpath(row));

		// get column names of table from table headers
		ArrayList<String> columnNames = new ArrayList<String>();
		List<WebElement> headerElements = tbody.get(0).findElements(By.xpath(header));
		for (WebElement headerElement : headerElements) {
			columnNames.add(headerElement.getText());
		}
		List<WebElement> rowElements = driver.findElements(By.xpath(tablerow));
		// iterate through all rows and add their content to table array
		for (WebElement rowElement : rowElements) {
			HashMap<String, WebElement> row = new HashMap<String, WebElement>();

			// add table cells to current row
			int columnIndex = 0;

			List<WebElement> cellElements = rowElement.findElements(By.xpath(cell));
			// retryingFindlistofElement(10,rowElement);

			for (WebElement cellElement : cellElements) {
				row.put(columnNames.get(columnIndex), cellElement);

				columnIndex++;
			}

			userTable.add(row);

		}

		// finally fetch the desired data

		return userTable;
	}

}