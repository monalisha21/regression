package com.pluribus.vcf.adminSettings;

import static net.sf.expectit.matcher.Matchers.contains;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.JSchException;
import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.helper.SshClient;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import static com.pluribus.vcf.adminSettings.UNUMSetUP.*;
import net.sf.expectit.Expect;

public class ManageUnumSetUp extends PageInfra {
	SshClient sshHelper;
	private NavigationMenu menu;
	private ManageUser user;
	private String vmUser = "vcf";
	private String vmPwd = "changeme";
	private String userName = "Test";
	private String pwd = "test";
	private String rol = "User";
	private VCFLoginPage login;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private final Object upgradeFile;
	private final Object upgradeLink;
	private final Object ip;
	private final Object input;
	private static int SESSION_TIMEOUT = 300;
	HashMap<String, Method> map = new HashMap<String, Method>();
	// Thread t_verify = new Thread(new ManageUnumSetUp(driver, input, input, input,
	// input));
	private Thread t_verify;
	private static final Logger log = Logger.getLogger(ManageUnumSetUp.class);

	public ManageUnumSetUp(WebDriver driver, Object vcfIp, Object imageNameUpgrade, Object imageUrl, Object configFile)
			throws Exception {

		super(driver);
		upgradeFile = imageNameUpgrade;
		upgradeLink = imageUrl;
		ip = vcfIp;
		input = configFile;
		sshHelper = new SshClient();
		menu = new NavigationMenu(driver);
		user = new ManageUser(driver);
		login = new VCFLoginPage(driver);

		t_verify = new Thread() {

			@Override
			public void run() {
				while (!t_verify.isInterrupted()) {
					try {
						Thread.sleep(SESSION_TIMEOUT);
					} catch (InterruptedException e) {
						t_verify.interrupt();
						break;
					}

					driver.getCurrentUrl();

				}
			}
		};
		t_verify.start();
		configureMap();
	}

	@FindBy(how = How.XPATH, using = "//button[contains(text(),'PN Cloud')]")
	WebElement pncCloudbutton;
	@FindBy(how = How.CSS, using = "button.btn.btn-warning.cancel")
	WebElement cancelButton;
	@FindBy(how = How.XPATH, using = "//div[@class='page-content']/table")
	WebElement table;

	public void configureMap() throws NoSuchMethodException, SecurityException {
		map.put(versionCheck, getMethod("versionAndMachineIdcheck"));
		map.put(statusCheck, getMethod("statusCheck"));
		map.put(stopUnum, getMethod("stopUnumCheck"));
		map.put(startUnum, getMethod("startUnumCheck"));
		map.put(techSup, getMethod("techSupportTarCheck"));
		map.put(configHostIp, getMethod("hostConfigCheck"));
		map.put("restHostIp", getMethod("hostConfigResetCheck"));
		map.put("configVcfNetIp:configDockerIp", getMethod("dockerConfigCheck"));
		map.put("configVcfNetIp:configVcfNetIp", getMethod("vcfNetConfigCheck"));
		map.put("configDateTime:ntpstatusCheck", getMethod("ntpStatusCheck"));
		map.put(debugEnable, getMethod("enableDebugModeCheck"));
		map.put(debugDisable, getMethod("disableDebugModeCheck"));
		map.put("advancedSetting:backupConfig", getMethod("backupUnumCheck"));
		map.put("advancedSetting:restoreConfig", getMethod("restoreBackupCheck"));
		map.put("advancedSetting:deleteConfig", getMethod("deleteBackupCheck"));
		map.put(updateUnum, getMethod("updateUnumCheck"));

	}

	private Method getMethod(String methodName) throws NoSuchMethodException, SecurityException {
		return ManageUnumSetUp.class.getMethod(methodName);
	}

	public boolean verifyUNUMSetUpOption(String option) throws Exception {

		if (map.containsKey(option)) {
			sshHelper.establishConnection((String) ip, vmUser, vmPwd);
			try {
				boolean status = (boolean) map.get(option).invoke(this);
				return status;
			} catch (InvocationTargetException e) {
				e.getCause().printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			sshHelper.closeSession();

		}
		return false;

	}

	public boolean versionAndMachineIdcheck() throws IOException, JSchException, InterruptedException, Exception {

		boolean status = true;
		if (!verifyCliAgainstUI()) {
			status = false;
		}
		return status;

	}

	public boolean statusCheck() throws IOException, JSchException, InterruptedException {

		boolean status = true;
		if (!verifyOptionOutput(statusCheck, "null", "Press any key to continue", "Success: ALL PASS")) {
			status = false;
		}
		return status;

	}

	public boolean stopUnumCheck() throws IOException, JSchException, InterruptedException {
		if (!verifyOptionOutput(stopUnum, "null", "Press any key to continue",
				"Services have been successfully stopped")) {
			log.error("UNUM has not stopped sucessfully");

			return false;
		}
		log.info("UNUM has stopped sucessfully");
		if (!cliValidation(stopUnum, "docker ps --format '{{.Names}}')")) {
			log.error("After Unum Stopped container are still running");

			return false;
		}
		log.info("After Unum Stopped container are stopped");
		if (!guiValidation("ERROR")) {
			log.info("GUI validation failed");
			return false;
		}
		log.info("GUI validation sucessed. UNUM is not running now.");
		return true;

	}

	public boolean startUnumCheck() throws IOException, JSchException, InterruptedException {
		if (!verifyOptionOutput(startUnum, "null", "Press any key to continue",
				"Services have been successfully started")) {

			log.error("UNUM has not started sucessfully");

			return false;
		}
		log.info("Unum has started sucessfully");
		if (!cliValidation(startUnum, "docker ps")) {
			log.error("After Unum started container are still stooped");

			return false;
		}
		log.info("After Unum started container are started");
		if (!guiValidation("SUCESS")) {
			log.info("GUI validation failed");
			return false;
		}
		log.info("GUI validation sucessed. UNUM is  running now.");
		return true;

	}

	public boolean techSupportTarCheck() throws IOException, JSchException, InterruptedException {
		boolean status = true;
		if (!verifyTechSupportTarFile(techSup, "null", "Press any key to continue", "ls -1 -t /tmp | grep tar.gz",
				fileName, directoryName)) {
			status = false;
		}
		return status;

	}

	public boolean hostConfigCheck() throws Exception {
		boolean status = true;
		if (!verifyHostConfig(configHostIp, configHostIp, "Press any key to continue", (String) input, "ifconfig eth2",
				"saved successfully")) {
			status = false;
		}
		return status;

	}

	public boolean hostConfigResetCheck() throws Exception {
		boolean status = true;
		if (!verifyHostResetValueCheck(configHostIp, configHostIp, "Press any key to continue", (String) input,
				"saved successfully")) {
			status = false;
		}
		return status;

	}

	public boolean dockerConfigCheck() throws Exception {
		boolean status = true;
		if (!verifyHostConfig(configHostIp, configDockerIp, "Press any key to continue", (String) input,
				"ifconfig docker0", "successfully started.")) {
			status = false;
		}
		return status;

	}

	public boolean vcfNetConfigCheck() throws Exception {
		boolean status = true;
		if (!verifyHostConfig(configHostIp, configVcfNetIp, "Press any key to continue", (String) input,
				"docker network inspect vcfnet", "successfully started.")) {
			status = false;
		}
		return status;

	}

	public boolean enableDebugModeCheck() throws Exception {
		boolean status = true;
		if (!verifyEnableDisableDebugMode(advancedSetting, enableDisable, "successfully started.", "Enable",
				"cd var/vcf/logs;cat vcf-center.log | awk '{{print $4}}' | grep DEBUG | wc -l")) {
			status = false;
		}
		return status;

	}

	public boolean disableDebugModeCheck() throws Exception {
		boolean status = true;
		if (!verifyEnableDisableDebugMode(advancedSetting, enableDisable, "successfully started.", "Disable",
				"cd var/vcf/logs;cat vcf-center.log | awk '{{print $4}}' | grep DEBUG | wc -l")) {
			status = false;
		}
		return status;

	}

	public boolean ntpStatusCheck() throws IOException, JSchException, InterruptedException {
		boolean status = true;
		if (!verifyOptionOutput(configDateTime, ntpstatusCheck, "Press any key to continue", "ALL PASS")) {
			status = false;
		}
		return status;

	}

	public boolean updateUnumCheck() throws Exception {
		boolean status = true;
		if (!verifyUnumUpdate(updateUnum, upgradeFile, upgradeLink, "cd ;cd /srv/docker/offline_images;ls")) {
			status = false;
		}
		return status;

	}

	public boolean backupUnumCheck() throws Exception {
		boolean status = true;
		if (!verifyBackupConfig(advancedSetting, backupConfig, "Press any key to continue", "cd var/vcf/backup && ls",
				"created successfully")) {
			status = false;
		}
		return status;
	}

	public boolean restoreBackupCheck() throws Exception {
		boolean status = true;
		if (!verifyRestoreConfig(advancedSetting, restoreConfig, "Press any key to continue", "cd var/vcf/backup && ls",
				"successfully started.")) {
			status = false;
		}
		return status;

	}

	public boolean deleteBackupCheck() throws Exception {
		boolean status = true;
		if (!verifyDeleteConfig(advancedSetting, deleteConfig, "Press any key to continue",
				"cd ;cd var/vcf/backup && ls", "deleted successfully.")) {
			status = false;
		}
		return status;
	}

	public boolean guiValidation(String expected) {
		String actualOp = sshHelper
				.execCmd("curl https://" + ip + " -k -s -f -o /dev/null && echo SUCESS || echo ERROR");
		if (!actualOp.contains(expected)) {
			return false;
		}
		return true;

	}

	public String executeUnumSetUpOption(String option, String secoption, String match)
			throws IOException, JSchException, InterruptedException {
		if (secoption.equals(backupConfig)) {
			sshHelper.execCmd("sudo rm -rf /home/vcf/var/vcf/backup/*BACKUP*");
		}

		Expect expect = sshHelper.expect();
		try {
			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			if (option != "null") {
				expect.expect(contains("(0-9):"));
				sshHelper.exeShelCmd(expect, option);
				if (secoption != "null") {
					sshHelper.exeShelCmd(expect, secoption);
				}
				if (option.equals(techSup)) {
					sshHelper.exeShelCmd(expect, "y", "ENTER");
				}
				Thread.sleep(60000);
			}
			String actualOp = expect.expect(contains(match)).getBefore().trim();
			log.info(actualOp);
			return actualOp;
		} finally {
			expect.close();
		}
	}

	public boolean verifyCliAgainstUI() throws IOException, JSchException, InterruptedException {
		boolean status = true;
		String uiVersionNo = uiVersionAndBuildNo();
		String uiMachineId = uiMachineId();
		String cliValue = executeUnumSetUpOption("null", "null", "(0-9):");
		if (!cliValue.contains(uiVersionNo)) {
			log.error("buildNo and version is not matched and the no is" + uiVersionNo);
			status = false;
		}
		if (!cliValue.contains(uiMachineId)) {
			log.error("MachineId is not matched and the no is" + uiMachineId);
			status = false;
		}
		return status;

	}

	public boolean verifyOptionOutput(String option, String secOption, String match, String Value)
			throws IOException, JSchException, InterruptedException {
		String actualValue = executeUnumSetUpOption(option, secOption, match);
		if (actualValue.contains(Value)) {
			return true;
		}
		return false;

	}

	public String cliOutput(String cmd, String option) {
		String cmdOp = sshHelper.execCmd(cmd);
		if (option.equals(techSup) || option.equals(advancedSetting)) {
			String[] out = cmdOp.split("\n");
			return out[0];
		}
		return cmdOp;

	}

	public boolean cliValidation(String option, String cmd) throws IOException, JSchException, InterruptedException {
		boolean status = true;
		String actOp = cliOutput(cmd, option);
		if (option.equals(stopUnum)) {
			if (actOp.length() != 0) {
				status = false;
			}
		} else if (option.equals(startUnum)) {
			if (actOp.length() == 0) {
				status = false;
			}

		}
		return status;
	}

	public boolean verifyTechSupportTarFile(String option, String secOption, String match, String cmd,
			String[] fileName, String[] directoryName) throws IOException, JSchException, InterruptedException {
		String expOp = executeUnumSetUpOption(option, "null", match);
		String cliOp = cliOutput(cmd, option);
		if (!expOp.contains(cliOp)) {
			log.error("Unum techh support check failed and tgz file not created");
			return false;
		}
		String out1 = sshHelper.execCmd("tar -tvf " + "/tmp/" + cliOp);

		for (int i = 0; i < fileName.length; i++) {
			if (!out1.contains(fileName[i])) {
				log.error("This file is not present " + fileName[i]);
				return false;
			}
		}
		String out2 = sshHelper.execCmd("tar -tvf " + "/tmp/" + cliOp + " | grep " + " dr");
		for (int i = 0; i < directoryName.length; i++) {
			if (!out2.contains(directoryName[i])) {
				log.error("This directory is not present " + directoryName[i]);
				return false;
			}
		}
		return true;
	}

	public String uiVersionAndBuildNo() {
		menu.gotoSettingsMenu();
		String version = (driver.findElement(By.xpath(verNo)).getText().trim()).replaceAll("\\s", "");
		menu.gotoMenu("Overview", "Overview", "Topology");
		return version;

	}

	public String uiMachineId() {
		menu.gotoSettingsLicenseMenu();
		pncCloudbutton.click();
		String machineid = (driver.findElement(By.xpath(machinId)).getText().trim()).replaceAll("\\s", "");
		cancelButton.click();
		login.logout();
		return machineid;

	}

	public String executeHostConfig(String option, String secoption, String match, String configFile) throws Exception {
		String[] inputValues = readTextFile(configFile);
		Expect expect = sshHelper.expect();
		try {
			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			if (secoption.equals(configHostIp)) {
				expect.expect(contains("(0-9):"));
				sshHelper.exeShelCmd(expect, startUnum);
				Thread.sleep(30000);
				sshHelper.exeShelCmd(expect, "", "ENTER");
				sshHelper.exeShelCmd(expect, option);
				expect.expect(contains("(0-1):"));
				sshHelper.exeShelCmd(expect, secoption);
				if ((expect.expect(contains(match)).getBefore()).length() != 0) {
					log.info("Unum is running now.Can not set the ip.First need to stop the Unum.");
					sshHelper.exeShelCmd(expect, "", "ENTER");
					expect.expect(contains("(0-1):"));
					sshHelper.exeShelCmd(expect, exit);
					expect.expect(contains("(0-9):"));
					sshHelper.exeShelCmd(expect, stopUnum);
					Thread.sleep(60000);
					sshHelper.exeShelCmd(expect, "", "ENTER");
					sshHelper.exeShelCmd(expect, option);
					expect.expect(contains("(0-1):"));
					sshHelper.exeShelCmd(expect, option);
				}
				sshHelper.exeShelCmd(expect, "Y", "ENTER");
				log.info(expect.expect(contains("Enter interface")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[0], "ENTER");
				log.info(expect.expect(contains("Enter ip address")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[1], "ENTER");
				log.info(expect.expect(contains("Enter network mask")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[2], "ENTER");
				log.info(expect.expect(contains("Enter gateway")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[3], "ENTER");
				log.info(expect.expect(contains("Enter domain search list")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[4], "ENTER");
				log.info(expect.expect(contains("Enter DNS name servers")).getBefore().trim());
				sshHelper.exeShelCmd(expect, inputValues[5], "ENTER");
			} else {
				expect.expect(contains("(0-9):"));
				sshHelper.exeShelCmd(expect, option);
				expect.expect(contains("(0-1):"));
				sshHelper.exeShelCmd(expect, secoption);
				if (secoption.equals(configDockerIp)) {
					log.info(expect.expect(contains("Enter desired docker0 IP/mask")).getBefore().trim());
					sshHelper.exeShelCmd(expect, inputValues[6], "ENTER");
					Thread.sleep(2 * 60000);
				} else {
					log.info(expect.expect(contains("Enter desired vcfnet subnet/mask")).getBefore().trim());
					sshHelper.exeShelCmd(expect, inputValues[7], "ENTER");
					Thread.sleep(2 * 60000);
				}

			}
			String actualOp = expect.expect(contains(match)).getBefore().trim();
			log.info(actualOp);
			return actualOp;
		} finally {
			expect.close();
		}

	}

	public boolean verifyHostConfig(String option, String secoption, String match, String configFile, String cmd,
			String value) throws Exception {
		String actOp = executeHostConfig(option, secoption, match, configFile);
		String dockerip = null;
		String vcfNetIp = null;
		if (actOp.contains(value)) {
			log.info("Ip configure sucessfully");
			String out = cliOutput(cmd, option);
			String[] inputValues = readTextFile(configFile);
			if (!secoption.equals(configHostIp)) {
				dockerip = inputValues[6].split("/")[0];
				vcfNetIp = inputValues[7].split("/")[0];
			}
			if (out.contains(inputValues[1]) || out.contains(dockerip) || out.contains(vcfNetIp)) {
				return true;
			}

			log.error("ip does not match with the setted ip");
		}
		log.error("Ip has not setted up");
		return false;

	}

	public boolean verifyHostResetValueCheck(String option, String secoption, String match, String configFile,
			String value) throws Exception {
		String actOp = executeHostConfig(option, secoption, match, configFile);
		if (actOp.contains(value)) {
			log.info("Ip configure sucessfully");
			return true;
		}
		return false;
	}

	public boolean verifyBackupConfig(String option, String secOption, String match, String cmd, String value)
			throws Exception {
		String optionOp = executeUnumSetUpOption(option, secOption, match);
		String out = cliOutput(cmd, option);
		boolean status = true;
		if (optionOp.contains(value)) {
			log.info("Backup has been taken sucessfully");
			if (!optionOp.contains(out)) {
				status = false;
			}
		}
		return status;

	}

	public String restoreAndDeleteBackup(String option, String secOption, String match, String cmd) throws Exception {
		String out = cliOutput(cmd, option);
		if (secOption.equals(restoreConfig)) {
			login.login(vcfUserName, vcfPassword);
			user.addUser(userName, pwd, rol);
			login.logout();
		}
		Expect expect = sshHelper.expect();
		try {

			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			expect.expect(contains("(0-9:)"));
			sshHelper.exeShelCmd(expect, option);
			expect.expect(contains("(0-4:)"));
			sshHelper.exeShelCmd(expect, secOption);
			expect.expect(contains("Enter the backup to restore from []:"));
			sshHelper.exeShelCmd(expect, out, "ENTER");
			expect.expect(contains("Continue?"));
			sshHelper.exeShelCmd(expect, "Y", "ENTER");
			Thread.sleep(2 * 60000);
			String actualOp = expect.expect(contains(match)).getBefore().trim();
			log.info(actualOp);
			return actualOp;
		} finally {
			expect.close();
		}
	}

	public boolean verifyRestoreConfig(String option, String secOption, String match, String cmd, String value)
			throws Exception {
		String actualOp = restoreAndDeleteBackup(option, secOption, match, cmd);
		if (actualOp.contains(value)) {
			login.login(vcfUserName, vcfPassword);
			Thread.sleep(60000);
			if (isElementActive(By.xpath("//div[@class='parent-container']"))) {
				menu.gotoSettingsManageUsersMenu();
			}
			waitForElementVisibility(table);
			if (!isElementActive(By.xpath(addedUser))) {
				return true;
			}
		}
		Thread.currentThread().notify();
		return false;

	}

	public boolean verifyDeleteConfig(String option, String secOption, String match, String cmd, String value)
			throws Exception {
		String actualOp = restoreAndDeleteBackup(option, secOption, match, cmd);
		if (actualOp.contains(value)) {
			return true;
		}
		return false;

	}

	public String enableDisableDebugMode(String option, String secOption, String match)
			throws IOException, JSchException, InterruptedException {

		sshHelper.execCmd("cd var/vcf/logs && truncate -s 0 vcf-center.log");
		Expect expect = sshHelper.expect();
		try {

			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			expect.expect(contains("(0-9:)"));
			sshHelper.exeShelCmd(expect, stopUnum);
			Thread.sleep(60000);
			sshHelper.exeShelCmd(expect, "", "ENTER");
			sshHelper.exeShelCmd(expect, exit);
			sshHelper.exeShelCmd(expect, "cd var/vcf/logs && truncate -s 0 vcf-center.log", "ENTER");
			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			expect.expect(contains("(0-9:)"));
			sshHelper.exeShelCmd(expect, option);
			expect.expect(contains("(0-4:)"));
			sshHelper.exeShelCmd(expect, secOption);
			expect.expect(contains("([Y]es or [N]o)"));
			sshHelper.exeShelCmd(expect, "y", "ENTER");
			expect.expect(contains("Press any key to continue"));
			sshHelper.exeShelCmd(expect, "", "ENTER");
			expect.expect(contains("(0-4:)"));
			sshHelper.exeShelCmd(expect, exit);
			sshHelper.exeShelCmd(expect, startUnum);
			Thread.sleep(2 * 60000);
			sshHelper.exeShelCmd(expect, "", "ENTER");
			String actualOp = expect.expect(contains(match)).getBefore().trim();
			log.info(actualOp);
			return actualOp;
		} finally {
			expect.close();

		}

	}

	public boolean verifyEnableDisableDebugMode(String option, String secOption, String match, String action,
			String cmd) throws Exception {
		boolean status = true;
		enableDisableDebugMode(option, secOption, match);
		int count = Integer.parseInt(cliOutput(cmd, option).trim());
		log.info("No of Times DEBUG present is " + count);
		if (action.equals("Enable")) {
			if (count == 0) {
				status = false;
			}
		} else {
			if (count != 0) {
				status = false;
			}
			return status;
		}
		return status;

	}

	public String executeUpdateUNUM(Object upgradeFile, Object upgradeLink, String option, String cmd)
			throws Exception {

		String imageFile = downloadImageFile(upgradeFile, upgradeLink, cmd);
		Expect expect = sshHelper.expect();
		try {

			expect.expect(contains("$"));

			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			expect.expect(contains("(0-9:)"));
			sshHelper.exeShelCmd(expect, option);
			expect.expect(contains("([Y]es or [N]o)"));
			sshHelper.exeShelCmd(expect, "y", "ENTER");
			expect.expect(contains("Please input the image file name"));
			sshHelper.exeShelCmd(expect, imageFile, "ENTER");
			Thread.sleep(9 * 60000);
			expect.expect(contains("Press any key to continue"));
			sshHelper.exeShelCmd(expect, "", "ENTER");
			sshHelper.exeShelCmd(expect, exit);
			expect.expect(contains("$"));
			sshHelper.exeShelCmd(expect, setUP, "ENTER");
			String actualOp = expect.expect(contains("(0-9):")).getBefore().trim();
			log.info(actualOp);
			return actualOp;
		} finally {
			expect.close();

		}

	}

	public String downloadImageFile(Object upgradeFile, Object upgradeLink, String cmd) throws Exception {
		String wgetOutput = sshHelper
				.execCmd("rm -rf /srv/docker/offline_images/*;cd /srv/docker/offline_images;wget " + upgradeLink);
		Thread.sleep(30000);
		String imageName = sshHelper.execCmd(cmd);
		if (imageName.contains((CharSequence) upgradeFile)) {
			log.info("Image file is downloaded sucessfully");
			return (String) upgradeFile;
		} else {
			log.error("Image File download is failed");
			throw new Exception("Image File download is failed");
		}

	}

	public boolean verifyUnumUpdate(String option, Object upgradeFile, Object upgradeLink, String cmd)
			throws Exception {
		boolean status = true;
		String actualOp = executeUpdateUNUM(upgradeFile, upgradeLink, option, cmd);
		String version = (((String) upgradeFile).replace(".tgz", "")).replace("unum-", "");
		if (actualOp.contains(version)) {
			return status;
		}
		status = false;
		return status;

	}

	public void stopThread() {
		log.info("Stop the thread");
		t_verify.interrupt();
	}
}