package com.pluribus.vcf.adminSettings;

import static com.pluribus.vcf.helper.PointFeatureConstants.*;
import static com.pluribus.vcf.helper.CollectorConstants.COLLECTOR_MGMT_ADD_COLLECTOR_BTN;
import static com.pluribus.vcf.helper.FabricConstants.ADD_FABRIC;
import static com.pluribus.vcf.helper.NavigationMenuConstants.MENU_SETTINGS;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.PointFeatures;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;

public class ManageUser extends PageInfra {
	private NavigationMenu menu;
	private TopologyPage topology;
	private static final Logger log = Logger.getLogger(ManageUser.class);

	public ManageUser(WebDriver driver) {
		super(driver);
		menu = new NavigationMenu(driver);
		topology = new TopologyPage(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(how = How.CSS, using = "button.btn.btn-custom.btn-primary")
	WebElement addUserButton;

	@FindBy(how = How.CSS, using = "div.modal-content")
	WebElement addUserForm;

	@FindBy(how = How.ID, using = "username")
	WebElement username;

	@FindBy(how = How.ID, using = "password")
	WebElement password;

	@FindBy(how = How.CSS, using = "role")
	WebElement role;

	@FindBy(how = How.NAME, using = "ok")
	WebElement createButton;

	@FindBy(how = How.XPATH, using = "//div[@class='page-content']/table")
	WebElement table;

	String addFabricButton = "a[ng-click='$ctrl.addFabric()']";
	String collectorSettingIcon = "//preceding-sibling::span/span[@class='my-table-action fa fa-cog dropdown-toggle']";
	String createVlanButton = "//button[contains(.,'Delete VLANs by range')]";
	String deleteVlanButton = "//button[contains(.,'Create VLANs by range')]";
	String settings = "//span/preceding-sibling::span[@class='action-dropdown dropdown']/span";
	String deleteButton = "//span[@class='icon-img-link fa fa-trash-o']";
	String addedUser = "//div[@class='page-content']/table/tbody/tr[2]";

	public boolean addUser(String usrname, String pwd, String rol) {
		menu.gotoSettingsManageUsersMenu();
		addUserButton.click();
		waitForElementVisibility(addUserForm);
		setValue(username, usrname);
		setValue(password, pwd);
		selectDropDownValue(By.cssSelector(DROPDOWN_ARROW_ADMIN), By.cssSelector(DROPDOWN_LIST),
				DROPDOWN_MENU_ITEM_ADMIN, rol);
		retryingFindClick(createButton);
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		}
		waitForElementVisibility(table);
		if (isElementActive(By.xpath(addedUser))) {
			return true;
		}

		return false;
	}

	public boolean verifyUserRole(String fabricName, String switchName) {
		boolean status = true;
		if (isElementActive(By.cssSelector(ADD_FABRIC))) {
			status = false;
		}
		if (!verifyPointFeaturesButton(fabricName, switchName)) {
			log.error("PointFeature Button Validation Failed.");
			status = false;
		}

		return status;

	}

	public boolean verifyCollectorButton() {
		boolean status = true;
		menu.gotoMenu("Manage", "Fabric", "Manage Collector");
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		if (isElementActive(By.xpath(COLLECTOR_MGMT_ADD_COLLECTOR_BTN))) {
			status = false;
		}
		if (isElementActive(By.xpath(collectorSettingIcon))) {
			status = false;
		}
		menu.gotoMenu("Overview", "Overview", "Topology");
		return status;
	}

	public boolean verifyPointFeaturesButton(String fabricName, String switchName) {
		boolean status = true;
		topology.selectSwitchInMenu(switchName, fabricName);
		menu.gotoMenu("Manage", "Layer 2", "Manage VLAN");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));

		if (isElementActive(By.xpath(createVlanButton))) {
			log.error("Create VLAN button is active");
			status = false;
		}
		if (isElementActive(By.xpath(deleteVlanButton))) {
			log.error("Delete VLAN button is active");
			status = false;
		}
		if (isElementActive(By.xpath(settings))) {
			log.error("Settings VLAN button is active");
			status = false;
		}
		menu.gotoMenu("Overview", "Overview", "Topology");
		return status;
	}

	public boolean deleteUser() throws InterruptedException {
		boolean status = true;
		// Thread.sleep(2000);
		waitForVisibilityOfElementLocated(By.cssSelector(MENU_SETTINGS));
		menu.gotoSettingsManageUsersMenu();
		retryingFindClick(By.xpath(deleteButton));
		log.info("Delete button clicked");
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		}
		waitForElementVisibility(table);
		if (isElementActive(By.xpath(addedUser))) {
			status = false;
		}
		return status;

	}
}
