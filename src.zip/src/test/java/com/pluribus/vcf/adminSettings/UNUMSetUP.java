package com.pluribus.vcf.adminSettings;

public interface UNUMSetUP {
	String setUP = "sudo /home/vcf/UNUM_setup.sh";
	String exit = "0";
	String versionCheck = "null";
	String configHostIp = "1";
	String configDateTime = "2";
	String startUnum = "3";
	String stopUnum = "4";
	String updateUnum = "5";
	String techSup = "6";
	String statusCheck = "7";
	String advancedSetting = "8";
	String debugDisable = "8:4D";
	String debugEnable = "8:4E";
	String ntpstatusCheck = "3";
	String backupConfig = "1";
	String restoreConfig = "2";
	String deleteConfig = "3";
	String enableDisable = "4";
	String configDockerIp="2";
	String configVcfNetIp="3";
	String addedUser = "//div[@class='page-content']/table/tbody/tr[2]";
	String machinId = "//div[@class='col-sm-8']";
	String verNo = "//div[@class='help-block']/div[1]";
	String[] fileName = { "etc/ntp.conf", "etc/network/interfaces", "tmp/sys-stats", "tmp/es-info", "tmp/disk-usage",
			"tmp/postgres-dump" };
	String[] directoryName = { "home/vcf/var/vcf/skedler/logs/", "home/vcf/var/vcf/logs/", "home/vcf/srv/maestro/",
			"home/vcf/srv/vcf/config/" };

	public boolean executeUNUMOption() throws Exception;
	// public boolean executeUNUMOption(String input);

}