package com.pluribus.vcf.helper;

public interface AnalyticsConstants {
	String SEARCH_BUTTON = "input[placeholder='Search...']";
	String KIBANA_APPLIED_FILTER_LIST = "div.filter-actions";
	String KIBANA_FILTER_ACTION_TEXT = "Actions";
	String KIBANA_REMOVE_FILTER_TEXT = "Remove";
	String FILTER_ACTION_LIST_HIDDEN = "div.filter-bar.filter-bar-condensed.ng-hide";
	String COMMON_IFRAME_TAG = "//iframe[contains(@src,'redirect')]";
	String KIBANA_ELEMENT = "//span[contains(@title , 'Time')]";
	String KIBANA_ELEMENT_BYTES = "//span[contains(@title , 'TotalBytes')]";
	String KIBANA_CHART_VISUALIZE = "//visualize[@data-title='"; // ']";
	String KIBANA_CHART_PIA_LEGEND_VALUE = "/descendant::div[@class='legend-value-title legend-value-truncate']";
	String ANALYTICS_DROPDOWN_BUTTON = "//*[@id='navbar']/navbar/ul/li[3]/a";
	String ANALYTICS_FLOW_CONNECTION = "//*[@id='sub-menu-0-2']/div[1]/p[1]/a";
	String ANALYTICS_SEARCH_BUTTON = "//*[@id='kibana-body']/div[1]/div/div/div[3]/dashboard-app/div[1]/div/form/input";
	String ANALYTICS_TRAFFIC_TOTAL_CONNECTION_BYTES_COUNT = "//span[contains(text(),'Total Connection Bytes Count')]/parent::*/parent::*/visualize/div/div/div/div/div[1]/span";
	String TOTAL_COUNT = "//span[contains(text(),'$FIELD')]/parent::*/parent::*/visualize/div/div/div/div/div[1]/span";
	String ANALYTICS_AVERAGE_CONNECTION_LATENCY_MS = "//visualize[@data-title='Top Servers By Average Connection Latency in Î¼sec']/div/div/div/div[2]/div[2]/div/*[name()='svg']/*[name()='g']/*[name()='g']/*[name()='rect']";
	String ANALYTICS_REFRESH_BUTTON = "//div[@class='kuiLocalMenuItem navbar-timepicker-auto-refresh-desc']/parent::*/parent::*/div[@tooltip='Interval Selector']/div[2]/span[2]";
	String ANALYTICS_REFRESH_INTERVAL = "//a/parent::*/following::div[@class='kbn-refresh-section']/following-sibling::div//a[contains(text(),'5 seconds')]";
	String ANALYTICS_AVERAGE_CONNECTION_LATENCY_TOOLTIP = "//*[@id='kibana-body']/div[2]/table/tbody/tr[1]/td[2]";
	String ANALYTICS_LIST_OF_REFRESH_INTERVALS = "//*[@id='kibana-body']/div[4]/div/div/kbn-timepicker/div/div/div[2]";
	String ANALYTICS_PLURIBUS_WAIT = "div.ui-app-loading";
	String CUSTOM_TAGS_UPLOAD_TAGS = "//a[contains(text(),'Upload Tags')]";
	String CUSTOM_TAGS_CLEAR_TAGS = "//a[contains(text(),'Clear Tags')]";
	String CUSTOM_TAGS_CUSTOMIZE_DASHBOARD = "//a[contains(text(),'Customize Dashboard')]";
	String CUSTOM_TAGS_UPLOAD_SUCESS_ALERT = "//div[@class='alert alert-success']/div";
	String[] CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME = { "projects.src.item_srcip", "projects.src.item_dstip",
			"projects.src.item_dstport", "projects.src.item_srcswitchport", "projects.src.item_srcmac",
			"projects.src.item_dstmac" };
	String CUSTOM_TAGS_SAVE_BUTTON = "button.btn.btn-primary";
	String INPUT_FILE_FIELD = "//input[@type='file']";
	String CUSTOM_TAGS_UPLOAD_ERROR_ALERT = "//div[@class='alert alert-danger']/div";
	String CUSTOM_TAGS_CANCEL_BUTTON = "button.btn.btn-warning.cancel";
	String[] CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME_PCAP = { "projects.dst.item_src", "projects.dst.item_dst",
			"projects.dst.item_dstport", "projects.dst.item_srcport", "projects.dst.item_srcmac",
			"projects.dst.item_dstmac" };
	String PCAP_PACKET_COUNT = "//span[@ ng-bind='obj.getEsCount() | number']";

}