package com.pluribus.vcf.helper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.google.common.base.Splitter;

import static com.pluribus.vcf.helper.AnalyticsConstants.*;

public class AnalyticsMethods {
	private String switchUser = "root";
	private String switchPwd = "test123";
	private String switchName;
	SshClient sshHelper = new SshClient();
	private static final Logger log = Logger.getLogger(AnalyticsMethods.class);

	public AnalyticsMethods(String switchName) {
		this.switchName = switchName;
		try {
			sshHelper.establishConnection(switchName, switchUser, switchPwd);
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}

	private String convertToCliCmd(String cmd) {
		return "cli --no-login-prompt --quiet -c '" + cmd + "'";
	}

	// method to get the traffic count from terminal

	public int getCountByClientServeronTerminal(String filter) {

		int Terminal_count = 0;
		Map<String, String> map = Splitter.on("::").withKeyValueSeparator(":").split(filter);

		StringBuilder sb = new StringBuilder(1000);
		sb.append("connection-show  ");
		if (map.containsKey("src-ip"))
			sb.append("src-ip " + map.get("src-ip"));
		if (map.containsKey("src-ip"))
			sb.append(" dst-ip " + map.get("dst-ip"));
		if (map.containsKey("src-port"))
			sb.append(" src-port " + map.get("src-port"));
		if (map.containsKey("dst-port"))
			sb.append(" dst-port " + map.get("dst-port"));
		if (map.containsKey(" cur-State"))
			sb.append("curr-State " + map.get("cur-State"));
		sb.append(" count-output within-last 15m limit-output 100000");

		String out = sshHelper.execCmd(convertToCliCmd(sb.toString()));

		Pattern pattern = Pattern.compile("Count: (\\d+)", Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher(out);
		if (m.find()) {
			Terminal_count = Integer.parseInt(m.group(1).trim());
			log.info("Terminal count is " + Terminal_count);
		}
		return Terminal_count;
	}

	public long getCountBytes() throws IOException {
		long count = 0;
		String out1 = sshHelper.execCmd(
				convertToCliCmd("client-server-stats-show no-show-headers raw-int-values unscaled format total-bytes"));
		String[] connLines = out1.split("\n");
		for (String value : connLines) {
			log.info(value + "=value count=" + count);
			value = value.trim();
			if (value != "" && value != null && !value.isEmpty() && value.chars().allMatch(Character::isDigit))
				count += Long.parseLong(value.trim());
		}
		return count;
	}

	public float averageLatencyCount(String trafficDestIp) throws IOException {
		float count = 0;
		String out1 = sshHelper.execCmd(convertToCliCmd("connection-show no-show-headers unscaled format latency"));
		String[] connLines = out1.split("\n");
		for (String value : connLines) {
			log.info(value + "=value count=" + count);
			value = value.trim();
			if (value != "" && value != null && !value.isEmpty() && value.chars().allMatch(Character::isDigit))
				count += Float.parseFloat(value.trim());
		}
		return ((count) / 1000);
	}
}