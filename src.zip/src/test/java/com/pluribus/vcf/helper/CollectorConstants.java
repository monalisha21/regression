package com.pluribus.vcf.helper;

/* VCFIAIndexConst use to store all css and xpath of IA page.
 * */

public interface CollectorConstants {
	// Collector Mgmt tab of UNUM Setting
	String FOCUS_ON_BODY = "//body";
	String ALERT_NOTIFICATION = "div.alert.alert-success";
	String COLLECTOR_MGMT_COLLECTOR_TOGGLE = "/../following-sibling::div[3]//check-box[@class='on' or @class='off']//span//span[@class='toggle-dial']";
	String COLLECTOR_MGMT_COLLECTOR_TOGGLE_DIAL = "span.toggle-dial";
	String COLLECTOR_MGMT_COLLECTOR_TOGGLE_ON_BTN= "/../following-sibling::div[3]//check-box[@class='on']";
	String COLLECTOR_MGMT_ADD_SWITCH_LIST_TEXT = "//input[@name='switchname']";
	String COLLECTOR_MGMT_ADD_SWITCH_LIST = "//ul[@uib-dropdown-menu]/descendant::a";
	String COLLECTOR_MGMT_AUTHENTICATION_REQUIRED = "//span[@ng-show='form.switchname.$error.auth']";
	String COLLECTOR_MGMT_SWITCH_USERNAME= "//input[@placeholder='Switch Username']";
	String COLLECTOR_MGMT_SWITCH_PWD = "//input[@placeholder='Switch Password']";
	String COLLECTOR_MGMT_SETTING = "/preceding-sibling::span/span[@class='my-table-action fa fa-cog dropdown-toggle']";
	String COLLECTOR_MGMT_SETTING_DELETE = "/preceding-sibling::span/ul/li/a[contains(text(),'Delete')]";
	String COLLECTOR_MGMT_ADD_SWITCH_ADD_BTN = "//button[@name='ok' and @type='submit']";
	String COLLECTOR_MGMT_ADD_SWITCH_CANCEL_BTN = "//button[@class='btn btn-warning cancel' and contains (text(),'Cancel')]";
	String COLLECTOR_MGMT_START_COLLECTOR_OK_BTN = "//button[@ng-click='ok()']";
	String COLLECTOR_MGMT_ADD_COLLECTOR_BTN="//button[contains (text(),'Add Netvisor Collector')]";
	String COLLECTOR_MGMT_COLLECTOR_LIST_TABLE="div#my-table-th";
}