package com.pluribus.vcf.helper;

// VCF Manager Fabric Constants use to store all css and xpath.

public interface FabricConstants {
	String ALERT_NOTIFICATION = "div.alert.alert-success";
	String ADD_FABRIC = "a[ng-click='$ctrl.addFabric()']";
	String TOAST_MSG = "div.d3-tip";
	String FABRIC_DIALOG_ADD_6_NODE_PLAYBOOK = "label.unum-ztp_hostfile";
	String FABRIC_DIALOG_ADD_2_NODE_PLAYBOOK = "label.unum-add_manual";
	String FABRIC_DIALOG_FABRIC_NAME = "input.form-control.ng-pristine.ng-untouched.ng-empty.ng-invalid.ng-invalid-required.ng-valid-pattern";
	String FABRIC_DIALOG_TOGGLE_40G = "div.col-sm-5 select[value='True']";
	String FABRIC_DIALOG_GATEWAY_IP = "input#pn_gateway_ip";
	String FABRIC_DIALOG_USERAME = "username";
	String FABRIC_DIALOG_PASSWORD = "password";
	String FABRIC_DIALOG_NEXT_BTN = "span.fa.fa-chevron-right";
	String FABRIC_DIALOG_ADD_BTN = "button[ng-disabled='$ctrl.isDisableAddButton(form)']";
	String FABRIC_DIALOG_RADIO_BUTTONS = "input[type='radio']";
	String FABRIC_DIALOG_ACCEPT_LICENSE = "input[ng-model='$ctrl.createObj.isAcceptLicense']";
	String FABRIC_DIALOG_RESET_FABRIC_CHK_BOX = "input[ng-model='$ctrl.createObj.isResetFabric']";
	String FABRIC_DIALOG_FILE_UPLOAD_STATUS = "span.progress-status";
	String FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN = "button.btn.btn-primary.btn-sm[ng-if='$ctrl.isShowLaunchPlaybook()']";
	String FABRIC_DIALOG_VRRP_UPLOAD = "input#csvFileForPlaybook[file-type='vrrp_csv_file']";
	String FABRIC_SUCCESS_DIALOG = "div.modal-body";
	String FABRIC_DIALOG_CANCEL_CLOSE_BTN = "button.btn.btn-warning.cancel";
	String ERROR_NOTIFICATION = "div.alert.alert-danger";
	String FABRIC_DETAILS_PANEL = "h3.page-title";
	String FABRIC_DIALOG_STATUS_BAR = "div.progress-bar.progress-bar-info span";
	String FABRIC_LEFT_PANE_FABRIC_NAME = "//span[contains(@uib-tooltip,'";
	String FABRIC_DIALOG_ADD_SWITCH = "//label[@class='unum-add_seed_switch']";
	String FABRIC_LIST_ARROW_LEFT = "i.fa.fa-caret-left";
	String FABRIC_LIST_ARROW_DOWN = "i.fa.fa-caret-down";
	String FABRIC_SETTINGS_DELETE = "a[ng-click='$ctrl.removeFabric($index);$event.stopPropagation();']";
	String FABRIC_SETTINGS_ICON = "h3 span.my-table-action.fa.fa-cog.dropdown-toggle";
	String FABIC_DELETE_DIALOG_OK_BTN = "button.btn.btn-primary";
	String FABRIC_DETAILS_SWITCH_LIST = "//div[@class='tr']/div[1]/span[2]";
	String FABRIC_DIALOG_THIRD_PARTY_SWITCH1 = "//input[@name='0' and @value='third_party_spine']";
	String FABRIC_DIALOG_THIRD_PARTY_SWITCH2 = "//input[@name='1' and @value='third_party_spine']";
	String FABRIC_DIALOG_SAVE_BUTTON = "//button[@name='save']";
	String FABRIC_DIALOG_RESET_FABRIC_DROPDOWN = "//div[@class='col-sm-7']/select";
	String INBAND_IP = "//div[@class='col-sm-5']/input[@id='pn_inband_ipv4']";
	String NOTIFICATION_POP_UP_CLOSE_BUTTON = "//button[@class='close']/span[@class='fa fa-times']";
}
