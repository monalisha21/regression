package com.pluribus.vcf.helper;

public interface IAChartList {

	//Connection Tab
	String CONNECTION_TOP_L4_SERVICES = "Insight - Top L4 Services by Connections";
	String CONNECTION_TOP_CLIENT = "Insight - Top Clients by Connections";
	String CONNECTION_L4_SERVICES_COUNT = "Insight - L4 Services Count";
	String CONNECTION_COUNT = "Insight - Connection Count";
	String CONNECTION_TOP_DOMAINS_CONNECTION = "Insight - Top Domains by Connections";
	String CONNECTION_TOP_SERVER_BY_CONNECTION = "Insight - Top Servers by Connections";
	String CONNECTION_TOP_L4_SERVICES_BY_TOTAL = "Top L4 Services by Total Unique Clients";
	String CONNECTION_TOP_SERVER_BY_TOTAL = "Top Servers by Total Unique Clients";
	String CONNECTION_TOP_SERVERS_BY_AVG = "Top Servers By Average Connection Latency in μsec";
	String CONNECTION_BY_STATE = "Insight - Connections by State";
	String CONNECTION_TOP_SWITCHES_BY_TOTAL = "Top Switches by Total # of Connections";
	String CONNECTION_TIMELINE_BY_STATE = "Insight - Connections Timeline by State";
	String CONNECTION_DETAILS = "Insight - Details";

	String[] CONNECTION_TAB = {CONNECTION_TOP_L4_SERVICES,
			CONNECTION_TOP_CLIENT,
			CONNECTION_L4_SERVICES_COUNT,
			CONNECTION_COUNT,
			CONNECTION_TOP_DOMAINS_CONNECTION,
			CONNECTION_TOP_SERVER_BY_CONNECTION,
			CONNECTION_TOP_L4_SERVICES_BY_TOTAL,
			CONNECTION_TOP_SERVER_BY_TOTAL,
			CONNECTION_TOP_SERVERS_BY_AVG,
			CONNECTION_BY_STATE,
			CONNECTION_TOP_SWITCHES_BY_TOTAL,
			CONNECTION_TIMELINE_BY_STATE,
			CONNECTION_DETAILS
			};

	//Traffic Tab
	String TRAFFIC_TOP_L4_SERVICES = "Top L4 Services by Bytes";
	String TRAFFIC_TOP_CLIENT_BY_BYTES = "Top Clients by Bytes";
	String TRAFFIC_L4_SERIVES_COUNT = "Insight - L4 Services Count";
	String TRAFFIC_TOTAL_CONNECTION_BYTES = "Total Connection Bytes Count";
	String TRAFFIC_TOP_SERVERS_BY_AVG_TOTALBYTES = "Top Servers by Average TotalBytes (for FIN/RST)";
	String TRAFFIC_BYTES_STATE = "Insight - Bytes by State";
	String TRAFFIC_TOP_SERVERS_BY_BYTES = "Insight - Top Servers by Bytes";
	String TRAFFIC_TOP_CLIENTS_BY_AVG_TOTALBYES = "Top Clients by Average TotalBytes (for FIN/RST)";
	String TRAFFIC_TOP_SERVER_DOMAIN = "Insight - Top Server Domains by Bytes";
	String TRAFFIC_TOP_SWITCHES_BY_TOTAL_BYTES = "Top Switches by Total Bytes";
	String TRAFFIC_TOP_SERVERS_BY_CONNECTION_RST = "Top Servers by Connection in RST state and 0 bytes";
	String TRAFFIC_DETAILS = "Insight - Details";

	String[] TRAFFIC_TAB = {TRAFFIC_TOP_L4_SERVICES,
			TRAFFIC_TOP_CLIENT_BY_BYTES,
			TRAFFIC_L4_SERIVES_COUNT,
			TRAFFIC_TOTAL_CONNECTION_BYTES,
			TRAFFIC_TOP_SERVERS_BY_AVG_TOTALBYTES,
			TRAFFIC_BYTES_STATE,
			TRAFFIC_TOP_SERVERS_BY_BYTES,
			TRAFFIC_TOP_CLIENTS_BY_AVG_TOTALBYES,
			TRAFFIC_TOP_SERVER_DOMAIN,
			TRAFFIC_TOP_SWITCHES_BY_TOTAL_BYTES,
			TRAFFIC_TOP_SERVERS_BY_CONNECTION_RST,
			TRAFFIC_DETAILS};

	//ADDM Tab No of chart is 6
	String ADDM_TOP_SWITCHES ="Top Switches by Total # of Connections";
	String ADDM_CONNECTION_TIMELINE = "Insight - Connections Timeline by State";
	String ADDM_CONNECTION_COUNT= "Insight - Connection Count";
	String ADDM_TOTAL_CLIENT= "Total Client Endpoints";
	String ADDM_SRCIP_TO_DSTIP= "SrcIp to dstIp Dependencies";
	String ADDM_DETAILS= "Insight - Details";

	String[] ADDM_TAB = {ADDM_TOP_SWITCHES, ADDM_CONNECTION_TIMELINE,
			ADDM_CONNECTION_COUNT, ADDM_TOTAL_CLIENT, ADDM_SRCIP_TO_DSTIP,
			ADDM_DETAILS };

	//VMWare Connection Tab No of chart is Available 17
	String VMCONN_CONNECTIONS_BY_VMKERNEL= "Connections by VM/vm-kernel";
	String VMCONN_INFRASTRUCTURE_CONNECTION= "VMware Infrastructure Connections";
	String VMCONN_KERNEL_SERVICES= "vm-kernel Services by Connections";
	String VMCONN_ONLY_CONNECTION= "VM only Connections";
	String VMCONN_IP_STORAGE_KERNEL = "IP Storage vm-kernel Connections";
	String VMCONN_CONNECTION_BY_VCENTER = "Connections by vCenter";
	String VMCONN_VIRTUAL_SAN_SERVICES = "Virtual SAN Services";
	String VMCONN_TOTAL_VMS_BY_VCENTER = "Total VMs by vCenter";
	String VMCONN_TOP_VM_L4_SERVICES = "Top VM L4 Services by Connections";
	String VMCONN_TOP_KERNEL_SERVICES = "Top vm-kernel Services by Connections";
	String VMCONN_TOP_VM_CLIENTS = "Top VM Clients by Connections";
	String VMCONN_TOP_VM_SERVERS = "Top VM servers by Connections";
	String VMCONN_TOP_ESXI_SERVERS = "Top ESXi Servers by Connections";
	String VMCONN_TOP_KERNEL_CLIENT = "Top vm-kernel Clients by Connections";
	String VMCONN_TOP_STANDARD_PORT = "Top Standard Port Groups by Connections";
	String VMCONN_TOP_DISTRIBUTED_PORT = "Top Distributed Port Groups by Connections";
	String VMCONN_VMWARE_DETAILS = "VMware - Details";

	String[] VMCONN_TAB = {VMCONN_CONNECTIONS_BY_VMKERNEL, VMCONN_INFRASTRUCTURE_CONNECTION,
			VMCONN_KERNEL_SERVICES, VMCONN_ONLY_CONNECTION, VMCONN_IP_STORAGE_KERNEL,
			VMCONN_CONNECTION_BY_VCENTER,VMCONN_VIRTUAL_SAN_SERVICES, VMCONN_TOTAL_VMS_BY_VCENTER,
			VMCONN_TOP_VM_L4_SERVICES, VMCONN_TOP_KERNEL_SERVICES, VMCONN_TOP_VM_CLIENTS,
			VMCONN_TOP_VM_SERVERS, VMCONN_TOP_ESXI_SERVERS, VMCONN_TOP_KERNEL_CLIENT,
			VMCONN_TOP_STANDARD_PORT, VMCONN_TOP_DISTRIBUTED_PORT, VMCONN_VMWARE_DETAILS
	};

	//VMWare Traffic Tab  No of chart is Available 17
	String VMTRAFFIC_TOTAL_BYTES = "Total Bytes by VM/vm-kernel";
	String VMTRAFFIC_VMWARE_INFRASTRUCTURE = "VMware Infrastructure Total Bytes";
	String VMTRAFFIC_KERNEL_SERVICES = "vm-kernel Services Total Bytes";
	String VMTRAFFIC_VM_ONLY_TOTAL = "VM only Total Bytes";
	String VMTRAFFIC_IP_STORAGE_KERNEL = "IP Storage vm-kernel Total Bytes";
	String VMTRAFFIC_TOTAL_BYTES_BY_VCENTER = "Total Bytes by vCenter";
	String VMTRAFFIC_VIRTUAL_SAN_SERVICES = "Virtual SAN Services Total Bytes";
	String VMTRAFFIC_TOTAL_VMS_BY_VCENTER = "Total VMs by vCenter";
	String VMTRAFFIC_TOP_VM_L4_SERVICES = "Top VM L4 Services by Total Bytes";
	String VMTRAFFIC_TOP_KERNEL_SERVICES = "Top vm-kernel Services by Total Bytes";
	String VMTRAFFIC_TOP_CLIENTS = "Top VM Clients by Total Bytes";
	String VMTRAFFIC_TOP_SERVERS = "Top VM servers by Total Bytes";
	String VMTRAFFIC_TOP_ESXI_SERVERS = "Top ESXi Servers by Total Bytes";
	String VMTRAFFIC_TOP_KERNEL_CLIENTS = "Top vm-kernel Clients by Total Bytes";
	String VMTRAFFIC_TOP_STANDARD_PORT = "Top Standard Port Groups by Total Bytes";
	String VMTRAFFIC_TOP_DISTRIBUTED_PORT = "Top Distributed Port Groups by Total Bytes";
	String VMTRAFFIC_DETAILS = "VMware - Details";

	String[] VMTRAFFIC_TAB = {VMTRAFFIC_TOTAL_BYTES, VMTRAFFIC_VMWARE_INFRASTRUCTURE,
			VMTRAFFIC_KERNEL_SERVICES, VMTRAFFIC_VM_ONLY_TOTAL, VMTRAFFIC_IP_STORAGE_KERNEL,
			VMTRAFFIC_TOTAL_BYTES_BY_VCENTER, VMTRAFFIC_VIRTUAL_SAN_SERVICES, 
			VMTRAFFIC_TOTAL_VMS_BY_VCENTER, VMTRAFFIC_TOP_VM_L4_SERVICES, VMTRAFFIC_TOP_KERNEL_SERVICES,
			VMTRAFFIC_TOP_CLIENTS, VMTRAFFIC_TOP_SERVERS, VMTRAFFIC_TOP_ESXI_SERVERS,
			VMTRAFFIC_TOP_KERNEL_CLIENTS, VMTRAFFIC_TOP_STANDARD_PORT, VMTRAFFIC_TOP_DISTRIBUTED_PORT,
			VMTRAFFIC_DETAILS};

	//VMWare ADDM Tab  No of chart is Available 6
	String VMADDM_TOP_SWITCHES_TOTAL_CONNECTION = "Top Switches by Total # of Connections";
	String VMADDM_CONNECTION_TIMELINE = "Insight - Connections Timeline by State";
	String VMADDM_CONNECTION_COUNT = "Insight - Connection Count";
	String VMADDM_TOTAL_CLIENT_ENDPOINTS = "Total Client Endpoints";
	String VMADDM_DEPENDENCIES_VMWARE = "Top Dependencies by VMware";
	String VMADDM_DETAILS = "Insight - Details";

	String[] VMADDM_TAB = {VMADDM_TOP_SWITCHES_TOTAL_CONNECTION, VMADDM_CONNECTION_TIMELINE,
			VMADDM_CONNECTION_COUNT, VMADDM_TOTAL_CLIENT_ENDPOINTS,
			VMADDM_DEPENDENCIES_VMWARE, VMADDM_DETAILS};

	//Post status Tab no of chart is Available 15
	String PORT_INPUT_PACKETS = "Port - Input Traffic (Packets)";
	String PORT_OUTPUT_PACKETS = "Port - Output Traffic (Packets)";
	String PORT_INPUT_BYTES = "Port - Input Traffic (Bytes)";
	String PORT_OUTPUT_BYTES = "Port - Output Traffic (Bytes)";
	String PORT_INPUT_PRACKETS = "Port - Input Problems (Total Packets)";
	String PORT_OUTPUT_PROBLEM_PACKETS = "Port - Output Problems (Packets)";
	String PORT_TOP_INPUT_TRAFFIC = "Port - Top Ports Input Traffic (Packets)";
	String PORT_TOP_CLIENT_CONNECTIONS = "Port - Top Ports by Client Connections";
	String PORT_TOP_OUTPUT_TRAFFIC = "Port - Top Ports Output Traffic (Packets)";
	String PORT_TOP_BYSERVER_CONNECTIONS= "Port - Top Ports by Server Connections";
	String PORT_INPUT_PROBLEMS_PORTS = "Port - Input Problems by Ports";
	String PORT_TOP_BY_CLIENT = "Port - Top Ports by Client";
	String PORT_OUTPUT_PROBLEMS_BY_PORTS = "Port - Output Problems by Ports";
	String PORT_TOP_PORTS_BY_SERVER = "Port - Top Ports by Server";
	String PORT_DETAIL_DATA = "Port - Detail Data";

	String[] PORT_TAB = {PORT_INPUT_PACKETS,
			PORT_OUTPUT_PACKETS,PORT_INPUT_BYTES, PORT_OUTPUT_BYTES, PORT_INPUT_PRACKETS,
			PORT_OUTPUT_PROBLEM_PACKETS, PORT_TOP_INPUT_TRAFFIC, PORT_TOP_CLIENT_CONNECTIONS,
			PORT_TOP_OUTPUT_TRAFFIC,PORT_TOP_BYSERVER_CONNECTIONS, PORT_INPUT_PROBLEMS_PORTS,
			PORT_TOP_BY_CLIENT, PORT_OUTPUT_PROBLEMS_BY_PORTS, PORT_TOP_PORTS_BY_SERVER,
			PORT_DETAIL_DATA};
}