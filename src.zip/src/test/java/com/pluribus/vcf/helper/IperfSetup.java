/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/
package com.pluribus.vcf.helper;

import org.apache.log4j.Logger;

public class IperfSetup {
	private String clientIp;
	private String serverIp;
	private String iperfUser = "root";
	private String iperfPwd = "test123";
	SshClient iperfServer = new SshClient();
	private static final Logger log = Logger.getLogger(IperfSetup.class);

	public IperfSetup(String clientAddr, String serverAddr) {
		this.clientIp = clientAddr;
		this.serverIp = serverAddr;
	}

	/* Start server */
	public boolean startServer(String switchIp) throws Exception {

		iperfServer.establishConnection(serverIp, iperfUser, iperfPwd);
		log.info("connection establish with iperf server =" + iperfServer.execCmd("hostname") );
		if(isIperfServerRunning()) killServer();
		iperfServer.execCmd("/usr/bin/iperf3 -s -D > /dev/null 2>&1");
		if(isIperfServerRunning()) {
			log.info("startIperfServer :iperf server started");
			return true;
		} else {
			log.info("startIperfServer :iperf server not started");
			return false;
		}
	}

	/* Start Iperf Server on specific port server */
	public boolean startServer(String switchIp,String port) throws Exception {

		iperfServer.establishConnection(serverIp, iperfUser, iperfPwd);
		log.info("connection establish with iperf server =" + iperfServer.execCmd("hostname") );
		if(isIperfServerRunning(port)) killServer(port);
		iperfServer.execCmd("/usr/bin/iperf3 -s -D -p "+ port + " > /dev/null 2>&1");
		if(isIperfServerRunning(port)) {
			log.info("startIperfServer :iperf server started");
			return true;
		} else {
			log.info("startIperfServer :iperf server not started");
			return false;
		}
	}

	public void killServer() throws Exception {
		killIperfServer("ps -ef | grep [i]perf");
	}

	public void killServer(String port) throws Exception {
		killIperfServer("ps -ef | grep [i]perf | grep " + port);
	}

	private void killIperfServer(String cmd) throws Exception {
		String out1 = iperfServer.execCmd(cmd);
		if (!out1.isEmpty()) {
			String[] pids = out1.split("\n");
			for (int i = 0; i < pids.length; i++) {
				iperfServer.execCmd("kill -9 " + pids[i].trim());
			}
		}
	}

	public boolean isIperfServerRunning(){
		return iperfServer.execCmd("ps -ef | grep [i]perf").isEmpty() ? false : true;
	}

	public boolean isIperfServerRunning(String port){
		return iperfServer.execCmd("ps -ef | grep [i]perf | grep " + port ).isEmpty() ? false : true;
	}

	public boolean sendTraffic(String destIp, int numSessions, int timeVal) throws Exception {
		boolean status = false;
		if(isIperfServerRunning()) {
			SshClient iperfClient = new SshClient();
			iperfClient.establishConnection(clientIp, iperfUser, iperfPwd);
			String command = "/usr/bin/iperf3 -c " + destIp + " -P " + numSessions  + " -t " + timeVal;
			if( iperfClient.execCmd(command).contains("iperf Done")) {
				log.info("Traffic sent from iperf client: number of sessions" + numSessions + "for " + timeVal + " seconds");
				status = true;
			} else {
				log.info("Traffic sent Fail from iperf client: number of sessions" + numSessions + "for " + timeVal + " seconds");
				status = false;
			}
			Thread.sleep(1000); // Sleeping after traffic run so that stats can be
								// updated
			iperfClient.closeSession();
		} else {
			status = false;
		}
		return status;
	}

	public boolean sendTraffic(String destIp, int numSessions, int timeVal, String port) throws Exception {
		boolean status = false;
		if(isIperfServerRunning()) {
			SshClient iperfClient = new SshClient();
			iperfClient.establishConnection(clientIp, iperfUser, iperfPwd);
			String command = "/usr/bin/iperf3 -c " + destIp + " -P " + numSessions  + " -t " + timeVal + " -p " + port;
			if( iperfClient.execCmd(command).contains("iperf Done")) {
				log.info("Traffic sent from iperf client: number of sessions" + numSessions + "for " + timeVal + " seconds");
				status = true;
			} else {
				log.info("Traffic sent Fail from iperf client: number of sessions" + numSessions + "for " + timeVal + " seconds");
				status = false;
			}
			Thread.sleep(1000); // Sleeping after traffic run so that stats can be updated
			iperfClient.closeSession();
		} else {
			status = false;
		}
		return status;
	}
}