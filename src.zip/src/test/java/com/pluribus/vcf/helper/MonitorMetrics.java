package com.pluribus.vcf.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcabi.ssh.SSHByPassword;
import com.jcabi.ssh.Shell;

public class MonitorMetrics extends PageInfra implements Runnable {

	private java.util.Properties metricsProperties;
	private static String vcfIpForMetrics;
	private static String metricsUserName;
	private static String metricsPassword;
	private static String getMetrics = "/vcf-mgr/metrics";
	int totalMetricsCount = 0;
	int memoryThresholdViolationCount = 0;
	int cpuThresholdViolationCount = 0;
	private boolean isRunning = true;
	@FindBy(how = How.CSS, using = "button.btn.btn-info")
	WebElement addFabric;
	String snmpTab = "//uib-tab-heading[text()='SNMP']";
	String mapTab = "//uib-tab-heading[text()='Map']";
	String getIframe = "//iframe[contains(@src,'kibana-redirect')]";
	String getIframeElement = "//span[contains(@title , 'Timeline')]";
	String completedFabric = "//*[contains(text() , 'completed')]";
	private static final Logger log = Logger.getLogger(MonitorMetrics.class);

	public MonitorMetrics(WebDriver driver, String vcfIp, String vcfUserName, String password) throws IOException {
		super(driver);
		metricsProperties = new Properties();
		metricsProperties.loadFromXML(new FileInputStream("metrics.xml"));
		this.vcfIpForMetrics = vcfIp;
		this.metricsUserName = vcfUserName;
		this.metricsPassword = password;
	}

	public void terminate() {
		isRunning = false;
	}

	// Bring system to a moderate usage level by simulating some random user activities.
	public void simulateGeneralSystemUsage() throws InterruptedException {
		if (isElementActive(By.xpath(completedFabric))) {
		driver.findElement(By.xpath(snmpTab)).click();
		frameToBeAvailable(By.xpath(getIframe));
		waitForElementVisibility(driver.findElement(By.xpath(getIframeElement)));
		Thread.sleep(30000);
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath(mapTab)).click();
		waitForElementVisibility(addFabric);
		}
	}

	public int[] threadMonitoring() throws ClientProtocolException, IOException, InterruptedException {
		String json = getCurlResult(vcfIpForMetrics, getMetrics).toString();
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> obj = mapper.readValue(json, Map.class);
		int threadsPeak = (Integer) obj.get("threads.peak");
		int threadsDaemon = (Integer) obj.get("threads.daemon");
		int threads = (Integer) obj.get("threads");
		return new int[] { threadsPeak, threadsDaemon, threads };
	}

	public void runMetrics() throws InterruptedException, IOException {
		try {
			totalMetricsCount++;
			String json = getCurlResult(vcfIpForMetrics, getMetrics).toString();
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> obj = mapper.readValue(json, Map.class);
			log.info("=================================================");
			log.info("Time when below Sample was taken-" + Calendar.getInstance().getTime());
			log.info("=================================================");
			int mem = (Integer) obj.get("mem");
			int freeMem = (Integer) obj.get("mem.free");
			log.info("Total Memory : " + mem);
			log.info("Free Memory : " + freeMem);
			float memPerformance;
			memPerformance = (float) ((freeMem * 100) / mem);
			log.info("Memory Performance in Percentage : " + memPerformance);

			if (memPerformance >= Integer.parseInt(metricsProperties.getProperty("memoryThreshold"))) {
				log.info("System memory performance is fine");
			} else {
				memoryThresholdViolationCount++;
				log.info(
						memoryThresholdViolationCount + " Memory Sample resulted in Violation");
				float memoryViolationPercentage = ((float) (memoryThresholdViolationCount) * 100) / totalMetricsCount;
				if (memoryViolationPercentage >= Float
						.valueOf(metricsProperties.getProperty("memoryViolationThreshold"))) {
					log.info(
							memoryThresholdViolationCount + " out of " + totalMetricsCount
									+ " Memory Monitoring samples resulted in violations from the permitted "
									+ metricsProperties.getProperty("memoryViolationThreshold")
									+ "% violation so result is FAILURE");
				}
			}

			log.info( "=================================================");
			int processors = (Integer) obj.get("processors");
			double systemloadAverage = (Double) obj.get("systemload.average");
			log.info( "Total processors : " + processors);
			log.info( "Average Systemload Load : " + systemloadAverage);
			float cpuPerformance;
			cpuPerformance = (float) ((systemloadAverage * 100) / processors);
			log.info( "CPU Performance in Percentage : " + cpuPerformance);

			if (cpuPerformance <= Integer.parseInt(metricsProperties.getProperty("cpuThreshold"))) {
				log.info( "System Average Systemload Load is fine");
			} else {
				cpuThresholdViolationCount++;
				log.info(
						cpuThresholdViolationCount + " System Average Load Sample resulted in Violation");
				float cpuViolationPercentage = (((float) cpuThresholdViolationCount) / totalMetricsCount) * 100;
				if (cpuViolationPercentage >= Float.valueOf(metricsProperties.getProperty("cpuViolationThreshold"))) {
					log.info(
							cpuThresholdViolationCount + " out of " + totalMetricsCount
									+ " CPU Monitoring samples resulted in violations from the permitted "
									+ metricsProperties.getProperty("cpuViolationThreshold")
									+ "% violation so result is FAILURE");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void run() {
		int count = 0;
		try {
			while (isRunning) {
				try {
					while (count < (Integer.parseInt(metricsProperties.getProperty("monitiorCycle"))
							* Integer.parseInt(metricsProperties.getProperty("monitorPeriod")))) {
						runMetrics();
						TimeUnit.MINUTES.sleep(Integer.parseInt(metricsProperties.getProperty("monitiorCycle")));
						count++;
					}
				} catch (InterruptedException e) {
					// e.printStackTrace();
					isRunning = false;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
	}

	public static String getCurlResult(String Ip, String getRequest) throws IOException {
		Shell sh1 = new Shell.Verbose(new SSHByPassword(vcfIpForMetrics, 22, "vcf", "changeme"));
		String out1;
		out1 = new Shell.Plain(sh1).exec("curl --user " + metricsUserName + ":" + metricsPassword + " https://"
				+ vcfIpForMetrics + getMetrics + " -k --silent");
		return out1;
	}
}
