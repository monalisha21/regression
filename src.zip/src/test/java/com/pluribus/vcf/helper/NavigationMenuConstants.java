package com.pluribus.vcf.helper;

public interface NavigationMenuConstants {
	String MENU_NOTIFICATION = "//a[contains(text(),'Notifications')]";
	String MENU_NOTIFICATION_CONSTANT = "//a[@ui-sref='notifications.";
	String MENU_NAMES_CONSTANT = "//a[contains(text(),";
	String MENU_USER = "span.fa.fa-user-circle";
	String MENU_USER_CHANGE_PASSWORD = "//a[contains(text(),'Change Password')]";
	String MENU_USER_LOGOUT = "span.unum-logout";
	String MENU_BELL_ICON = "a.notification-info.dropdown-toggle";
	String MENU_BELL_ICON_FABRIC = "//notifications//uib-tab-heading[contains(text(),'Fabric')]";
	String MENU_BELL_ICON_LICENSE = "//notifications//uib-tab-heading[contains(text(),'License')]";
	String MENU_SETTINGS = "span.unum-gears";
	String MENU_SETTINGS_LICENSE = ".//a[contains(@href,'/settings/license')]";
	String MENU_SETTINGS_AUTH_SERVER = ".//a[contains(@href,'/settings/ldap')]";
	String MENU_SETTINGS_MANAGE_USERS = ".//a[contains(@href,'/settings/users')]";
	String MENU_SETTINGS_AUDIT_LOGS = ".//a[contains(@href,'/settings/audit')]";
	String MENU_SETTINGS_SYSTEM_HEALTH = ".//a[contains(@href,'/settings/health')]";
	String MENU_CUSTOMTAG_CONSTANT = "//a[@ui-sref='pa-dashboard.custom'][contains(text(),";
}