package com.pluribus.vcf.helper;

import java.io.File;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Optional;
import com.pluribus.vcf.pagefactory.AddFabric;
import com.pluribus.vcf.pagefactory.ManageCollector;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;

public class PlaybookHelper extends PageInfra {

	public PlaybookHelper(WebDriver driver) {
		super(driver);
	}

	public WebDriver getDriver() {
		return driver;
	}

	private TopologyPage topology = new TopologyPage(getDriver());
	private AddFabric vcfMgr1 = new AddFabric(getDriver());
	private NavigationMenu menu = new NavigationMenu(getDriver());
	private ManageCollector manageCollector = new ManageCollector(getDriver());
	private static final Logger log = Logger.getLogger(PlaybookHelper.class);
	private static String[] fileNameList = new String[5];
	private static File[] filesInventory = new File[9];

	public boolean playbookTestHelper(String hostFile, @Optional("test123") String password, String collectorName,
			String gatewayIp, String inbandIp, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			String testPlaybookName) throws Exception {
		boolean playbookHelperStatus = true;
		try {
			topology.handleCancelButtonClick();
			log.info("Running stopCollector Test");
			// check Collector Management tab and current status of collector.
			menu.gotoMenu("Manage", "Fabric", "Manage Collector");
			if (manageCollector.stopCollector(collectorName)) {
				log.info("Collector " + collectorName + " stopped successfully");
			} else {
				log.info("Collector not found");
			}
			menu.gotoMenu("Overview", "Overview", "Topology");
		} catch (Exception e) {
			log.error(e);
			playbookHelperStatus = false;
		}
		if (!topology.deleteFabric()) {
			playbookHelperStatus = false;
			log.error("Deletion of existing switches failed. Aborting playbook run");
			throw new Exception("Deletion of existing switches failed");
		}
		filesInventory[0] = new File(hostFile);
		filesInventory[1] = new File(csvFile);
		filesInventory[2] = new File(vlanCsvFile);
		filesInventory[3] = new File(vrrpCsvFile);
		filesInventory[4] = new File(bgpCsvFile);
		filesInventory[5] = new File(ospfCsvFile);
		filesInventory[6] = new File(trunkCsvFile);
		filesInventory[7] = new File(vlagCsvFile);
		filesInventory[8] = new File(sviCsvFile);
		for (int i = 0; i < filesInventory.length; i++) {
			if (!PageInfra.filesInventoryCheck(filesInventory[i])) {
				playbookHelperStatus = false;
				log.error("File " + filesInventory[i] + " doesn't exist");
				throw new Exception("File " + filesInventory[i] + " doesn't exist");
			}
		}
		fileNameList[0] = hostFile;
		if (vcfMgr1.fabricCreation(fileNameList, password, collectorName, gatewayIp, inbandIp, testPlaybookName)) {
			log.info("Fabric was configured successfully");
		} else {
			playbookHelperStatus = false;
			log.error("Fabric was not configured successfully");
			throw new Exception("Fabric was not configured successfully");
		}
		switch (testPlaybookName) {
		case "L2 VRRP":
			fileNameList[0] = csvFile;
			break;
		case "L3 VRRP OSPF":
			fileNameList[0] = csvFile;
			break;
		case "L3 VRRP EBGP":
			fileNameList[0] = csvFile;
			break;
		case "L2 with existing spines":
			fileNameList[0] = csvFile;
			break;
		case "L3 VRRP OSPF with existing spines":
			fileNameList[0] = csvFile;
			break;
		case "L3 VRRP EBGP with existing spines":
			fileNameList[0] = csvFile;
			break;
		case "L2 Single Switch":
			fileNameList[0] = vlanCsvFile;
			fileNameList[1] = trunkCsvFile;
			break;
		case "L2 Two Switch Cluster":
			fileNameList[0] = vlanCsvFile;
			fileNameList[1] = trunkCsvFile;
			fileNameList[2] = vlagCsvFile;
			break;
		case "L2 Cluster with VRRP":
			fileNameList[0] = vlanCsvFile;
			fileNameList[1] = vrrpCsvFile;
			fileNameList[2] = trunkCsvFile;
			fileNameList[3] = vlagCsvFile;
			break;
		case "L3 Single Routed BGP":
			fileNameList[0] = bgpCsvFile;
			break;
		case "L3 Single Routed OSPF":
			fileNameList[0] = ospfCsvFile;
			break;
		case "L3 BGP with VRRP":
			fileNameList[0] = vlanCsvFile;
			fileNameList[1] = vrrpCsvFile;
			fileNameList[2] = bgpCsvFile;
			fileNameList[3] = trunkCsvFile;
			fileNameList[4] = vlagCsvFile;
			break;
		case "L3 OSPF with VRRP":
			fileNameList[0] = vlanCsvFile;
			fileNameList[1] = vrrpCsvFile;
			fileNameList[2] = ospfCsvFile;
			fileNameList[3] = trunkCsvFile;
			fileNameList[4] = vlagCsvFile;
			break;
		case "L3 Single Routed BGP with L2":
			fileNameList[0] = bgpCsvFile;
			fileNameList[1] = vlanCsvFile;
			fileNameList[2] = sviCsvFile;
			fileNameList[3] = trunkCsvFile;
			break;
		case "L3 Single Routed OSPF with L2":
			fileNameList[0] = ospfCsvFile;
			fileNameList[1] = vlanCsvFile;
			fileNameList[2] = sviCsvFile;
			fileNameList[3] = trunkCsvFile;
			break;
		}
		if (vcfMgr1.playbookExecution(fileNameList, testPlaybookName)) {
			log.info("Playbook " + testPlaybookName + " was configured successfully");
		} else {
			playbookHelperStatus = false;
			log.error("Playbook " + testPlaybookName + " was not configured successfully");
			throw new Exception("Playbook " + testPlaybookName + " was not configured successfully");
		}
		return playbookHelperStatus;
	}
}
