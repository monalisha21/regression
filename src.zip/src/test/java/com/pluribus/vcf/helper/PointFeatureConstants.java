package com.pluribus.vcf.helper;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;

public interface PointFeatureConstants {
	String CREATE_VLAN_BUTTON_TEXT = "Create VLANs by range";
	String DELETE_VLAN_BUTTON_TEXT = "Delete VLANs by range";
	String CREATE_VLAG_BUTTON_TEXT = "Create virtual link aggregation";
	String ADD_PORT_BUTTON_TEXT = "Add a port to a VLAN";
	String REMOVE_PORT_BUTTON_TEXT = "Remove ports from ";
	String MANAGE_FORM = "div.modal-content";
	String MANAGE_FORM_MIRROR = "div.config-content";
	String FORM_SAVE_BUTTON = "button.btn.btn-primary"; // VLAN and VLAG
	String EXISTING_LIST = "div.tbody"; // VLAN and VLAG
	String DROPDOWN_BOX = "input[name='selectSelector']";
	String DROPDOWN_ARROW = "button.btn.btn-default.btn-sm.arrow-button";
	String DROPDOWN_ARROW_ADMIN = "button.btn.btn-default.btn-sm";
	String DROPDOWN_ARROW_CLASS = "btn btn-default btn-sm arrow-button";
	String DROPDOWN_ARROW_ADMIN_CLASS = "btn btn-default btn-sm";
	String DROPDOWN_LIST = "ul.dropdown-menu";
	String DROPDOWN_MENU_ITEM = "div[@class='btn-group dropdown-toggle select-drop-down open']//ul//li//a";
	String DROPDOWN_MENU_ITEM_ADMIN = "div[@class='btn-group dropdown dropdown-toggle open']//ul//li//a";
	String ALERT_NOTIFICATION = "div.alert.alert-success";
	String ERROR_NOTIFICATION = "div.alert.alert-danger";
	String DELETE_VLAG_DROPDOWN = "ul.dropdown-menu.dropdown-menu-e";
	String DELETE_ICON = "//span[@aria-expanded='true']/following-sibling::ul//li//a[contains(text(),'Delete')]";
	String CREATE_TRUNK_BUTTON_TEXT = "Create a trunk configuration for link aggregation";
	String CREATE_CLUSTER_BUTTON_TEXT = "Create a new cluster for high availability (HA) in a fabric";
	String PLURIBUS_WAIT_ICON = "span.pluribus-loading-spinner";
	String CREATE_VROUTER_SELECT_DROPDOWN = "select.form-control.ng-pristine.ng-untouched.ng-valid.ng-empty";
	String CREATE_HW_VROUTER_TEXT = "Create H/W vRouter";
	String CREATE_VROUTER_GO_BUTTON = "button.btn.btn-custom.btn-primary";
	String CREATE_VROUTER_PLUS_ICON = "button[class='icon-img-link fa fa-plus-circle ng-pristine ng-untouched ng-valid ng-empty'][ng-show='!vm.isAdvancedFieldVisible']";
	int TIMEOUT_VALUE = 100;
	String CREATE_VFLOW_BUTTON_TEXT = "Create a virtual flow definition for L2 or L3 IP";
	String CREATE_SYSLOG_BUTTON_TEXT = "Create the scope and other parameters of syslog event collection";
	String CREATE_SYSLOGMATCH_BUTTON_TEXT = "Search a syslog file for specific events logged to it";
	String CREATE_SNMP_TRAP_BUTTON_TEXT = "Create a SNMP trap sink";
	String CREATE_SNMP_COMMUNITYSTRING_BUTTON_TEXT = "Create SNMP communities for SNMPv1";
	String CREATE_SNMPV3_BUTTON_USER = "Create SNMPv3 users";
	String SNMPV3_TRAP_BUTTON_RECEIVER = "Create SNMPv3 trap receivers";
	String CREATE_VACM_BUTTON = "Create View Access Control Models (VACM)";
	String ADDITIONAL_FIELDS = "//label[contains(text(),'Additional fields')]";
	String EDIT_ICON = "//span[@aria-expanded='true']/following-sibling::ul//li//a[contains(text(),'Edit')]";
	String PORT_CONFIG_LIST = "//div[@class='table my-table']/div[@class='tbody']/div[@name='form']/div[@class='td port']/span[2]";
	String ROW_IDENTIFIER_TABLE = "//div[@class='tr']//div[position()=1 and (contains(@class,'td'))]";
	String CREATE_MIRROR_BUTTON_TEXT = "Create Mirror";
	String CREATE_VFLOW_PLUS_SIGN = "span.fa.fa-plus-circle.icon-img-link";
	String CREATE_VFLOW_SAVE_BUTTON = "button.btn.btn-custom.btn-primary";
	String CREATE_PCAP_FETCH_BUTTON = "button.btn.btn-primary.btn-sm";
	String CREATE_PCAP_INTERFACE_LIST = "//div[@class='col-sm-9']//span[@class='help-block']";
	String CREATE_PCAP_SAVE_BUTTON = "button[class='btn btn-primary']";
	String ROW_IDENTIFIER_TABLE_VRouter = "//div[@class='tr']//div[position()=2 and (contains(@class,'td'))]";
	String UPLOAD_PCAP_BUTTON_TEXT = "Upload PCAP";
	String CREATE_VRF_BUTTON_TEXT = "Create vrf";
	String CREATE_SUBNET_BUTTON_TEXT = "Create subnet";
	String FORM_OK_BUTTON = "//button[text()='OK']";
	String CREATE_TUNNEL_BUTTON_TEXT = "Create a tunnel";
	String ADD_TUNNEL_VXLAN_BUTTON_TEXT = "Add a VXLAN to a tunnel";
	String CREATE_VLE_BUTTON_TEXT = "Create Virtual Link Extension";

}