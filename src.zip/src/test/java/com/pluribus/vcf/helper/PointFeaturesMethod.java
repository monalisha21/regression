package com.pluribus.vcf.helper;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestDataParser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.ManageBGP;
import com.pluribus.vcf.pagefactory.ManageCluster;
import com.pluribus.vcf.pagefactory.ManageLayer1;
import com.pluribus.vcf.pagefactory.ManageOSPF;
import com.pluribus.vcf.pagefactory.ManageSNMP;
import com.pluribus.vcf.pagefactory.ManageSubnet;
import com.pluribus.vcf.pagefactory.ManageSyslog;
import com.pluribus.vcf.pagefactory.ManageTunnel;
import com.pluribus.vcf.pagefactory.ManageVLE;
import com.pluribus.vcf.pagefactory.ManageVRF;
import com.pluribus.vcf.pagefactory.ManageVflow;
import com.pluribus.vcf.pagefactory.ManageVlag;
import com.pluribus.vcf.pagefactory.ManageVlan;
import com.pluribus.vcf.pagefactory.ManagevRouter;
import com.pluribus.vcf.pagefactory.ManageMirrors;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.PointFeatures;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.Trunks;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.AnalyticsFlowPage;
import com.pluribus.vcf.test.Layer1PointFeatures;
import com.pluribus.vcf.helper.JsonHelper;

public class PointFeaturesMethod extends PageInfra {
	com.pluribus.vcf.helper.TestDataParser parser;
	private static final Logger log = Logger.getLogger(PointFeaturesMethod.class);
	private NavigationMenu menu;
	private TopologyPage topology;
	private ManageLayer1 manageLayer1;
	private PointFeatures pf;
	private SwitchMethods switchCli;
	private ManageVlan manageVlan;
	private ManageVlag manageVlag;
	private Trunks trunkPage;
	private ManageCluster manageCluster;
	private ManagevRouter manageVrouter;
	private ManageOSPF manageOspf;
	private ManageBGP manageBgp;
	private ManageVflow manageVflow;
	private ManageSyslog manageSyslog;
	private ManageSNMP manageSnmp;
	private ManageMirrors manageMirror;
	private ManageVRF manageVrf;
	private ManageSubnet manageSubnet;
	private ManageTunnel manageTunnel;
	private ManageVLE manageVLE;
	private JsonHelper jsonHelper;
	private AnalyticsFlowPage analytics;

	public PointFeaturesMethod(WebDriver driver, String jsonFile) throws Exception {
		super(driver);
		pf = new PointFeatures(driver);
		parser = new TestDataParser(jsonFile);
		topology = new TopologyPage(driver);
		menu = new NavigationMenu(driver);
		manageLayer1 = new ManageLayer1(driver);
		manageVlan = new ManageVlan(driver);
		manageVlag = new ManageVlag(driver);
		trunkPage = new Trunks(driver);
		manageCluster = new ManageCluster(driver);
		manageVrouter = new ManagevRouter(driver);
		manageOspf = new ManageOSPF(driver);
		manageBgp = new ManageBGP(driver);
		manageVflow = new ManageVflow(driver);
		manageSyslog = new ManageSyslog(driver);
		manageSnmp = new ManageSNMP(driver);
		manageMirror = new ManageMirrors(driver);
		manageVrf = new ManageVRF(driver);
		manageSubnet = new ManageSubnet(driver);
		analytics = new AnalyticsFlowPage(driver);
		manageTunnel= new ManageTunnel(driver);
		manageVLE= new ManageVLE(driver);
		jsonHelper = new JsonHelper();
	}

	public void setupJsonData(String vcfIp, String fabricName, String vcfEth1Ip) {
		parser.updateJsonFile(vcfIp, fabricName, vcfEth1Ip);
	}

	public void setupJsonData(String vcfIp, String fabricName, String vcfEth1Ip, int cleanup) {
		parser.updateJsonFile(vcfIp, fabricName, vcfEth1Ip, cleanup);
	}

	public void setupJsonData() {
		parser.updateJsonFile();
	}

	public boolean generateEvents(String fabricName, String testTitle) throws InterruptedException {
		boolean status = true;
		pf.cleanPfSession();
		String switchName = parser.readTestData(testTitle, "switch");
		if (!stringNotNull(switchName)) {
			log.error("Test " + testTitle + " is missing mandatory key 'switch'. Aborting test.");
			return false;
		}
		try {
			switchCli = new SwitchMethods(switchName);
		} catch (Exception e) {
			log.error("Couldn't connect to switch" + switchName);
		}

		JSONArray commands = parser.readTestDataArray(testTitle, "commands");
		JSONArray events = parser.readTestDataArray(testTitle, "event_name");
		for (int i = 0; i < commands.length(); i++) {
			if (commands.getString(i) != "") {
				switchCli.executeSwitchCmd(commands.getString(i));
			}
			Thread.sleep(10000);
			if (verifyIADashboard(events.getString(i), 1)) {
				log.info("Verified SNMP event " + events.getString(i));
			} else {
				status = false;
			}
		}
		return status;
	}

	public boolean verifyIADashboard(String eventName, int expectedCount) {
		boolean status = true;
		int connCount = 0;
		if (menu.gotoNotifications("syslog")) {
			analytics.waitForAnalyticsConnectionPageLoad();
			analytics.removeFilters();
			analytics.applyFilter(eventName);
			try {
				Thread.sleep(15000); // Sleeping because sometimes it takes a few seconds for filter to take effect
				connCount = analytics.getTotalCount("Syslog - Total Count");
			} catch (Exception e) {
				switchToParent();
				log.error("Unable to get connection count on IA dashboard");
			}
		}
		if (connCount == expectedCount) {
			log.info("Expected count " + expectedCount + " matched GUI count " + connCount);
		} else {
			log.error("Expected count was " + expectedCount + " but GUI count " + connCount);
			status = false;
		}
		return status;
	}

	// Validation of test input and common test invocation method.
	public boolean executePfTests(String fabricName, String testTitle, String testType, String switchUser,
			String switchPwd) throws Exception {
		// First cleanup
		pf.cleanPfSession();
		String switchName = parser.readTestData(testTitle, "switch");
		if (!stringNotNull(switchName)) {
			topology.selectFabricInMenu(fabricName);
			log.info("Selected Fabric " + fabricName);
		} else {
			try {
				switchCli = new SwitchMethods(switchName);
			} catch (Exception e) {
				log.error("Couldn't connect to switch" + switchName);
			}
			Thread.sleep(5000);
			topology.selectSwitchInMenu(switchName, fabricName);
			log.info("Selected switch " + switchName);
		}
		String navMenu = parser.readTestData(testTitle, "nav_menu");
		if (!stringNotNull(navMenu)) {
			log.error("Test input is missing mandatory key 'nav_menu'. Aborting test.");
			return false;
		}
		String[] menuNames = navMenu.split("->");
		Thread.sleep(5000);
		menu.gotoMenu(menuNames[0], menuNames[1], menuNames[2]);
		log.info("Navigated to menu " + menuNames[0] + "->" + menuNames[1] + "->" + menuNames[2]);
		String buttonName = parser.readTestData(testTitle, "button_name");
		if (!stringNotNull(buttonName)) {
			log.error("Test input is missing mandatory key 'button_name'. Aborting test.");
			return false;
		}
		String[] formInputs = parser.readFormInputs(testTitle, "form_inputs");

		if (formInputs == null) {
			log.error("Test input is missing mandatory array 'form_inputs'. Aborting test.");
			return false;
		} else {
			log.info("Test details");
			log.info(Arrays.toString(formInputs));
		}
		String[] formValues = parser.readFormValues(testTitle, formInputs, "form_inputs");
		log.info(Arrays.toString(formValues));
		Thread.sleep(5000);
		if (testType.equals("PortConfig")) {
			if (!manageLayer1.executeEditPortConfigCommands(buttonName, formInputs, formValues)) {
				log.error("execute edit Port_Config Test failed");
				return false;
			}
		} else if (testType.equals("vlan")) {
			if (!manageVlan.executeVlanCommands(buttonName, formInputs, formValues)) {
				log.error("executeVlanTest failed");
				return false;
			}
		} else if (testType.equals("vlag")) {
			if (!manageVlag.executeVlagCommands(buttonName, formInputs, formValues)) {
				log.error("executeVlagTest failed");
				return false;
			}
		} else if (testType.equals("trunk")) {
			if (!trunkPage.executeTrunkCommands(buttonName, formInputs, formValues)) {
				log.error("execute trunk test failed");
				return false;
			}
		} else if (testType.equals("cluster")) {
			if (!manageCluster.executeClusterCommands(buttonName, formInputs, formValues)) {
				log.error("executeCluster test failed");
				return false;
			}
			try {
				Thread.sleep(20000); // Sleep 20 seconds before cli validation
			} catch (Exception e) {
				log.error("Sleeping for cli validation failed");
			}
		} else if (testType.equals("vrouter")) {
			if (!manageVrouter.executeVrouterCommands(buttonName, formInputs, formValues)) {
				log.error("execute vRouter tests failed");
				return false;
			}
		} else if (testType.equals("ospf")) {
			if (!manageOspf.executeOspfCommands(buttonName, formInputs, formValues)) {
				log.error("execute OSPF tests failed");
				return false;
			}
		} else if (testType.equals("bgp")) {
			if (!manageBgp.executeBgpCommands(buttonName, formInputs, formValues)) {
				log.error("execute BGP tests failed");
				return false;
			}
		} else if (testType.equals("vflow")) {
			if (!manageVflow.executeVflowCommands(buttonName, formInputs, formValues)) {
				log.error("executeVflowTest failed");
				return false;
			}
		} else if (testType.equals("Syslog")) {
			if (!manageSyslog.executeSyslogCommands(buttonName, formInputs, formValues)) {
				log.error("executeSyslogTest failed");
				return false;
			}

		} else if (testType.equals("LogEvent")) {
			if (!manageSyslog.executeLogEventsCommands(buttonName, formInputs, formValues)) {
				log.error("execute LogEvent Test failed");
				return false;
			}
		} else if (testType.equals("SNMP")) {
			if (!manageSnmp.executeSNMPStringCommands(buttonName, formInputs, formValues)) {
				log.error("executeSNMPV3Test failed");
				return false;
			}

		} else if (testType.equals("SNMP Trap Enable/Disable")) {
			if (!manageSnmp.executeSNMPEnableTrapCommands(buttonName, formInputs, formValues)) {
				log.error("execute LogEvent Test failed");
				return false;
			}
		} else if (testType.equals("Mirror")) {
			if (!manageMirror.executeMirrorCommands(buttonName, formInputs, formValues)) {
				log.error("execute mirror test failed");
				return false;
			}
		} else if (testType.equals("Pcap")) {
			if (!manageMirror.executeMirrorCommands(buttonName, formInputs, formValues)) {
				log.error("execute Pcap test failed");
				return false;
			}
		} else if (testType.equals("vrf")) {
			if (!manageVrf.executeVRFCommands(buttonName, formInputs, formValues)) {
				log.error("execute vrf test failed");
				return false;
			}
		} else if (testType.equals("subnet")) {
			if (!manageSubnet.executeSubnetCommands(buttonName, formInputs, formValues)) {
				log.error("execute subnet test failed");
				return false;
			}
		}else if (testType.equals("tunnel")) {
			if (!manageTunnel.executeTunnelCommands(buttonName, formInputs, formValues)) {
				log.error("execute tunnel test failed");
				return false;
			}
		}else if (testType.equals("vle")) {
			if (!manageVLE.executeVLECommands(buttonName, formInputs, formValues)) {
				log.error("execute vle test failed");
				return false;
			}
		}
		if (!executeCliVerification(testTitle, switchUser, switchPwd)) {
			return false;
		}
		menu.gotoMenu("Overview", "Overview", "Topology");
		return true;
	}

	public boolean executeCliVerification(String testTitle, String userName, String password) throws Exception {
		boolean status = true;
		String[] cli_input = parser.readCli(testTitle);
		log.info(cli_input);
		try {
			Thread.sleep(10000); // Sleep 10 seconds before cli validation
		} catch (Exception e) {
			log.error("Sleeping for cli validation failed");
		}
		if (cli_input != null) {
			JSONArray guiJson = pf.extractGuiJson(cli_input[0], cli_input[3]);
			log.info("JSON from GUI:" + guiJson.toString());
			HashMap cliHash = jsonHelper.getSwitchHttpResult(cli_input[1], cli_input[2], userName, password);
			JSONArray cliJsonArr = new JSONArray();
			if (cliHash.get("status").toString().equals("200")) {
				cliJsonArr = new JSONArray(cliHash.get("data").toString());
				cliJsonArr = pf.processJson(cliJsonArr);
				log.info("JSON from CLI:" + cliJsonArr.toString());
				if (jsonHelper.assertTwoJsons(guiJson, cliJsonArr)) {
					log.info("CLI validation succeeded");
				} else {
					log.error("JSONs did not match. CLI validation failed");
					status = false;
				}
			} else {
				log.info(guiJson);
				if (guiJson.length() == 0) {
					log.info("CLI validation succeeded");
				} else {
					log.error("JSONs did not match. CLI validation failed");
					status = false;
				}
			}
		}

		return status;
	}

}