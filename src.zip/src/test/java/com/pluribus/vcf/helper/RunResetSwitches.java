package com.pluribus.vcf.helper;

import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.jcabi.ssh.SSHByPassword;
import com.jcabi.ssh.Shell;
import com.pluribus.vcf.helper.SwitchMethods;
import org.apache.log4j.Logger;

public class RunResetSwitches extends TestSetup implements Runnable {
	private static SwitchMethods switchAccess;
	private static String switchName;
	private static final Logger log = Logger.getLogger(RunResetSwitches.class);

	public RunResetSwitches(SwitchMethods switchAccess, String switchName) throws IOException {
		this.switchName = switchName;
		this.switchAccess = switchAccess;
	}

	public boolean resetSwitch() throws Exception {
		boolean status = true;
		if(!switchAccess.resetSwitch()) {
			status = false;
		}
		return status;
	}

	public void run() {
		try {
			if(!resetSwitch()) {
				throw new Exception("Reset switch failed");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}