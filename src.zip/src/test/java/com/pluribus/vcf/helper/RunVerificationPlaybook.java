package com.pluribus.vcf.helper;

import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.jcabi.ssh.SSHByPassword;
import com.jcabi.ssh.Shell;
import org.apache.log4j.Logger;

public class RunVerificationPlaybook extends TestSetup implements Runnable {
	private static String vcfIp;
	private static String playbookYml;
	private static String playbookPy;
	private static String vcfPassword;
	private static String playbookName;
	private static String hostFile;
	private static String csvFile;
	private SshClient sshSession;
	private String switchUserName = "network-admin";
	private String switchPassword = "test123";
	private static final Logger log = Logger.getLogger(RunVerificationPlaybook.class);

	public RunVerificationPlaybook(String vcfIp, String playbookYml, String playbookPy, String verifPlaybook,
			String vcfPassword, String ansHosts, String csvFile) throws IOException {
		this.vcfIp = vcfIp;
		this.playbookYml = playbookYml;
		this.playbookPy = playbookPy;
		this.hostFile = ansHosts;
		this.csvFile = csvFile;
		this.vcfPassword = vcfPassword;
		this.playbookName = verifPlaybook;
	}
	
    /*Function copyToDocker
     * Argument 1: Pass comma separated list of files or a single file 
     * Argument 2: Destination path on docker (vcf-mgr) to which file will be copied
     * Argument 3: Name of docker container
     * Argument 4 (Optional): Specify a folder to create in /tmp and in destination path. If there are many files, 
     * a folder should be specified. If it is a single file, we can copy by the file name
     */
	public boolean copyToDocker(String fileList, String destPath, String dockerContainer, String folderName)
			throws Exception {
		boolean status = true;
		String[] files;
		File fileToCopy = null;

		if (fileList.contains(",")) {
			files = new String[10];
			files = fileList.split(",");
		} else {
			files = new String[1];
			files[0] = fileList;
		}

		String tmpCommand = "sshpass -p " + vcfPassword + " scp -r -o StrictHostKeyChecking=no ";
		for (int loopCount = 0; loopCount < files.length; loopCount++) {
			fileToCopy = new File(files[loopCount]);
			tmpCommand += fileToCopy + " ";
		}

		tmpCommand += " vcf@" + vcfIp + ":/tmp/" + folderName;
		String dockerCmd = "sshpass -p " + vcfPassword + " ssh -o StrictHostKeyChecking=no vcf@" + vcfIp;
		if (!folderName.equals("")) {
			dockerCmd += " docker cp /tmp/" + folderName + " " + dockerContainer + ":" + destPath;
		} else {
			for (int loopCount = 0; loopCount < files.length; loopCount++) {
				fileToCopy = new File(files[loopCount]);
				dockerCmd = "sshpass -p " + vcfPassword + " ssh -o StrictHostKeyChecking=no vcf@" + vcfIp
						+ " docker cp ";
				dockerCmd = dockerCmd + "/tmp/" + fileToCopy.getName() + " " + dockerContainer + ":" + destPath;
				if (!executeRuntimeProcess(dockerCmd)) {
					log.error("Copying to " + destPath + " failed");
					status = false;
				}
			}
		}

		if (!folderName.equals("")) {
			String createFile = "sshpass -p " + vcfPassword + " ssh -o StrictHostKeyChecking=no vcf@" + vcfIp
					+ " mkdir /tmp/" + folderName;
			if (!executeRuntimeProcess(createFile)) {
				log.error("Creating /tmp/" + folderName + " in VM " + vcfIp + " failed");
			}
		}

		if (!executeRuntimeProcess(tmpCommand)) {
			log.error("Copying to /tmp failed");
			status = false;
		}

		if (!executeRuntimeProcess(dockerCmd)) {
			log.error("Copying to " + destPath + " failed");
			status = false;
		}

		if (!folderName.equals("")) {
			String removeFile = "sshpass -p " + vcfPassword + " ssh -o StrictHostKeyChecking=no vcf@" + vcfIp
					+ " rm -rf /tmp/" + folderName;
			if (!executeRuntimeProcess(removeFile)) {
				log.error("Deleting /tmp/" + folderName + " from VM " + vcfIp + " failed");
			}
		}
		return status;
	}

	public boolean copyFiles() throws Exception {
		boolean status = true;
		String dockerName = "vcf-mgr";
		String folderName = "test";

		if (!copyToDocker(playbookYml, "/opt/vcf-mgr/ansible/playbooks", dockerName, folderName)) {
			return false;
		}
		if (!copyToDocker(playbookPy, "/opt/vcf-mgr/ansible/modules", dockerName, "")) {
			return false;
		}
		if (!copyToDocker(hostFile, "/opt/vcf-mgr/ansible/data/", dockerName, "")) {
			return false;
		}
		if (!copyToDocker(csvFile, "/opt/vcf-mgr/ansible/data/", dockerName, "")) {
			return false;
		}
		return status;
	}

	public boolean executeRuntimeProcess(String runtimeCmd) throws IOException {
		boolean status = true;
		int loopCount = 0;
		while (loopCount < 5) {
			status = true;
			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec(runtimeCmd);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

			String line;
			while ((line = stdError.readLine()) != null) {
				log.info("Retrying copy due to failure:" + line);
				loopCount++;
				status = false;
			}
			if (status = true) {
				break;
			}
		}
		return status;
	}

	public boolean runVerifPlaybook() throws Exception {
		// Shell sh1 = getVcfShell(vcfIp);
		if (!startSshConnection(vcfIp, "vcf", vcfPassword)) {
			log.error("Unable to SSH into VM: " + vcfIp);
			throw new Exception("SSH into VM " + vcfIp + " failed");
		}
		sshSession = getSshConnection();
		boolean status = true;
		File host = new File(hostFile);
		String runPlaybookCmd = "docker  exec -i vcf-mgr ansible-playbook -i /opt/vcf-mgr/ansible/data/"
				+ host.getName() + " /opt/vcf-mgr/ansible/playbooks/test/" + playbookName + " -e " + "ansible_user="
				+ switchUserName + " -e ansible_ssh_pass=" + switchPassword + " --tags=test-only";
		String out1 = sshSession.execCmd(runPlaybookCmd);
		log.info(out1);
		int loopCount = 0;

		while ((out1.contains("Connection reset by peer")) && (loopCount < 5)) {
			log.info("Retrying playbook execution");
			out1 = sshSession.execCmd(runPlaybookCmd);
			log.info(out1);
			loopCount++;
		}

		if (out1.contains("ok=0") || out1.contains("" + '"' + "ok" + '"' + ": 0")) {
			status = false;
			log.error("ok count is 0 : Playbook " + playbookName + " was not Verified successfully");
		} else {
			if (out1.contains("failed=0") || out1.contains("" + '"' + "failures" + '"' + ": 0")) {
				log.info("ok count is not 0 & failed count is 0 : Playbook " + playbookName
						+ " was Verified successfully");
			} else {
				status = false;
				log.error("Failed count is not 0: Playbook " + playbookName + " was not Verified successfully");
			}
		}
		return status;
	}

	public void run() {
		try {
			if (copyFiles()) {
				log.info("Copying files for playbook run succeeded");
				if (runVerifPlaybook()) {
					log.info("Verification playbook passed");
				} else {
					log.error("Verification playbook failed");
					throw new Exception("Verification playbook " + playbookName + " failed");
				}
			} else {
				throw new Exception("Copying files for playbook " + playbookName + " failed");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}