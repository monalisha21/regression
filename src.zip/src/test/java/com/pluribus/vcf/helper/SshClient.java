package com.pluribus.vcf.helper;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import net.sf.expectit.Expect;
import net.sf.expectit.ExpectBuilder;

public class SshClient {

	Session session = null;
	private static final Logger log = Logger.getLogger(SshClient.class);

	// Its used to connect switches by ssh, dont forgot to close session
	public Session establishConnection(String ip, String user, String pwd) throws JSchException {
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		session = new JSch().getSession(user, ip, 22);
		session.setPassword(pwd);
		session.setConfig(config);
		session.connect();
		log.info("The session has been established to " + ip);
		return session;
	}

	public String execCmd(String command) {

		StringBuilder outputBuffer = new StringBuilder();
		log.info(session.getHost() + " $ " + command);

		try {
			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			InputStream commandOutput = channel.getInputStream();
			channel.connect();
			int readByte = commandOutput.read();

			while (readByte != 0xffffffff) {
				outputBuffer.append((char) readByte);
				readByte = commandOutput.read();
			}
			channel.disconnect();
		} catch (IOException ioX) {
			log.error(ioX.getMessage());
			return null;
		} catch (JSchException jschX) {
			log.error(jschX.getMessage());
			return null;
		}
		return outputBuffer.toString();
	}

	public void closeSession() {
		session.disconnect();
	}

	public Expect expect() throws IOException, JSchException {

		Channel channel = session.openChannel("shell");
		channel.connect();

		Expect expect = new ExpectBuilder().withOutput(channel.getOutputStream())
				.withInputs(channel.getInputStream(), channel.getExtInputStream()).build();

		return expect;
	}

	public Expect exeShelCmd(Expect expect, String input) throws IOException {
		expect.send(input);
		return expect;

	}

	public Expect exeShelCmd(Expect expect, String input, String action) throws IOException {
		expect.sendLine(input);
		return expect;

	}

}