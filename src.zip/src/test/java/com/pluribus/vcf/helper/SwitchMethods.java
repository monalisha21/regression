/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/
package com.pluribus.vcf.helper;

import java.io.IOException;
import org.apache.log4j.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

public class SwitchMethods {
	private String switchUser = "root";
	private String switchPwd = "test123";
	private String switchName;
	SshClient sshHelper;
	private static final Logger log = Logger.getLogger(SwitchMethods.class);

	public SwitchMethods(String switchName) throws Exception {
		this.switchName = switchName;
		sshHelper = new SshClient();
		try {
			sshHelper.establishConnection(switchName, switchUser, switchPwd);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// Workaround for bug 15007
	public void restartTomcat() {
		try {
			sshHelper.execCmd("admin-service-modify if mgmt no-web\"");
			Thread.sleep(20000);
			sshHelper.execCmd("admin-service-modify if data no-web\"");
			Thread.sleep(20000);
			sshHelper.execCmd("admin-service-modify if mgmt web\"");
			Thread.sleep(20000); // Sleeping as tomcat takes 1 min to start
		} catch (Exception e) {
			log.error("Tomcat restart failed" + e);
		}
	}

	public boolean resetSwitch() {
		String switchOp = null;
		boolean status = true;
		int retryCount = 0;
		int EULA_RESET_RETRY_COUNT = 3;

		try {
			// Reset switches
			switchOp = sshHelper.execCmd("nvos-reset.ksh -z -y");
			if ((!switchOp.contains("nvOS reset complete, restart recommended")) || (switchOp == null)) {
				log.error("Output is: " + switchOp);
				log.error("Switch reset failed");
				status = false;
			}
			if (!checkNvosdStatus()) {
				log.error("nvOSd is not up during switch reset");
				return false;
			}
			switchOp = sshHelper.execCmd("service svc-nvOSd restart");
			if (!checkNvosdStatus()) {
				log.error("nvOSd is not up during switch reset");
				return false;
			}
			retryCount = 0;
			while (retryCount < EULA_RESET_RETRY_COUNT) {
				switchOp = sshHelper.execCmd(
						"cli --quiet --script-password switch-setup-modify password test123 eula-accepted true");
				if (switchOp.contains("Setup completed successfully")) {
					status = true;
					break;
				} else {
					status = false;
					retryCount++;
				}
			}
		} catch (Exception e) {
			log.error(e);
		}
		return status;
	}

	public boolean configSwitchName(String switchName) {
		boolean status = true;
		String switchOp = sshHelper.execCmd(convertToCliCmd("switch-setup-modify switch-name " + switchName));
		if (!switchOp.contains("Setup completed successfully")) {
			status = false;
		}
		return status;
	}

	public boolean checkNvosdStatus() {
		boolean status = false;
		int retryCount = 0;
		int maxRetryCount = 1000;
		String switchOp = sshHelper.execCmd("service svc-nvOSd status");
		while (retryCount < maxRetryCount) {
			switchOp = sshHelper.execCmd("service svc-nvOSd status");
			retryCount++;
			if (switchOp.contains("online") || (switchOp.contains("active (running)"))) {
				status = true;
				break;
			}
		}
		return status;
	}

	public boolean createFabric(String fabName) {
		String out1;
		boolean status = true;
		try {
			out1 = sshHelper.execCmd(convertToCliCmd("fabric-node-show"));
			if (!out1.contains("fabric-node-show: Not joined to fabric")) {
				out1 = sshHelper.execCmd(convertToCliCmd("fabric-create name " + fabName + " fabric-network mgmt"));
				if ((out1 == null) || (!out1.contains("Fabric " + fabName + " created"))) {
					log.error("Output is: " + out1);
					log.error("Fabric creation failed");
					status = false;
				}
			}
			Thread.sleep(15000);
		} catch (Exception e) {
			log.error("createFabric " + e.toString());
		}
		return status;
	}

	public boolean joinFabric(String fabricName) {
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("fabric-join name " + fabricName));
			if ((switchOp == null) || (!switchOp.contains("Joined fabric " + fabricName + ". Restarting nvOS.."))) {
				log.error("Output is: " + switchOp);
				log.error("Fabric join failed");
				status = false;
			}
			Thread.sleep(15000);
		} catch (Exception e) {
			log.error("joinFabric " + e.toString());
		}
		return status;
	}

	public boolean clusterConfig(String switchName2, String clusterName) {
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("cluster-create name " + clusterName + " cluster-node-1 "
					+ this.switchName + " cluster-node-2 " + switchName2));
			if ((switchOp == null) || (!switchOp.equals(""))) {
				log.error("Output is: " + switchOp);
				log.error("Create cluster failed");
				status = false;
			}
		} catch (Exception e) {
			log.error("clusterConfig " + e.toString());
			status = false;
		}
		return status;
	}

	public boolean vlagCreate(String vlagName, int portNum, int peerPort) {
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("vlag-create name " + vlagName + " port " + portNum
					+ " peer-port " + peerPort + " mode active-active lacp-mode active"));
			if ((switchOp == null) || (!switchOp.equals(""))) {
				log.error("Output is: " + switchOp);
				log.error("Create VLAG failed");
				status = false;
			}
		} catch (Exception e) {
			log.error("vlagCreate " + e.toString());
			status = false;
		}
		return status;
	}

	public boolean createUntaggedPorts(int vlanId, int portNum) {
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper
					.execCmd(convertToCliCmd("vlan-port-add vlan-id " + vlanId + " untagged ports " + portNum));
			if ((switchOp == null) || (!switchOp.contains("Ports added"))) {
				log.error("Output is: " + switchOp);
				log.error("Add untagged ports failed");
				status = false;
			}
		} catch (Exception e) {
			log.error("createUntaggedPorts " + e.toString());
			status = false;
		}
		return status;
	}

	public boolean vlanCreate(int vlanId) {
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(
					convertToCliCmd("vlan-create id " + vlanId + " description vlan-" + vlanId + " scope fabric"));
			if (switchOp == null) {
				log.error("Output is: " + switchOp);
				log.error("VLAN create failed");
				status = false;
			}
		} catch (Exception e) {
			log.error("vlanCreate" + e.toString());
			status = false;
		}
		return status;
	}

	public boolean vrouterCreate(String fabricName, int vrrpId) {
		String vnetName = fabricName + "-global";
		String vrouterName = switchName + "-vrouter";
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("vrouter-create name " + vrouterName + " vnet " + vnetName
					+ " router-type hardware hw-vrrp-id " + vrrpId));
			if ((switchOp == null) || (!switchOp.contains("vrouter created"))) {
				log.error("Output is: " + switchOp);
				log.error("Vrouter creation failed");
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean vrouterCreate(String fabricName) {
		String vnetName = fabricName + "-global";
		String vrouterName = switchName + "-vrouter";
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("vrouter-create name " + vrouterName + " vnet " + vnetName));
			if ((switchOp == null) || (!switchOp.contains("vrouter created"))) {
				log.error("Output is: " + switchOp);
				log.error("Vrouter creation failed");
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean vrouterIfCreate(String ipAddr, String ipAddr2, int vlanId, int vrrpId, int vrrpPriority) {
		String vrouterName = switchName + "-vrouter";
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd(
					"vrouter-interface-add vrouter-name " + vrouterName + " ip " + ipAddr + " vlan " + vlanId));
			if ((switchOp == null) || (!switchOp.contains("Added interface"))) {
				log.error("Vrouter creation failed");
				status = false;
			} else {
				String[] ifName = switchOp.split(" ");
				switchOp = sshHelper.execCmd(convertToCliCmd("vrouter-interface-add vrouter-name " + vrouterName
						+ " ip " + ipAddr2 + " vlan " + vlanId + " vrrp-id " + vrrpId + " vrrp-primary " + ifName[2]
						+ " vrrp-priority " + vrrpPriority));
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean vrouterIfCreate(String ipAddr, int l3Port) {
		boolean status = vrouterIfCreate(ipAddr, l3Port, -1);
		return status;
	}

	public boolean vrouterIfCreate(String ipAddr, int l3Port, int vlan) {
		String vrouterName = switchName + "-vrouter";
		String switchOp = null;
		boolean status = true;
		try {
			if (vlan != -1) {
				switchOp = sshHelper.execCmd(convertToCliCmd("vrouter-interface-add vrouter-name " + vrouterName
						+ " ip " + ipAddr + " l3-port " + l3Port + " vlan " + vlan));
			} else {
				switchOp = sshHelper.execCmd(convertToCliCmd(
						"vrouter-interface-add vrouter-name " + vrouterName + " ip " + ipAddr + " l3-port " + l3Port));
			}
			if ((switchOp == null) || (!switchOp.contains("Added interface"))) {
				log.error("Vrouter interface creation failed");
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public String getVrouterNic(String vrouterName, String ipAddr, int l3Port) {
		String nic = null;
		String switchOp = sshHelper.execCmd(convertToCliCmd(
				"vrouter-interface-show vrouter-name " + vrouterName + " l3-port " + l3Port + " format nic"));
		if (switchOp.contains(vrouterName)) {
			String line = switchOp.split("\n")[2];
			nic = line.split(" ")[1];
		}
		return nic;
	}

	public boolean vrouterIfDelete(String ipAddr, int l3Port) {
		boolean status = true;
		String switchOp = null;
		String vrouterName = switchName + "-vrouter";
		String nic = getVrouterNic(vrouterName, ipAddr, l3Port);
		try {
			if (nic != null) {
				switchOp = sshHelper.execCmd(
						convertToCliCmd("vrouter-interface-remove vrouter-name " + vrouterName + " nic " + nic));
				if (!switchOp.contains("")) {
					status = false;
				}
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean configOspf(String network, int area) {
		String vrouterName = switchName + "-vrouter";
		String switchOp = null;
		boolean status = true;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd(
					"vrouter-ospf-add vrouter-name " + vrouterName + " network " + network + " ospf-area " + area));
			if ((switchOp == null) || (!switchOp.equals(""))) {
				log.error("OSPF configuration failed");
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean enableWeb() {
		boolean status = true;
		String switchOp = null;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("admin-service-modify if mgmt web"));
			if (!checkWeb()) {
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public boolean deleteSnmp(String switchName) {
		boolean status = true;
		String switchOp = null;
		try {
			ArrayList<String> snmpCommunities = getSnmpCommunities(switchName);
			for (int count = 0; count < snmpCommunities.size(); count++) {
				switchOp = sshHelper.execCmd(
						convertToCliCmd("snmp-community-delete community-string " + snmpCommunities.get(count)));
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	private ArrayList getSnmpCommunities(String switchName) {
		String switchOp = sshHelper.execCmd(convertToCliCmd("switch-local snmp-community-show"));
		ArrayList<String> snmpCommunities = new ArrayList<>();
		if (!switchOp.equals("")) {
			String[] snmpOp = switchOp.split("\n");
			int i = 0;
			for (String s : snmpOp) {
				String[] commString = s.split(" ");
				if (commString[0].contains(switchName)) {
					snmpCommunities.add(commString[1].trim());
				}
			}
		}
		return snmpCommunities;
	}

	private boolean checkWeb() {
		boolean status = true;
		String switchOp = null;
		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("switch-local admin-service-show"));
			if (switchOp.contains("mgmt off")) {
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
		return status;
	}

	public String executeSwitchCmd(String command) {
		String switchOp = sshHelper.execCmd(convertToCliCmd(command));
		return switchOp;
	}

	private String convertToCliCmd(String cmd) {
		return "cli --no-login-prompt --quiet -c '" + cmd + "' -e";
	}

	public int getCountByTag(String tagValue) throws IOException {
		int tagCount = 0;
		String out1 = sshHelper
				.execCmd(convertToCliCmd("connection-show limit-output 100000 count-output cur-state " + tagValue));
		String[] connLines = out1.split("\n");
		for (int x = 0; x < connLines.length; x++) {
			if (connLines[x].contains(tagValue)) {
				tagCount += 1;
			}
		}
		return tagCount;
	}

	public int getCountByValue(String tagValue) throws IOException {
		int tagCount = 0;
		String out1 = sshHelper
				.execCmd(convertToCliCmd("connection-show limit-output 100000 count-output | grep " + tagValue));
		String[] connLines = out1.split("\n");
		for (int x = 0; x < connLines.length; x++) {
			if (connLines[x].contains(tagValue)) {
				tagCount += 1;
			}
		}
		return tagCount;
	}

	public long getCountBytes() throws IOException {
		long count = 0;
		String out1 = sshHelper.execCmd(
				convertToCliCmd("client-server-stats-show no-show-headers raw-int-values unscaled format total-bytes"));
		String[] connLines = out1.split("\n");
		for (String value : connLines) {
			log.info(value + "=value count=" + count);
			value = value.trim();
			if (value != "" && value != null && !value.isEmpty() && value.chars().allMatch(Character::isDigit))
				count += Long.parseLong(value.trim());
		}
		return count;
	}

	public int getCountByClientServerTag(String clientIp, String serverIp, String tagValue) throws IOException {
		int tagCount = 0;
		String out1 = sshHelper.execCmd(convertToCliCmd(
				"connection-show src-ip " + clientIp + " dst-ip " + serverIp + " cur-state " + tagValue));
		String[] connLines = out1.split("\n");
		for (int x = 0; x < connLines.length; x++) {
			if (connLines[x].contains(tagValue)) {
				tagCount += 1;
			}
		}
		return tagCount;
	}

	public boolean validateCommand(String command, boolean present, String value) {
		boolean status = true;
		try {
			String cliOutput = sshHelper.execCmd(convertToCliCmd(command));
			log.info(cliOutput);
			if (present == false && cliOutput.contains(value)) {
				log.error("Expected not to find " + value + " but found it in CLI output (below)");
				log.error("CLI output of command " + command + "is: " + cliOutput);
				status = false;
			}

			if (present == true && (!cliOutput.contains(value))) {
				log.error("Expected to find " + value + " but did not find it in CLI output (below)");
				log.error("CLI output of command " + command + "is: " + cliOutput);
				status = false;
			}
		} catch (Exception e) {
			log.error(e.toString());
			status = false;
		}
		if (status == true) {
			log.info("CLI validation succeeded");
		}
		return status;
	}

	public String[] getCLIPortlist(String SwitchName) {
		String out1 = sshHelper
				.execCmd(convertToCliCmd("switch " + SwitchName + " port-config-show format port no-show-headers"));

		String[] portLines = out1.split("\n");
		int i = 0;
		for (String s : portLines) {
			portLines[i] = s.trim();
			i++;
		}
		return portLines;
	}

	public String getConfiguredInterfaceIp(String interfaceName) {
		String ipAddr = sshHelper
				.execCmd("ip addr show dev " + interfaceName + " | grep inet | awk 'NR == 1 {print $2}'");
		ipAddr = ipAddr.replace("\n", "");
		return ipAddr;
	}

	public void configureBondInterface(String bondIf, String slaveIf1, String slaveIf2) {
		String switchOp = sshHelper.execCmd("modprobe bonding mode=4");
		switchOp = sshHelper.execCmd("ifconfig " + bondIf + " 0 up");
		String ipAddr = getConfiguredInterfaceIp(slaveIf1);
		if (!ipAddr.equals("")) {
			switchOp = sshHelper.execCmd("ip addr del " + ipAddr + " dev " + slaveIf1);
		}
		switchOp = sshHelper.execCmd("ifenslave bond0 " + slaveIf1 + " " + slaveIf2);
	}

	public void deleteBondIf(String bondIfName) {
		sshHelper.execCmd("ifconfig " + bondIfName + " down");
		sshHelper.execCmd("modprobe -r bonding");
	}

	public void modifyInterfaceIp(String ifName, String ipAddress) {
		String existingIp = getConfiguredInterfaceIp(ifName);
		if (!existingIp.equals("")) {
			sshHelper.execCmd("ip addr del " + existingIp + " dev " + ifName);
		}
		sshHelper.execCmd("ifconfig " + ifName + " " + ipAddress + " up");
	}

	public void addStaticRouteHost(String ipAddr, String nhIp, String ifName) {
		sshHelper.execCmd("ip route add " + ipAddr + " via " + nhIp + " dev " + ifName);
	}

	public boolean addStaticRoute(String fabricName, String networkIp, String gatewayIp) {
		String vrouterName = switchName + "-vrouter";
		boolean status = true;
		String switchOp = sshHelper.execCmd(convertToCliCmd("vrouter-static-route-add vrouter-name " + vrouterName
				+ " network " + networkIp + " gateway-ip " + gatewayIp));
		if (!switchOp.equals("")) {
			status = false;
		}
		return status;
	}

	public void exitSession() {
		sshHelper.closeSession();
	}

	public boolean vlanCreate(int vlanId, String ports, String scope) {
		String switchOp = null;
		boolean status = true;

		try {
			switchOp = sshHelper.execCmd(convertToCliCmd("vlan-create id " + vlanId + " description vlan-" + vlanId
					+ " scope " + scope + " ports " + ports));
			if (switchOp == null) {
				log.error("Output is: " + switchOp);
				log.error("VLAN create failed");
				status = false;
			}
		} catch (Exception e) {
			log.error("vlanCreate" + e.toString());
			status = false;
		}
		return status;
	}

	public int terminalCount(String cmd) {

		int terminalCount = 0;
		String out = sshHelper.execCmd(convertToCliCmd(cmd));
		Pattern pattern = Pattern.compile("Count: (\\d+)", Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher(out);
		if (m.find()) {
			terminalCount = Integer.parseInt(m.group(1).trim());
			log.info("Terminal count is " + terminalCount);
		}
		return terminalCount;

	}
}