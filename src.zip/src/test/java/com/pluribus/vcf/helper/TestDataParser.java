package com.pluribus.vcf.helper;

import java.io.StringReader;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class TestDataParser {
	private static String testFileName;
	private static JSONArray jsonArr;
	private static JSONObject jsonObj;
	private static int MAX_FORM_INPUT_SIZE = 20;

	public TestDataParser(String testFile) throws Exception {
		File testDataFile = new File(testFile);
		if (!testDataFile.exists()) {
			throw new Exception("testFile " + testFile + " does not exist");
		} else {
			testFileName = testFile;
		}
	}

	public void updateJsonFile(String vcfIp, String fabricName, String vcfEth1Ip) {
		String jsonData = populateVarsInJson(vcfIp, fabricName, vcfEth1Ip);
		writeFile(testFileName, jsonData);
		populateGlobalJson();
	}

	public void updateJsonFile(String vcfIp, String fabricName, String vcfEth1Ip, int cleanup) {
		String jsonData = populateVarsInJson(vcfIp, fabricName, vcfEth1Ip, cleanup);
		writeFile(testFileName, jsonData);
	}

	public void updateJsonFile() {
		populateGlobalJson();
	}

	private static void populateGlobalJson() {
		String jsonData = readFile(testFileName);
		jsonObj = new JSONObject(jsonData);
		jsonArr = jsonObj.getJSONArray("tests");
	}

	public String populateVarsInJson (String vcfIp, String fabricName, String vcfEth1Ip, int cleanup) {
		String jsonData = readFile(testFileName);
		if(cleanup == 0) {
			jsonData = jsonData.replaceAll("\\$vcfIp",vcfIp);
			jsonData = jsonData.replaceAll("\\$fabricName",fabricName);
			jsonData = jsonData.replaceAll("\\$vcfEth1Ip",vcfEth1Ip);
		} else {
			jsonData = jsonData.replaceAll(vcfIp,"\\$vcfIp");
			jsonData = jsonData.replaceAll(fabricName,"\\$fabricName");
			jsonData = jsonData.replaceAll(vcfEth1Ip,"\\$vcfEth1Ip");
		}
		return jsonData;
	}

	public String populateVarsInJson (String vcfIp, String fabricName, String vcfEth1Ip) {
		return populateVarsInJson(vcfIp, fabricName, vcfEth1Ip, 0);
	}

	public int getNumberTests() {
		return jsonArr.length();
	}

	public int getTestIndex(String testTitle) {
		int testArrIndex = -1;
		for (int i = 0; i < jsonArr.length(); i++) {
			JSONObject jsonObjName = jsonArr.getJSONObject(i);
			if (jsonObjName.keySet().contains("test_name")) {
				if (jsonObjName.getString("test_name").equals(testTitle)) {
					testArrIndex = i;
					break;
				}
			}
		}
		return testArrIndex;
	}

	public String readTestData(String testTitle, String fieldName) {
		String testData = null;
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains(fieldName)) {
				testData = item.getString(fieldName);
			}
		}
		return testData;
	}

	public JSONArray readTestDataArray(String testTitle, String fieldName) {
		JSONArray testData = new JSONArray();
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains(fieldName)) {
				testData = item.getJSONArray(fieldName);
			}
		}
		return testData;
	}

	public String readNavTitle(String testTitle) {
		String navMenu = null;
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains("nav_menu")) {
				navMenu = item.getString("nav_menu");
			}
		}
		return navMenu;
	}

	public String readSwitch(String testTitle) {
		String switchName = null;
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains("switch")) {
				switchName = item.getString("switch");
			}
		}
		return switchName;
	}

	public String readButtonName(String testTitle) {
		String buttonName = null;
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains("button_name")) {
				buttonName = item.getString("button_name");
			}
		}
		return buttonName;
	}

	public String[] readFormInputs(String testTitle, String fieldName) {
		String[] keys = new String[MAX_FORM_INPUT_SIZE];
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains(fieldName)) {
				JSONObject formInputs = item.getJSONObject(fieldName);
				keys = JSONObject.getNames(formInputs);
			}
		}
		return keys;
	}

	public String[] readFormValues(String testTitle, String[] keys, String fieldName) {
		String[] values = new String[MAX_FORM_INPUT_SIZE];
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			for (int ctr = 0; ctr < keys.length; ctr++) {
				JSONObject formInputs = item.getJSONObject(fieldName);
				values[ctr] = formInputs.getString(keys[ctr]);
			}
			values = Arrays.copyOf(values, keys.length);
		}
		return values;
	}

	public String[] readCli(String testTitle) {
		String[] cliCommand = new String[4];
		int testIdx = getTestIndex(testTitle);
		if (testIdx != -1) {
			JSONObject item = jsonArr.getJSONObject(testIdx);
			if (item.keySet().contains("cli")) {
				if (item.has("cli") && (!item.getString("cli").equals(""))) {
					cliCommand[0] = item.getString("cli");
				} else {
					cliCommand[0] = null;
				}
				cliCommand[1] = item.getString("cli_ip");
				cliCommand[2] = item.getString("cli_getRequest");
				if (item.has("cli_selectElement")) {
					cliCommand[3] = item.getString("cli_selectElement");
				} else {
					cliCommand[3] = null;
				}
			} else {
				return null;
			}
		}
		return cliCommand;
	}

	public static String readFile(String filename) {
		String result = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			result = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static void writeFile(String filename, String newContent) {
		try {
			FileWriter writer = new FileWriter(filename);
			JSONObject jsonObjPrint = new JSONObject(newContent);
			writer.write(jsonObjPrint.toString(2));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
