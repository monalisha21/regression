/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/
package com.pluribus.vcf.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import com.browserstack.local.Local;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pluribus.vcf.helper.JsonHelper;

/**
 *
 * @author Haritha, Poornima
 */
public class TestSetup {
	private RemoteWebDriver driver;
	private ResourceBundle bundle;
	Local bsLocal = new Local();
	private String localId;
	private String imageName;
	private JsonHelper jsonHelper;
	private static String exactFileName;
	private static String getVersion = "/vcf-center/api/application";
	private static String getRestApi = "/vRest/admin-services";
	private static final Logger log = Logger.getLogger(TestSetup.class);
	private SshClient sshSession;
	private static int SESSION_TIMEOUT = 300;
	/*
	 * This method will be invoked if VCFC upgrade is desired before test run.
	 */
	@Parameters({ "vcfIp", "upgrade", "imageNameUpgrade", "imageUrl", "vcfUserName", "vcfFirstLoginPassword", "vcfPassword", "clean" })
	@BeforeSuite(alwaysRun = true)
	public boolean upgradeVCFC(String vcfIp, @Optional("0") String upgrade, @Optional("") String imageNameUpgrade,
			@Optional("") String imageUrl, @Optional("admin") String vcfUserName,
			@Optional("admin") String vcfFirstLoginPassword, @Optional("test123") String vcfPassword,
			@Optional("1") String clean) throws Exception {
		imageName = imageNameUpgrade;
		boolean upgradeStatus = true;
		String result;
		if (Integer.parseInt(upgrade) == 1) {
			if (Integer.parseInt(clean) == 1) {
				result = getCurlResult(vcfIp, getVersion, vcfUserName, vcfFirstLoginPassword);
			} else {
				result = getCurlResult(vcfIp, getVersion, vcfUserName, vcfPassword);
			}
			String getLatestBuildNumber = result.toString().substring(1, result.length() - 1);
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> obj = mapper.readValue(getLatestBuildNumber, Map.class);
			String latestVcfcVersion = obj.get("version").toString();
			String latestBuildNumber = obj.get("build-number").toString();
			if (!imageNameUpgrade
					.substring(StringUtils.ordinalIndexOf(imageName, "-", 1) + 1,
							StringUtils.ordinalIndexOf(imageNameUpgrade, "-", 2))
					.matches(latestVcfcVersion.substring(0, StringUtils.ordinalIndexOf(latestVcfcVersion, "-", 1)))
					|| !imageNameUpgrade
							.substring(StringUtils.ordinalIndexOf(imageNameUpgrade, "-", 3) + 1,
									StringUtils.ordinalIndexOf(imageNameUpgrade, ".tgz", 1))
							.matches(latestBuildNumber)) {
				String out1;
				String wgetOutput = sshSession.execCmd("rm -rf /srv/docker/offline_images/*;cd /srv/docker/offline_images;wget " + imageUrl);
				if (wgetOutput.contains("ERROR 404: Not Found")) {
					log.error("Couldn't download image " + imageNameUpgrade + " from URL:" + imageUrl);
					upgradeStatus = false;
					throw new Exception("Image upgrade failed");
				}
				if (upgradeStatus == true) {
					out1 = sshSession.execCmd("/home/vcf/UNUM_setup.sh upgrade " + imageNameUpgrade);
					log.info(out1);
					if(!out1.contains("Upgrade completed successfully")) {
						log.error("Loading image "+ imageNameUpgrade + " failed");
						upgradeStatus = false;
						throw new Exception("Image upgrade failed");
					}
					Thread.sleep(30000);
				}
			} else {
				log.info("Image is already upgraded to the Latest Version");
			}
		}
		return upgradeStatus;
	}

	/*
	 * This method is usually invoked unless user overrides it with clean=0 in
	 * arguments with mvn clean test It deletes config files such as pcap-agent,
	 * pcap-engine, vcf-center properties, seed switch, username, license etc.
	 * This is run so that the user starts with a clean VM. If this isn't
	 * desired, then test class should be modified to use admin/new Password for
	 * login instead of admin/admin.
	 */
	@Parameters({ "vcfIp", "clean", "imageType", "vcfUserName", "vcfPassword" })
	@BeforeSuite(alwaysRun = true)
	public boolean resetUnum(String vcfIp, @Optional("1") String clean, @Optional("test") String imageType,
			@Optional("vcf") String vcfUserName, @Optional("changeme") String vcfPassword)
			throws Exception {
		boolean status = true;
		if (!startSshConnection(vcfIp, vcfUserName, vcfPassword)) {
			log.error("Unable to SSH into VM: " + vcfIp);
			status = false;
			throw new Exception("SSH into VM " + vcfIp + " failed");
		}
		if (Integer.parseInt(clean) == 1) {
			String path = "/home/vcf/srv/vcf/bin/reset-unum.sh";
			log.info(sshSession.execCmd(path + " -y"));
			Thread.sleep(2 * 60000);
		}
		if (!startSshConnection(vcfIp, vcfUserName, vcfPassword)) {
			log.error("Unable to SSH into VM: " + vcfIp);
			status = false;
			throw new Exception("SSH into VM " + vcfIp + " failed");
		}
		return status;
	}

	public String getEth1IpAddr(String vcfIp, String vcfUserName, String vcfPassword) throws Exception{
			String eth1Ip = null;
			if (!startSshConnection(vcfIp, vcfUserName, vcfPassword)) {
				log.error("Unable to SSH into VM: " + vcfIp);
				throw new Exception("SSH into VM " + vcfIp + " failed");
			} else {
				System.out.println(sshSession);
				eth1Ip = sshSession.execCmd("ifconfig eth1 | awk '/inet addr/ {gsub(\"addr:\", \"\", $2); print $2}'");
				sshSession.closeSession();
			}
			return eth1Ip.trim();
	}

	public boolean startSshConnection(String vmIp, String vmUser, String vmPwd) {
		sshSession = new SshClient();
		try {
			sshSession.establishConnection(vmIp, vmUser, vmPwd);
		} catch (Exception e) {
			log.error(e.getMessage());
			return false;
		}
		return true;
	}

	public SshClient getSshConnection() {
		return sshSession;
	}

	// To get Switch Details
	public static List<Map<String, Object>> getSwitchDetailFromHostFile(String hostFile) throws IOException {
		List<Map<String, Object>> hostSwitchDetails = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> spineSwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> leafSwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> thirdPartySwitch = new LinkedList<Map<String, Object>>();
		List<Map<String, Object>> normalSwitch = new LinkedList<Map<String, Object>>();
		try (BufferedReader br = new BufferedReader(new FileReader(new File(hostFile)));) {
			String line = null;
			String switchType = null;
			while ((line = br.readLine()) != null) {
				line = line.trim();
				Pattern pattern = Pattern.compile("(\\[)(.*)(\\])");
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					switchType = matcher.group(2);
				}
				Map<String, Object> switchMap = parseStringIntoSwitchDetail(line, switchType);
				if (switchMap == null || switchMap.isEmpty()) {
					continue;
				}
				if (("spine").equalsIgnoreCase(switchType)) {
					spineSwitch.add(switchMap);
				} else if (("leaf").equalsIgnoreCase(switchType)) {
					leafSwitch.add(switchMap);
				} else if (("third_party_spine").equalsIgnoreCase(switchType)) {
					thirdPartySwitch.add(switchMap);
				} else if (("switch").equalsIgnoreCase(switchType)) {
					normalSwitch.add(switchMap);
				}
			}
			hostSwitchDetails.addAll(spineSwitch);
			hostSwitchDetails.addAll(leafSwitch);
			hostSwitchDetails.addAll(thirdPartySwitch);
			hostSwitchDetails.addAll(normalSwitch);
		}
		return hostSwitchDetails;
	}

	public static Map<String, Object> parseStringIntoSwitchDetail(String line, String switchType) {
		Map<String, Object> switchMap = null;
		if (line.trim().length() > 0 && !line.startsWith("#") && !line.matches("\\[.*\\]")) {
			switchMap = new LinkedHashMap<String, Object>();
			String[] splitLine = line.split(" ");
			switchMap.put("switchName", splitLine[0]);
			switchMap.put("host", splitLine[1].split("=")[1]);
			switchMap.put("switchType", switchType);
		}
		return switchMap;
	}

	// To check REST API of switch
	public void checkRestApiOfSwitch(String vcfIp, String hostFile, String switchUserName, String password)
			throws IOException, InterruptedException {
		List<Map<String, Object>> result = getSwitchDetailFromHostFile(hostFile);
		String out1;
		for (Map<String, Object> obj : result) {
			String switchIp = obj.get("host").toString();
			try {
				out1 = StringUtils.substringBetween(getCurlResult(switchIp, getRestApi, switchUserName, password), "[",
						"]");
				ObjectMapper mapper2 = new ObjectMapper();
				Map<String, Object> obj2 = mapper2.readValue(out1, Map.class);
				boolean web = (boolean) obj2.get("web");
				if (web == true) {
					log.info("REST API is already Enabled on Switch : " + switchIp);
				}
			} catch (Exception e) {
				log.info("Enabling REST API on Switch : " + switchIp);
				String out2 = sshSession.execCmd("admin-service-modify if mgmt web");
				Thread.sleep(60000);
				out1 = getCurlResult(switchIp, getRestApi, switchUserName, password);
				log.info("REST API Sucessfully Enabled in Switch : " + switchIp);
			}
		}
	}

	// To check network-admin login
	public void checkNetworkAdminLogin(String hostFile, String switchUserName, String rootUserName, String password)
			throws IOException, InterruptedException {
		List<Map<String, Object>> result = getSwitchDetailFromHostFile(hostFile);
		for (Map<String, Object> obj : result) {
			String switchIp = obj.get("host").toString();
			try {
				sshSession.execCmd("exit");
				log.info("network-admin Login Successful on Switch : " + switchIp);
			} catch (Exception e) {
				log.info("network-admin Login was not Successful on Switch : " + switchIp);
				log.info("Exception Occured : " + e);
				String out1 = sshSession.execCmd(
						"cli --quiet --script-password switch-setup-modify password test123 eula-accepted true");
				Thread.sleep(60000);
				if (out1.toString().contains("Setup completed successfully")) {
					log.info("EULA Accepted and network-admin Login setup Successful on Switch : " + switchIp);
				}
			}
		}
	}

	public String getCurlResult(String ip, String getRequest, String userName, String pass) throws IOException {
		String command = "";
		if (!getRequest.contains("vRest")) {
			command = "curl --user " + userName + ":" + pass + " https://" + ip + getRequest + " -k --silent";
			return sshSession.execCmd(command);
		} else {
			command = sshSession.execCmd("curl --user " + userName + ":" + pass + " " + ip + getRequest + " --silent");
			return sshSession.execCmd(command);
		}
	}

	/*
	 * This is the method that starts the WebDriver either with browserstack or
	 * local based on the "local" argument value Mandatory argument: vcfIp,
	 * browser (Name of browser: "chrome", "firefox") etc. For local runs only
	 * chrome is supported now. Optional arguments: local, bsUserId, bsKey,
	 * jenkins Note: if jenkins plugin is used, handling is a little different
	 * from the other runs. jenkins = 1 is set by all jobs that run scripts from
	 * jenkins. End of Note.
	 */
	@Parameters({ "vcfIp", "browser", "local", "bsUserId", "bsKey", "jenkins" })
	@BeforeClass(alwaysRun = true)
	public void initDriver(String vcfIp, String browser, @Optional("0") String local, String bsUserId, String bsKey,
			@Optional("0") String jenkins) throws Exception {
		if (Integer.parseInt(local) == 1) {
			startDriver(vcfIp, browser);
		} else {
			startDriver(vcfIp, browser, bsUserId, bsKey, Integer.parseInt(jenkins));
		}
	}

	public void startDriver(String vcfIp, String browserName) {
		String os = System.getProperty("os.name").toLowerCase();
		String chrDriver = null;

		if (os.contains("win")) {
			chrDriver = "src/test/resources/chromedriver_win.exe";
		} else if (os.contains("mac")) {
			chrDriver = "src/test/resources/chromedriver_mac";
		} else if (os.contains("linux")) {
			chrDriver = "src/test/resources/chromedriver_linux64";
		}

		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", chrDriver);
			DesiredCapabilities chromeCaps = DesiredCapabilities.chrome();
			chromeCaps.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
			chromeCaps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			driver = new ChromeDriver(chromeCaps);
			driver.manage().timeouts().implicitlyWait(SESSION_TIMEOUT, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get("https:" + vcfIp);
		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "src/test/resources/geckodriver");
			DesiredCapabilities caps = DesiredCapabilities.firefox();
			caps.setCapability("marionette", true);
			caps.setCapability("acceptInsecureCerts", true);
			// var capabilities = new FirefoxOptions().addTo(caps);
			driver = new FirefoxDriver(caps);
			driver.get("https:" + vcfIp);
		}
		// TODO: ADD Firefox, IE AND SAFARI TO THE LIST
	}

	public void startDriver(String vcfIp, String browser, String bsUserId, String bsKey, int jenkins) throws Exception {
		String sessionId = null;
		String command = null;
		HashMap<String, String> bsLocalArgs = new HashMap<String, String>();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
		String dateAsString = simpleDateFormat.format(new Date());
		String localId = "convergenceTest" + dateAsString;
		if (jenkins == 0) {
			bsLocalArgs.put("localIdentifier", localId); // environment variable
			bsLocalArgs.put("key", bsKey); // BrowserStack Key
			bsLocalArgs.put("v", "true");
			bsLocal.start(bsLocalArgs);
		}

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("browser", browser);
		caps.setCapability("build", "VCFC SmokeTest Cases");
		caps.setCapability("acceptSslCerts", "true");
		caps.setCapability("acceptInsecureCerts", true);
		caps.setCapability("browserstack.debug", "true");
		caps.setCapability("browserstack.idleTimeout", "150");
	    //caps.setCapability("platform", "ANY");
		caps.setCapability("os", "Windows");
		caps.setCapability("os_version", "10");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browserstack.console", "verbose");
		if (browser.equalsIgnoreCase("firefox")) {
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			firefoxProfile.setPreference("security.tls.insecure_fallback_hosts", false);
			firefoxProfile.setAcceptUntrustedCertificates(true);
			caps.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
			caps.setCapability("browser_version", "54");
		}
		if (browser.equalsIgnoreCase("chrome")) {
			caps.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
		}
		if (jenkins == 0) {
			caps.setCapability("browserstack.local", "true");
			caps.setCapability("browserstack.localIdentifier", localId);
		} else {
			String browserstackLocal = System.getenv("BROWSERSTACK_LOCAL");
			String browserstackLocalIdentifier = System.getenv("BROWSERSTACK_LOCAL_IDENTIFIER");
			caps.setCapability("browserstack.local", browserstackLocal);
			caps.setCapability("browserstack.localIdentifier", browserstackLocalIdentifier);
		}
		driver = new RemoteWebDriver(
				new URL("https://" + bsUserId + ":" + bsKey + "@hub-cloud.browserstack.com/wd/hub"), caps);
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		// Get a handle to the driver.
		try {
			driver.get("https://" + vcfIp);
		} catch (Exception e) {
			log.error("Unable to open connection to " + vcfIp);
		}
		log.info("Browserstack logs:"+getBSLogs(bsUserId, bsKey));
	}

	/*
	 * This method is invoked when a browserstack session is created to retrieve
	 * and print out link to the logs in the console output.
	 *
	 */
	public String getBSLogs(String bsUserId, String bsKey) {
		String publicUrl = null;
		jsonHelper = new JsonHelper();
		String sessId = driver.getSessionId().toString();
		String request = "/automate/sessions/"+sessId+".json";
		HashMap httpJson = new HashMap();

		do {
			httpJson = jsonHelper.getBrowserStackHttpResult("browserstack.com", request, bsUserId, bsKey);
		} while(!httpJson.get("status").toString().equals("200"));

		if (httpJson.get("status").toString().equals("200")) {
			JSONObject jsonObject = new JSONObject(httpJson.get("data").toString());
			publicUrl = jsonObject.get("public_url").toString();
		}
		return publicUrl;
	}

	@Parameters({ "jenkins", "vcfIp" })
	@AfterClass(alwaysRun = true)
	public void setupAfterSuite(@Optional("0") String jenkins, String vcfIp) {
		log.info("Cleaning up session after testclass");
		try {
			driver.quit();
			if (Integer.parseInt(jenkins) == 0) {
				bsLocal.stop();
			}
		} catch (Exception e) {
			log.error("Driver already closed");
		}
	}

	@Parameters({ "vcfIp", "vcfUserName", "vcfPassword" })
	@AfterSuite(alwaysRun = true)
	public void saveLogs(String vcfIp,@Optional("vcf") String vcfUserName, @Optional("changeme") String vcfPassword) {
		try {
			if (!startSshConnection(vcfIp, vcfUserName, vcfPassword)) {
				log.error("Cannot save vcf-mgr logs on VM: " + vcfIp);
			}
	        String saveLogsOut = sshSession.execCmd("cat /home/vcf/var/vcf/logs/vcf-mgr.log >> /tmp/vcf-mgr-reg.log");
	        sshSession.closeSession();
		} catch (Exception e) {
			log.error("Cannot save vcf-mgr logs");
		}
	}

	public void keepSessionActive() {
		try {
			Thread.sleep(SESSION_TIMEOUT);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			getCurrentUrl();
	}

	public boolean isContainsText(String text) {
		return driver.getPageSource().contains(text);
	}

	public ResourceBundle getBundle() {
		return bundle;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public String getPageSource() {
		return driver.getPageSource();
	}

	public void pageRefresh() {
		driver.navigate().refresh();
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public void clickOnBody() {
		driver.findElement(By.xpath("//body")).click();
	}

	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public String isRequired(String field) {
		String isrequired = getBundle().getString("errors.required").replace("{0}", field);
		return isrequired;
	}

	public String matchPattern(String field) {
		String isrequired = getBundle().getString("errors.required").replace("{0}", field);
		return isrequired;
	}
}
