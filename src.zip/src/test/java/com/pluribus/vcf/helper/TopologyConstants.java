package com.pluribus.vcf.helper;

// VCF Manager Fabric Constants use to store all css and xpath.

public interface TopologyConstants {
	String MGMT_IP = "//div[@class='tr']/div[2]/span";
	String IN_BAND_IP = "//div[@class='tr']/div[3]/span";
	String STATE = "//div[@class='tr']/div[4]/discovery-status/div/span/span";
	String DISCOVERY_STATUS_ONLINE = "//span[@class='fa fa-circle good']";
	String TOPOLOGY_SWITCH_LIST = "//*[@class='nodename']";
	String SWITCH_NAME_TOOL_TIP = "//div[contains(@class, 'd3-node-tooltip')]";
	String CLOSE_FABRIC_DETAILS_WINDOW = "in-window-close";
	String FABRIC_LIST = "//span[@uib-tooltip='";
	String LICENSE_DETAILS_TAB = "//uib-tab-heading[text()='License']";
	String SOFTWARE_DETAILS_TAB = "//uib-tab-heading[text()='Software']";
	String HARDWARE_DETAILS_TAB = "//uib-tab-heading[text()='Hardware']";
	String GENRAL_DETAILS_TAB = "//uib-tab-heading[text()='General']";
	String TRANSCEIVERS_DETAILS_TAB = "//uib-tab-heading[text()='Transceivers']";
	String ROWS_COUNT_FOR_JSON_ARRAY = "//div[@class='tab-pane active']/div/div/div[@class='tbody']/div[@class='tr']";
	String KEYS_FOR_JSON_ARRAY = "//div[@class='tab-pane active']/div/div/div[@class='tbody']/div[1]/div[@class='th']";
	String VALUES_FOR_JSON_ARRAY1 = "//div[@class='tab-pane active']/div/div/div[@class='tbody']/div[";
	String VALUES_FOR_JSON_ARRAY2 = "]/div[@class='td']";
	String KEYS_FOR_JSON = "//div[@class='tab-pane active']/div/table/tbody/tr/td[1]";
	String VALUES_FOR_JSON = "//div[@class='tab-pane active']/div/table/tbody/tr/td[2]";
	String PLURIBUS_WAIT_ICON = "span.pluribus-loading-spinner";
	String DISCOVERY_STATUS_POP_UP = "//div[@class='modal-content']";
	String DISCOVERY_POP_UP_CLOSE_BUTTON = "button.btn.btn-warning.cancel";
	String DISCOVERY_POP_UP_STATUS_HEADER = "//div[@class='tbody']/div/div/span/div[contains(@class, 'status-heading')]";
	String DISCOVERY_POP_UP_COUNT = "//div[@class='tbody']/div/div/span/div[contains(@class, 'status-text')]";
	String DISCOVERY_POP_UP_GREEN_STATUS = "#4cbb17";
}
