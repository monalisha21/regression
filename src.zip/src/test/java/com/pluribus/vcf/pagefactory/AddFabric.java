package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.FabricConstants.*;
import com.pluribus.vcf.helper.PageInfra;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class AddFabric extends PageInfra {

	private static final Logger log = Logger.getLogger(AddFabric.class);
	private static int switchCount;

	public AddFabric(WebDriver driver) {
		super(driver);
	}

	public boolean fabricCreation(String[] fileNameList, String password, String CollectorName, String gatewayIp,
			String inbandIp, String playbookName) throws Exception {
		try {
			waitForElementToClick(By.cssSelector(ADD_FABRIC));
			clickOnWebElement(By.cssSelector(ADD_FABRIC));
			String hostFile = fileNameList[0].toString();
			List<Map<String, Object>> noOfSwitchesInHostFile = getSwitchDetailFromHostFile(hostFile);
			switchCount = noOfSwitchesInHostFile.size();
			if (switchCount == 6) {
				waitForElementToClick(By.cssSelector(FABRIC_DIALOG_ADD_6_NODE_PLAYBOOK));
				clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ADD_6_NODE_PLAYBOOK));
			} else {
				waitForElementToClick(By.cssSelector(FABRIC_DIALOG_ADD_2_NODE_PLAYBOOK));
				clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ADD_2_NODE_PLAYBOOK));
			}
			waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_FABRIC_NAME));
			WebElement fabricName = driver.findElement(By.cssSelector(FABRIC_DIALOG_FABRIC_NAME));
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
			String dateAsString = simpleDateFormat.format(new Date());
			setValue(fabricName, CollectorName + dateAsString);
			fileUploadsForNonInputElements(fileNameList);
			setValue(driver.findElement(By.name(FABRIC_DIALOG_USERAME)), "network-admin");
			setValue(driver.findElement(By.name(FABRIC_DIALOG_PASSWORD)), password);
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			// Changing spines to third party spines keeping same host file as normal 6 node
			// to execute third party playbooks
			if (playbookName.contains("with existing spines")) {
				waitForElementVisibilityLocatedBy(driver.findElement(By.xpath(FABRIC_DIALOG_THIRD_PARTY_SWITCH1)));
				clickOnWebElement(By.xpath(FABRIC_DIALOG_THIRD_PARTY_SWITCH1));
				clickOnWebElement(By.xpath(FABRIC_DIALOG_THIRD_PARTY_SWITCH2));
				waitForElementToClick(By.xpath(FABRIC_DIALOG_SAVE_BUTTON));
				clickOnWebElement(By.xpath(FABRIC_DIALOG_SAVE_BUTTON));
			}
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			selectElement(driver.findElement(By.cssSelector(FABRIC_DIALOG_TOGGLE_40G)), "False");
			if (noOfSwitchesInHostFile.size() == 6) {
				setValue(driver.findElement(By.cssSelector(FABRIC_DIALOG_GATEWAY_IP)), gatewayIp);
			}
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ACCEPT_LICENSE));
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_RESET_FABRIC_CHK_BOX));
			// Setting inband ip and resetting Leafs to execute third party playbooks
			if (playbookName.contains("with existing spines")) {
				waitForElementToClick(By.xpath(INBAND_IP));
				clickOnWebElement(By.xpath(INBAND_IP));
				setValue(driver.findElement(By.xpath(INBAND_IP)), inbandIp);
				waitForElementToClick(By.xpath(FABRIC_DIALOG_RESET_FABRIC_DROPDOWN));
				clickOnWebElement(By.xpath(FABRIC_DIALOG_RESET_FABRIC_DROPDOWN));
				waitForElementToClick(By.xpath(FABRIC_DIALOG_RESET_FABRIC_DROPDOWN));
				selectElement(By.xpath(FABRIC_DIALOG_RESET_FABRIC_DROPDOWN),
						"Leafs : Mostly used for Existing  spine playbooks");
			}
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
			waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
			waitForElementToClick(By.xpath(FABRIC_LEFT_PANE_FABRIC_NAME + CollectorName + "')]"));
			clickOnWebElement(By.xpath(FABRIC_LEFT_PANE_FABRIC_NAME + CollectorName + "')]"));
			waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DETAILS_PANEL));

			if (isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))) {
				String message = driver.findElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN)).getText();
				log.error("playbookConfig failed with error: " + message);
				return false;
			}
			// Start Fabric Creation
			boolean successMessageFound = true;
			log.info("Fabric Start");
			log.info("Waiting for fabric reset / creation to be completed");
			while (!isElementActive(By.cssSelector(FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN))
					&& !isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))) {

				try {
					if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
						log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
						waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
					}
					if (isElementActive(By.xpath(NOTIFICATION_POP_UP_CLOSE_BUTTON))) {
						clickOnWebElement(By.xpath(NOTIFICATION_POP_UP_CLOSE_BUTTON));
					}
					if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
						if (driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText().contains("Server Error") ||
							driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText().contains("Error in device discovery")) {
							String message = driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText();
							log.error("playbookConfig " + message);
							waitForInvisibilityOfElementLocated(By.cssSelector(ERROR_NOTIFICATION));
							successMessageFound = false;
							break;
						}
					}
				} catch (StaleElementReferenceException e) {
				} catch (NoSuchElementException e) {
				} catch (Exception e) {
					log.error(e);
				}
			}

			if (isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))
					&& isElementActive(By.cssSelector(FABRIC_SUCCESS_DIALOG))) {
				String message = driver.findElement(By.cssSelector(FABRIC_SUCCESS_DIALOG)).getText();
				log.error("playbookConfig " + message);
				clickOnWebElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
				waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
				successMessageFound = false;
			}
			log.info("Fabric End");

			if (successMessageFound == false) {
				log.error("Fabric reset/discovery failed");
				return false;
			}
			Thread.sleep(30000); // Wait to allow the success messages to be displayed
			return true;
		} catch (Exception e) {
			log.error("Exception in Fabric Creation : " + e);
			return false;
		}
	}

	// For Upload Playbook
	public boolean playbookExecution(String[] fileNameList, String playbookName) throws Exception {
		try {
			if (isElementActive(By.cssSelector(FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN))) {
				waitForElementToClick(By.cssSelector(FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN));
				String message = driver.findElement(By.cssSelector(FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN)).getText();
				log.info(message + " Button is visible");
				clickOnWebElement(driver.findElement(By.cssSelector(FABRIC_DIALOG_LAUNCH_PLAYBOOK_BTN)));
			}
			waitForElementToClick(findElementByText("a", playbookName));
			clickOnWebElement(findElementByText("a", playbookName));
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			// Avoid csv file upload for L2 with existing spines
			if (!playbookName.matches("L2 with existing spines")) {
				fileUploadsForNonInputElements(fileNameList);
			}
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
			waitForElementToClick(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
			if (switchCount < 6) {
				fileUploadsForNonInputElements(fileNameList);
			}
			clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
			waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_ADD_BTN));

			// Start Playbook Execution
			log.info("Playbook Start");
			boolean successMessageFound = false;
			log.info("Waiting for playbook " + playbookName + " execution to be completed");
			while (!isElementActive(By.cssSelector(FABRIC_SUCCESS_DIALOG))
					&& !isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))) {
				try {
					if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
						log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
						waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
					}
					if (isElementActive(By.xpath(NOTIFICATION_POP_UP_CLOSE_BUTTON))) {
						clickOnWebElement(By.xpath(NOTIFICATION_POP_UP_CLOSE_BUTTON));
					}
					if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
						if (driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText().contains("Server Error") ||
							driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText().contains("Error in device discovery")) {
							String message = driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText();
							log.error("playbookConfig " + message);
							waitForInvisibilityOfElementLocated(By.cssSelector(ERROR_NOTIFICATION));
							successMessageFound = false;
							break;
						}
					}
				} catch (StaleElementReferenceException e) {
				} catch (NoSuchElementException e) {
				} catch (Exception e) {
					log.error(e);
				}
			}

			if (isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))
					&& isElementActive(By.cssSelector(FABRIC_SUCCESS_DIALOG))) {
				String message = driver.findElement(By.cssSelector(FABRIC_SUCCESS_DIALOG)).getText();
				if (message.contains("Playbook scenario has been successfully deployed")) {
					log.info(message);
					clickOnWebElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
					waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
					successMessageFound = true;
				} else {
					log.error("playbookConfig " + message);
					clickOnWebElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
					waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
					successMessageFound = false;
				}
			}
			log.info("Playbook End");

			if (successMessageFound == false) {
				log.error("Playbook " + playbookName + " did not complete.");
				return successMessageFound;
			}
			Thread.sleep(30000); // Waiting for Map to be displayed on UI and Fabric Panel to be loaded with all elements
			return true;
		} catch (Exception e) {
			log.error("Exception in Playbook Execution : " + e);
			return false;
		}
	}
}