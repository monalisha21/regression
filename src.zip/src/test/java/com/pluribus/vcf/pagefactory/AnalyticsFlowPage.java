package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.AnalyticsConstants.*;
import static com.pluribus.vcf.helper.PointFeatureConstants.PLURIBUS_WAIT_ICON;
import java.io.IOException;
import java.nio.file.FileSystems;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.Keys;
import java.util.List;
import static com.pluribus.vcf.helper.PointFeatureConstants.MANAGE_FORM;

import com.pluribus.vcf.helper.AnalyticsMethods;
import com.pluribus.vcf.helper.PageInfra;

public class AnalyticsFlowPage extends PageInfra {
	private AnalyticsMethods anm;
	private static final Logger log = Logger.getLogger(AnalyticsFlowPage.class);

	public AnalyticsFlowPage(WebDriver driver) {
		super(driver);
	}

	public void applyFilter(String filterName) {
		setValue(By.cssSelector(SEARCH_BUTTON), filterName, Keys.ENTER);
		log.info("Applied " + filterName + " filter to dashboard");
	}

	public void removeFilters() {
		if (isElementActive(By.cssSelector(KIBANA_APPLIED_FILTER_LIST))) {
			if (isElementActive(By.cssSelector(FILTER_ACTION_LIST_HIDDEN))) {
				WebElement actionsLink = findElementByText("a", KIBANA_FILTER_ACTION_TEXT);
				clickOnWebElement(actionsLink);
			}
			WebElement removeFilter = findElementByText("a", KIBANA_REMOVE_FILTER_TEXT);
			clickOnWebElement(removeFilter);
			log.info("Removed filters on dashboard");
		} else {
			log.info("No filter to remove");
		}
	}

	public void waitForAnalyticsConnectionPageLoad() {
		waitForInvisibilityOfElementLocated(By.cssSelector(ANALYTICS_PLURIBUS_WAIT));
		frameToBeAvailable(By.xpath(COMMON_IFRAME_TAG));
		while (!isElementActive(By.xpath(KIBANA_ELEMENT))) {
		}
		waitForVisibilityOfElementLocated(By.xpath(KIBANA_ELEMENT));
	}

	public void waitForAnalyticsTrafficPageLoad() {
		frameToBeAvailable(By.xpath(COMMON_IFRAME_TAG));
		waitForInvisibilityOfElementLocated(By.cssSelector(ANALYTICS_PLURIBUS_WAIT));
		waitForVisibilityOfElementLocated(By.xpath(KIBANA_ELEMENT_BYTES));
		// driver.switchTo().defaultContent();
	}

	public int getTotalCount(String fieldName) throws InterruptedException {
		clickOnWebElement(By.xpath(ANALYTICS_REFRESH_BUTTON));
		clickOnWebElement(By.xpath(ANALYTICS_REFRESH_INTERVAL));
		String TOTAL_COUNT_SELECTOR = TOTAL_COUNT.replace("$FIELD", fieldName);
		int UICount = 0;
		for (int i = 0; i <= 600; i++) {
			UICount = Integer.parseInt(retryingFindGetText(By.xpath(TOTAL_COUNT_SELECTOR), 3));
			if (UICount != 0) {
				break;
			}
		}
		switchToParent();
		return (UICount);

	}

	public long getTotalBytesCountonUI() throws InterruptedException {
		clickOnWebElement(By.xpath(ANALYTICS_REFRESH_BUTTON));
		clickOnWebElement(By.xpath(ANALYTICS_REFRESH_INTERVAL));
		long UICount = 0;
		for (int i = 0; i <= 600; i++) {

			UICount = (Long
					.parseLong(((retryingFindGetText(By.xpath(ANALYTICS_TRAFFIC_TOTAL_CONNECTION_BYTES_COUNT), 3))
							.replaceAll(",", ""))));

			if (UICount != 0) {

				break;
			}
		}
		return (UICount);

	}

	public float getAverageLatencyCountonUI() {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// This will scroll the page till the element is found
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(By.xpath(ANALYTICS_AVERAGE_CONNECTION_LATENCY_MS)));
		Actions toolAct = new Actions(driver);
		toolAct.moveToElement(driver.findElement(By.xpath(ANALYTICS_AVERAGE_CONNECTION_LATENCY_MS))).build().perform();
		return (Float.parseFloat(
				(driver.findElement(By.xpath(ANALYTICS_AVERAGE_CONNECTION_LATENCY_TOOLTIP)).getText()).trim()));

	}

	public boolean trafficCountVerification(String filter, String switchName1)
			throws IOException, InterruptedException {

		anm = new AnalyticsMethods(switchName1);
		int UICount = getTotalCount("Insight - Connection Count");
		int TerminalCount = anm.getCountByClientServeronTerminal(filter);
		int delta = (int) (TerminalCount * 0.1);
		if (((TerminalCount - delta) < UICount && UICount < (TerminalCount + delta))) {
			log.info("Terminal count is " + TerminalCount + "UI Count is" + UICount);
			driver.switchTo().parentFrame();
			return true;
		} else {
			log.info("Terminal count is " + TerminalCount + "UI count is" + UICount);
			return false;
		}

	}

	public boolean trafficBytesCountVerification(String switchName1) throws IOException, InterruptedException {
		anm = new AnalyticsMethods(switchName1);
		long UIByteCount = getTotalBytesCountonUI();
		long TerminalTotalSumOfBytesCount = anm.getCountBytes();
		long delta = (long) (TerminalTotalSumOfBytesCount * 0.1);
		if (((TerminalTotalSumOfBytesCount - delta) < UIByteCount
				&& UIByteCount < (TerminalTotalSumOfBytesCount + delta))) {
			log.info("Terminal Count is" + TerminalTotalSumOfBytesCount + " UI count is" + UIByteCount);
			switchToParent();
			return true;
		} else {
			log.info("Terminal count is" + TerminalTotalSumOfBytesCount + "UI count is " + UIByteCount);
			switchToParent();
			return false;
		}
	}

	public boolean uploadAndCustomizeCustomTagFile(String fileName,String[] customizeFieldName) throws InterruptedException, IOException {
		if (isElementActive(By.cssSelector(ANALYTICS_PLURIBUS_WAIT))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ANALYTICS_PLURIBUS_WAIT));

		}
		retryingFindClick(By.xpath(CUSTOM_TAGS_UPLOAD_TAGS));
		log.info("upload tag button is clicked");
		if (fileName.contains("Invalid")) {
			return (uploadCustomTagFile(fileName));
		} else {
			if (uploadCustomTagFile(fileName)) {
				if (customizeTheDashBoard(customizeFieldName)) {
					return true;
				}

			}
		}
		return false;
	}

	public boolean customizeTheDashBoard(String[] fieldName) {
		retryingFindClick(By.xpath(CUSTOM_TAGS_CUSTOMIZE_DASHBOARD));
		log.info("Customize Tag button is clicked");
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		try {
			for (int i = 0; i < fieldName.length; i++) {

				clickOnWebElement(By.xpath("//*[@id=" + "'pieChart" + (i + 1) + "'" + "]"
						+ "/pie-chart-customizer/div/div[3]/div/select/option[@value=" + "'" + fieldName[i] + "']"));
			}
		} catch (Exception e) {
			return false;
		}
		clickOnWebElement(By.cssSelector(CUSTOM_TAGS_SAVE_BUTTON));
		if (isElementActive(By.cssSelector(ANALYTICS_PLURIBUS_WAIT))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ANALYTICS_PLURIBUS_WAIT));
		}
		return true;
	}

	public boolean validatetheCustomizedtag(String fileName) throws IOException, InterruptedException {
		int count = 0;
		for (int i = 1; i <= CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME.length; i++) {
			String fieldName = "//div/visualize[@data-title='Custom Pie Chart " + i + "']"
					+ "/div/div/div/div/div/div/*[name()='svg']/*[name()='g']/*[name()='path'][1]";
			if (!waitFortheElement(fieldName)) {
				break;
			}
			count++;
		}
		if (count == CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME.length) {
			log.info("all the 6 widgets are present on the dashboard");
			switchToParent();
			return true;
		}
		switchToParent();
		return false;
	}

	public boolean waitFortheElement(String fieldName) throws InterruptedException {
		int limit = 0;
		int attempt = 100;
		while (limit <= attempt) {
			if (isElementActive(By.xpath(fieldName))) {
				return true;
			}
			Thread.sleep(1000);
			limit++;
		}
		return false;

	}

	public boolean clearTag() {
		retryingFindClick(By.xpath(CUSTOM_TAGS_CLEAR_TAGS));
		log.info("Clear Tag button is clicked");
		waitForAnalyticsConnectionPageLoad();
		switchToParent();
		if (!validateClearTag(CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME)) {
			return false;
		}
		return true;

	}

	public boolean validateClearTag(String[] fieldName) {
		retryingFindClick(By.xpath(CUSTOM_TAGS_CUSTOMIZE_DASHBOARD));
		log.info("Customize Tag button is clicked");
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		for (int i = 0; i < fieldName.length; i++) {
			if (isElementActive(By.xpath("//*[@id=" + "'pieChart" + (i + 1) + "'" + "]"
					+ "/pie-chart-customizer/div/div[3]/div/select/option[@value=" + "'" + fieldName[i] + "']"))) {
				return false;
			}
		}
		clickOnWebElement(By.cssSelector(CUSTOM_TAGS_SAVE_BUTTON));
		if (isElementActive(By.cssSelector(ANALYTICS_PLURIBUS_WAIT))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ANALYTICS_PLURIBUS_WAIT));
		}
		return true;

	}

	public boolean uploadCustomTagFile(String fileName) {
		boolean status = false;
		if (uploadFile(fileName)) {
			try {
				clickOnWebElement(By.cssSelector(CUSTOM_TAGS_SAVE_BUTTON));
				if (fileName.contains("Invalid")) {
					while (!isElementActive(By.xpath(CUSTOM_TAGS_UPLOAD_ERROR_ALERT))) {
					}
					log.info(driver.findElement(By.xpath(CUSTOM_TAGS_UPLOAD_ERROR_ALERT)).getText());
					waitForInvisibilityOfElementLocated(By.xpath(CUSTOM_TAGS_UPLOAD_ERROR_ALERT));
					clickOnWebElement(By.cssSelector(CUSTOM_TAGS_CANCEL_BUTTON));
					status = true;
				} else {
					while (!isElementActive(By.xpath(CUSTOM_TAGS_UPLOAD_SUCESS_ALERT))) {
					}
					waitForInvisibilityOfElementLocated(By.xpath(CUSTOM_TAGS_UPLOAD_SUCESS_ALERT));
					log.info("File uploaded sucessfully");
					status = true;
				}
			} catch (Exception e) {
				log.error(e);
			}
		}
		return status;

	}
}