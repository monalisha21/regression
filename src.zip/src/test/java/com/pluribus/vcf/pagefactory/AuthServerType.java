package com.pluribus.vcf.pagefactory;

public enum AuthServerType {
	LDAP{public String toString(){return "ldap";}},
	AD{public String toString(){return "ad";}},

}
