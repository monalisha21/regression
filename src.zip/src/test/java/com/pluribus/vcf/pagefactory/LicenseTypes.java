package com.pluribus.vcf.pagefactory;

public enum LicenseTypes {
	IA_MOD_LIC{public String toString(){return "IA-MOD-LIC";}},
	UNUM_LIC{public String toString(){return "UNUM-LIC";}},
	UNUM_ALRT_LIC{public String toString(){return "UNUM-ALRT-LIC";}},
	UNUM_RPRT_LIC{public String toString(){return "UNUM-RPRT-LIC";}},
	VCFC_DEMO_100M{public String toString(){return "VCFC-DEMO-100M";}}
}
