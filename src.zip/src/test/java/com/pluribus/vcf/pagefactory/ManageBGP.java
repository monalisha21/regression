package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManageBGP extends PageInfra {
	private static final Logger log = Logger.getLogger(ManageBGP.class);
	private PointFeatures pf;

	public ManageBGP(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeBgpCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Add")) {
			if (!pf.addDelPorts(input_names, input_values, buttonName)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
				if (!deleteBgp(input_names, input_values)) {
					status = false;
				}
		} else if(buttonName.contains("Verify")) {
			status = true;
		}
		return status;
	}

	public boolean deleteBgp(String[] input_names, String[] input_values) {
		boolean status = true;
		int nameIndex = pf.selectFieldinDropDown("vrouter-name",input_names,input_values);
		int ipIndex = Arrays.asList(input_names).lastIndexOf("ip");
		String[] valueArray = new String[] {input_values[ipIndex]};
		if(!pf.delete(input_names, valueArray)) {
			status = false;
		}
		return status;
	}
}