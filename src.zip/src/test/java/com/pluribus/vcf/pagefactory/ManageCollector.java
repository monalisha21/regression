package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.CollectorConstants.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.pluribus.vcf.helper.PageInfra;

public class ManageCollector extends PageInfra {

	private static final Logger log = Logger.getLogger(ManageCollector.class);

	public ManageCollector(WebDriver driver) {
		super(driver);
	}

	public boolean stopCollector(String collectorName) {
		if (isCollectorRunning(collectorName)) {
			toggleCollector(collectorName);
			if (isElementActive(By.xpath(collectorName + COLLECTOR_MGMT_COLLECTOR_TOGGLE_ON_BTN))) {
				return false;
			} else {
				return true;
			}
		} else {
			log.info("Collector not running");
			return false;
		}
	}

	public boolean startCollector(String collectorName) {
		if (!isCollectorRunning(collectorName)) {
			toggleCollector(collectorName);
			if (isElementActive(By.xpath(collectorName + COLLECTOR_MGMT_COLLECTOR_TOGGLE_ON_BTN))) {
				return false;
			} else {
				return true;
			}
		} else {
			log.info("Collector is running");
			return false;
		}
	}

	public void waitForPageLoad() {
		waitForElementPresent(By.cssSelector(COLLECTOR_MGMT_COLLECTOR_LIST_TABLE));
	}

	public boolean isCollectorRunning(String collectorName) {
		try {
			String COLLECTOR_NAME = "//span[contains(text() , 'netvisor-collector-" + collectorName + "')]";
			waitForElementToClick(By.cssSelector(COLLECTOR_MGMT_COLLECTOR_TOGGLE_DIAL));
			if (isElementActive(By.xpath(COLLECTOR_NAME + COLLECTOR_MGMT_COLLECTOR_TOGGLE_ON_BTN))) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			log.error(e);
			return false;
		}
	}

	private boolean toggleCollector(String collectorName) {
		try {
			String COLLECTOR_NAME = "//span[contains(text() , 'netvisor-collector-" + collectorName + "')]";
			waitForElementVisibility(driver.findElement(By.xpath(COLLECTOR_NAME)));
			log.info("Starting collector is " + collectorName);
			clickOnWebElement(By.xpath(COLLECTOR_NAME + COLLECTOR_MGMT_COLLECTOR_TOGGLE));
			waitForElementVisibility(driver.findElement(By.xpath(COLLECTOR_MGMT_START_COLLECTOR_OK_BTN)));
			clickOnWebElement(By.xpath(COLLECTOR_MGMT_START_COLLECTOR_OK_BTN));
			waitForVisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			// do check whether collector has stopped or not

			return true;

		} catch (Exception e) {
			log.error("listOfSeedSwitches " + e);
			return false;
		}
	}

	public boolean deleteCollector(String collectorName) {
		String COLLECTOR_NAME = "//span[contains(text() , 'netvisor-collector-" + collectorName + "')]";
		try {
			if (isCollectorRunning(collectorName)) {
				toggleCollector(collectorName);
			}
			waitForElementVisibility(driver.findElement(By.xpath(COLLECTOR_NAME)));
			log.info("Deleting collector is " + collectorName);
			clickOnWebElement(By.xpath(COLLECTOR_NAME + COLLECTOR_MGMT_SETTING));
			clickOnWebElement(By.xpath(COLLECTOR_NAME + COLLECTOR_MGMT_SETTING_DELETE));
			waitForElementVisibility(driver.findElement(By.xpath(COLLECTOR_MGMT_START_COLLECTOR_OK_BTN)));
			clickOnWebElement(By.xpath(COLLECTOR_MGMT_START_COLLECTOR_OK_BTN));
			waitForVisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			// do check whether collector has deleted or not
			if (driver.findElements(By.xpath(COLLECTOR_NAME)).size() != 0) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			log.error("listOfSeedSwitches " + e);
			return false;
		}
	}
}