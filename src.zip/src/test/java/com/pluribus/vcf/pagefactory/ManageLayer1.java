package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.PointFeatureConstants.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.helper.SwitchMethods;

public class ManageLayer1 extends PageInfra {
	private PointFeatures pf;
	// private Layer1Methods lm;
	private SwitchMethods switchCli;
	private static final Logger log = Logger.getLogger(ManageLayer1.class);

	public ManageLayer1(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeEditPortConfigCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Edit")) {
			if (!pf.edit(input_names, input_values, "EDIT")) {
				status = false;
			}
		}
		return status;
	}

	public String[] getUIPortNo() {
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		List<WebElement> portListUI = driver.findElements(By.xpath(PORT_CONFIG_LIST));

		String[] arrPortList = new String[portListUI.size()];
		int i = 0;

		// Storing List elements text into String array
		for (WebElement e : portListUI) {
			arrPortList[i] = (e.getText()).trim();

			i++;
		}
		return arrPortList;

	}

	public boolean verifyPortNos(String SwitchName) throws Exception {
		// lm=new Layer1Methods(SwitchName);
		switchCli = new SwitchMethods(SwitchName);
		String[] UIPortList = getUIPortNo();
		String[] CliPortList = switchCli.getCLIPortlist(SwitchName);

		int n = CliPortList.length;
		if (n != UIPortList.length) {
			log.info("length is not matching" + CliPortList.length + "ui length" + UIPortList.length);
			return false;
		}
		for (int i = 0; i < n; i++) {

			if (!((Integer.parseInt(UIPortList[i])) == (Integer.parseInt(CliPortList[i])))) {
				return false;
			}
		}

		return true;

	}

}
