package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;
import com.pluribus.vcf.pagefactory.PointFeatures;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManageMirrors extends PageInfra {
	private static final Logger log = Logger.getLogger(ManageMirrors.class);
	private PointFeatures pf;

	public ManageMirrors(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeMirrorCommands(String buttonName, String[] input_names, String[] input_values)
			throws Exception {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!addMirror(input_names, input_values, Arrays.asList(input_names).lastIndexOf("span-encap"),
					CREATE_MIRROR_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			int nameIndex = Arrays.asList(input_names).lastIndexOf("name");
			if (!disableEnableMirror(input_values[nameIndex], false)) {
				status = false;
			}
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if (buttonName.contains("Add vFlow")) {
			if (!addVflowFilter(input_names, input_values, Arrays.asList(input_names).lastIndexOf("name"))) {
				status = false;
			}
		} else if (buttonName.contains("Enable")) {
			int nameIndex = Arrays.asList(input_names).lastIndexOf("name");
			if (!disableEnableMirror(input_values[nameIndex], true)) {
				status = false;
			}
		}
		return status;
	}

	public boolean addMirror(String[] input_names, String[] input_values, int spanEncapIndex, String buttonName)
			throws Exception {
		boolean status = true;
		if (!pf.clickOnButtonByText(buttonName)) {
			return false;
		}
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM_MIRROR));
		if (spanEncapIndex != -1) {
			pf.writeTextIntoInputElement(By.cssSelector("input[name='span-encap']"), input_names[spanEncapIndex],
					input_values[spanEncapIndex]);
		}
		pf.enterFormInputs(input_names, input_values);
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Save button");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));

		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}
		return status;
	}

	public boolean addVflowFilter(String[] input_names, String[] input_values, int mirrorNameIndex) {
		boolean status = true;
		String mirrorNameLocator = "//span[contains(text(),'" + input_values[mirrorNameIndex] + "')]";
		clickOnWebElement(By.xpath(mirrorNameLocator));
		clickOnWebElement(By.cssSelector(CREATE_VFLOW_PLUS_SIGN));
		for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
			if (loopCount != mirrorNameIndex) {
				String inputField = "input[name='" + input_names[loopCount] + "']";
				if (!isElementActive(By.cssSelector(inputField))) {
					inputField = "input[id='" + input_names[loopCount] + "']";
				}
				moveToWebElement(By.cssSelector(inputField));
				waitForVisibilityOfElementLocated(By.cssSelector(inputField));
				pf.writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount],
						input_values[loopCount]);
			}
		}
		log.info("Entered fields in form");
		clickOnWebElement(By.cssSelector(CREATE_VFLOW_SAVE_BUTTON));
		log.info("Clicked on Save button");
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		return status;
	}

	public boolean disableEnableMirror(String mirrorName, boolean enable) {
		boolean status = true;
		if (enable == true) {
			if (!getMirrorStatus(mirrorName)) {
				if (!toggleMirrorState(mirrorName)) {
					status = false;
				}
			}
		} else {
			if (getMirrorStatus(mirrorName)) {
				if (!toggleMirrorState(mirrorName)) {
					status = false;
				}
			}
		}
		return status;
	}

	public boolean toggleMirrorState(String mirrorName) {
		boolean status = true;
		clickOnWebElement(
				By.xpath("//span[contains(text(),'" + mirrorName + "')]/../..//div//span[@class='toggle-bg']//span"));
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		}
		return status;
	}

	public boolean getMirrorStatus(String mirrorName) {
		boolean status = true;
		if (!isElementActive(
				By.xpath("//span[contains(text(),'" + mirrorName + "')]/../..//div//check-box[@class='on']"))) {
			status = false;
		}
		return status;
	}

}