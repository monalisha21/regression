package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.AnalyticsConstants.CUSTOM_TAGS_SAVE_BUTTON;
import static com.pluribus.vcf.helper.AnalyticsConstants.PCAP_PACKET_COUNT;
import static com.pluribus.vcf.helper.PointFeatureConstants.ALERT_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.CREATE_PCAP_FETCH_BUTTON;
import static com.pluribus.vcf.helper.PointFeatureConstants.CREATE_PCAP_INTERFACE_LIST;
import static com.pluribus.vcf.helper.PointFeatureConstants.CREATE_PCAP_SAVE_BUTTON;
import static com.pluribus.vcf.helper.PointFeatureConstants.ERROR_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.EXISTING_LIST;
import static com.pluribus.vcf.helper.PointFeatureConstants.MANAGE_FORM;
import static com.pluribus.vcf.helper.PointFeatureConstants.PLURIBUS_WAIT_ICON;
import static com.pluribus.vcf.helper.PointFeatureConstants.UPLOAD_PCAP_BUTTON_TEXT;

import java.io.IOException;
import java.util.Arrays;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.jcraft.jsch.JSchException;
import com.pluribus.vcf.helper.PageInfra;

public class ManagePCAP extends PageInfra {
	private static final Logger log = Logger.getLogger(ManagePCAP.class);
	private PointFeatures pf;
	private AnalyticsFlowPage afp;

	public ManagePCAP(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
		afp = new AnalyticsFlowPage(driver);
	}

	public boolean executePCAPCommands(String buttonName, String[] input_names, String[] input_values)
			throws Exception {
		boolean status = true;
		if (buttonName.contains("Add Packet Engine")) {
			if (!addPacketEngine(input_names, input_values, buttonName)) {
				status = false;
			}
		} else if (buttonName.contains("Upload")) {
			if (!uploadPCAPFile(input_names, input_values, UPLOAD_PCAP_BUTTON_TEXT)) {
				status = false;
			}
		}
		return status;
	}

	public boolean addPacketEngine(String[] input_names, String[] input_values, String buttonName) {
		boolean status = true;
		pf.clickOnButtonByText(buttonName);
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));

		for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
			if (input_names[loopCount].contains("interface")) {
				continue;
			}
			String inputField = "input[name='" + input_names[loopCount] + "']";
			moveToWebElement(By.cssSelector(inputField));
			waitForVisibilityOfElementLocated(By.cssSelector(inputField));
			pf.writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount], input_values[loopCount]);
		}
		log.info("Entered fields in form");
		clickOnWebElement(By.cssSelector(CREATE_PCAP_FETCH_BUTTON));
		waitForVisibilityOfElementLocated(By.xpath(CREATE_PCAP_INTERFACE_LIST));
		WebElement intfLabel = findElementByText("label",
				input_values[Arrays.asList(input_names).lastIndexOf("interface")]);
		if (intfLabel == null) {
			log.error(
					"Could not locate interface " + input_values[Arrays.asList(input_names).lastIndexOf("interface")]);
			return false;
		}
		if (intfLabel.findElements(By.xpath(".//input[contains(@class ,'ng-empty')]")).size() != 0) {
			clickOnWebElement(intfLabel.findElement(By.xpath(".//input")));
		}
		clickOnWebElement(By.cssSelector(CREATE_PCAP_SAVE_BUTTON));
		log.info("Clicked on save button");
		waitForInvisibilityOfElementLocated(By.xpath(MANAGE_FORM));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}
		return status;
	}

	public boolean uploadPCAPFile(String[] input_names, String[] input_values, String buttonName)
			throws JSchException, IOException {
		boolean status = false;
		String filePath = "src/test/resources/PCAP/";
		WebElement uploadButton = findElementByText("button", buttonName);
		if (uploadButton == null) {
			log.error("Could not locate button with text" + buttonName);
			return status;
		}
		uploadButton.click();
		log.info("Clicked on button " + buttonName);
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		for (int loopCount = 0; loopCount < input_values.length; loopCount++) {
			if (input_values[loopCount].contains(".pcap")) {
				filePath = filePath + input_values[loopCount];
				status = uploadFile(filePath);
			} else {

				String inputField = "input[name='" + input_names[loopCount] + "']";
				moveToWebElement(By.cssSelector(inputField));
				waitForVisibilityOfElementLocated(By.cssSelector(inputField));
				pf.writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount],
						input_values[loopCount]);
			}
		}
		clickOnWebElement(By.cssSelector(CUSTOM_TAGS_SAVE_BUTTON));
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}

		return status;

	}

	public boolean waitForPacketCount(String filePath) throws JSchException, IOException {
		boolean status = true;
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}

		int terminalCount = pcapTerminalCount(filePath);
		int uiCount = pcapUiCount();
		if (uiCount != terminalCount) {
			status = false;
		}
		return status;

	}

	public int pcapUiCount() {
		int uiCount = 0;
		for (int i = 0; i <= 600; i++) {

			uiCount = (Integer.parseInt(((retryingFindGetText(By.xpath(PCAP_PACKET_COUNT), 3)))));

			if (uiCount != 0) {

				break;
			}
		}
		log.info("Ui count is " + uiCount);
		return uiCount;
	}
}