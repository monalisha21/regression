package com.pluribus.vcf.pagefactory;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.pluribus.vcf.helper.PageInfra;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManageSNMP extends PageInfra {
	private PointFeatures pf;
	private static final Logger log = Logger.getLogger(ManageSNMP.class);

	public ManageSNMP(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeSNMPStringCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("communities")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_SNMP_COMMUNITYSTRING_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if (buttonName.contains("sink")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_SNMP_TRAP_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Remove")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if (buttonName.contains("SNMPv3 user")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_SNMPV3_BUTTON_USER)) {
				status = false;
			}
		} else if (buttonName.contains("SNMPv3 trap")) {
			if (!pf.createDeletePf(input_names, input_values, SNMPV3_TRAP_BUTTON_RECEIVER)) {
				status = false;
			}
		} else if (buttonName.contains("VACM")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_VACM_BUTTON)) {
				status = false;
			}
		}
		return status;
	}

	public boolean executeSNMPEnableTrapCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Enable")) {
			if (!pf.edit(input_names, input_values, "ENABLE")) {
				status = false;
			}
		} else if (buttonName.contains("Disable")) {
			if (!pf.edit(input_names, input_values, "DISABLE")) {
				status = false;
			}
		}
		return status;
	}
}