package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.PointFeatureConstants.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import com.pluribus.vcf.helper.PageInfra;

public class ManageSyslog extends PageInfra {
	private PointFeatures pf;
	private static final Logger log = Logger.getLogger(ManageSyslog.class);

	public ManageSyslog(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeSyslogCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_SYSLOG_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if (buttonName.contains("Search")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_SYSLOGMATCH_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Edit")) {
			if (!pf.edit(input_names, input_values, "EDIT")) {
				status = false;
			}
		} else if (buttonName.contains("Remove")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		}
		return status;
	}

	public boolean executeLogEventsCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("On")) {
			if (!pf.edit(input_names, input_values, "ON")) {
				status = false;
			}
		} else if (buttonName.contains("Off")) {
			if (!pf.edit(input_names, input_values, "OFF")) {
				status = false;
			}
		}
		return status;
	}
}