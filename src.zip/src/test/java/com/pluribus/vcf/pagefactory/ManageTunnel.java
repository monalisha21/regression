package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.PointFeatureConstants.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.pluribus.vcf.helper.PageInfra;

public class ManageTunnel extends PageInfra {
	private PointFeatures pf;
	private static final Logger log = Logger.getLogger(ManageTunnel.class);

	public ManageTunnel(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeTunnelCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_TUNNEL_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if (buttonName.contains("Add")) {
			if (!pf.createDeletePf(input_names, input_values, ADD_TUNNEL_VXLAN_BUTTON_TEXT)) {
				status = false;
			}
		}

		return status;
	}
}
