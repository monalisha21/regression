package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.helper.PointFeatureConstants.*;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.pluribus.vcf.helper.PageInfra;

public class ManageVRF extends PageInfra {
	private PointFeatures pf;
	private static final Logger log = Logger.getLogger(ManageVRF.class);

	public ManageVRF(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeVRFCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_VRF_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		}

		return status;
	}
}
