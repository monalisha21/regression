package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManageVlag extends PageInfra {
	private static final Logger log = Logger.getLogger(ManageVlag.class);
	private PointFeatures pf;

	public ManageVlag(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeVlagCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_VLAG_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.delete(input_names, input_values)) {
				status = false;
			}
		}
		return status;
	}

}
