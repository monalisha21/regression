package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManageVlan extends PageInfra {
	private PointFeatures pf;
	private static final Logger log = Logger.getLogger(ManageVlan.class);

	public ManageVlan(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeVlanCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!pf.createDeletePf(input_names, input_values, CREATE_VLAN_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Delete")) {
			if (!pf.createDeletePf(input_names, input_values, DELETE_VLAN_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Add")) {
			if (!pf.addDelPorts(input_names, input_values, ADD_PORT_BUTTON_TEXT)) {
				status = false;
			}
		} else if (buttonName.contains("Remove")) {
			if (!pf.addDelPorts(input_names, input_values, REMOVE_PORT_BUTTON_TEXT)) {
				status = false;
			}
		}
		return status;
	}

}
