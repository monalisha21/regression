package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import java.util.Arrays;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class ManagevRouter extends PageInfra {
	private static final Logger log = Logger.getLogger(ManagevRouter.class);
	private PointFeatures pf;

	public ManagevRouter(WebDriver driver) {
		super(driver);
		pf = new PointFeatures(driver);
	}

	public boolean executeVrouterCommands(String buttonName, String[] input_names, String[] input_values) {
		boolean status = true;
		if (buttonName.contains("Create")) {
			if (!createVrouter(input_names, input_values)) {
				status = false;
			}
		} else if(buttonName.contains("Add an interface")) {
			if(!pf.addDelPorts(input_names, input_values, buttonName)) {
				status = false;
			}
		} else if(buttonName.contains("Delete")) {
			if(!pf.delete(input_names, input_values)) {
				status = false;
			}
		} else if(buttonName.contains("Remove")) {
			if(!deleteVrouter(input_names,input_values, buttonName)) {
				status = false;
			}
		}
		return status;
	}

	public boolean createVrouter(String[] input_names, String[] input_values) {
		boolean status = true;
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		selectElement(By.cssSelector(CREATE_VROUTER_SELECT_DROPDOWN),CREATE_HW_VROUTER_TEXT);
		log.info("Selected software vRouter");
		clickOnWebElement(By.cssSelector(CREATE_VROUTER_GO_BUTTON));
		log.info("Clicked on Go button");
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
			if(input_names[loopCount].contains("Advanced")) {
				input_names[loopCount] = pf.handleAdvanced(input_names[loopCount]);
				}
			String inputField = "input[name='" + input_names[loopCount] + "']";
			if(!isElementActive(By.cssSelector(inputField))) {
				inputField = "select[name='" + input_names[loopCount] + "']";
			}
			moveToWebElement(By.cssSelector(inputField));
			waitForVisibilityOfElementLocated(By.cssSelector(inputField));
			pf.writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount], input_values[loopCount]);
		}
		log.info("Entered fields in form");
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Save button");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}
		return status;
	}
	public boolean deleteVrouter(String[] input_names, String[] input_values, String buttonName) {
		boolean status = true;
		int nameIndex = pf.selectFieldinDropDown("vrouter-name",input_names,input_values);
		int ipIndex = Arrays.asList(input_names).lastIndexOf("ip");
		String menuItem = pf.getDropDownMenuItem();
		String dropdownArrow = pf.getDropDownArrow();
		selectDropDownValue(By.cssSelector(dropdownArrow), By.cssSelector(DROPDOWN_LIST), menuItem,
				input_values[nameIndex]);
		String[] valueArray = new String[] {input_values[ipIndex]};
		if(!pf.delete(input_names, valueArray)) {
			status = false;
		}
		return status;
	}
}