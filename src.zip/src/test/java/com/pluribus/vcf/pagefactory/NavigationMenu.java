package com.pluribus.vcf.pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static com.pluribus.vcf.helper.NavigationMenuConstants.*;

import com.pluribus.vcf.helper.PageInfra;

public class NavigationMenu extends PageInfra {

	public NavigationMenu(WebDriver driver) {
		super(driver);
	}

	public boolean gotoNotifications(String subElement) {
		waitForElementToClick(By.xpath(MENU_NOTIFICATION));
		clickOnWebElement(By.xpath(MENU_NOTIFICATION));
		String notificationSubMenu = MENU_NOTIFICATION_CONSTANT+subElement+"']";
		return clickOnWebElement(By.xpath(notificationSubMenu));
	}

	/*
	 * This is a generic method for "most" menu traversals in Navigation menu, since
	 * each menu item is a combination of: 1. Click on the topmost menu item (such
	 * as Manage/Analytics/Notification 2. Hover over the second-level menu item
	 * (Such as Fabric/ Layer 2/ Layer 3/ Insight Anayltics Flow etc) 3. Finally a
	 * click on the desired page (such as Connections/ Manage VLAN/ VLAN Ports/
	 * Manage LLDP etc)
	 */
	public boolean gotoMenu(String topMenu, String secondMenu, String thirdMenu) {
		String menuLocator = MENU_NAMES_CONSTANT + "'" + topMenu + "')]";
		waitForElementToClick(By.xpath(menuLocator));
		clickOnWebElement(By.xpath(menuLocator));

		menuLocator = MENU_NAMES_CONSTANT + "'" + secondMenu + "')]";
		waitForElementToClick(By.xpath(menuLocator));
		hoverOnWebElement(By.xpath(menuLocator));
		if (secondMenu.contains("Packet")) {
			menuLocator = MENU_CUSTOMTAG_CONSTANT + "'" + thirdMenu + "')]";
		} else {
			menuLocator = MENU_NAMES_CONSTANT + "'" + thirdMenu + "')]";
		}
		waitForElementToClick(By.xpath(menuLocator));
		clickOnWebElement(By.xpath(menuLocator));

		return true;
	}

	public void gotoLogoutMenu() {
		waitForElementToClick(By.cssSelector(MENU_USER));
		clickOnWebElement(By.cssSelector(MENU_USER));
		waitForElementToClick(By.cssSelector(MENU_USER_LOGOUT));
		clickOnWebElement(By.cssSelector(MENU_USER_LOGOUT));
	}

	public void gotoSettingsMenu() {
		waitForElementToClick(By.cssSelector(MENU_SETTINGS));
		clickOnWebElement(By.cssSelector(MENU_SETTINGS));
	}

	public void gotoSettingsLicenseMenu() {
		gotoSettingsMenu();
		clickOnWebElement(By.xpath(MENU_SETTINGS_LICENSE));
	}

	public void gotoSettingsAuthServerMenu() {
		gotoSettingsMenu();
		clickOnWebElement(By.xpath(MENU_SETTINGS_AUTH_SERVER));
	}

	public void gotoSettingsManageUsersMenu() {
		gotoSettingsMenu();
		clickOnWebElement(By.xpath(MENU_SETTINGS_MANAGE_USERS));
	}

	public void gotoSettingsManageAuditLogs() {
		gotoSettingsMenu();
		clickOnWebElement(By.xpath(MENU_SETTINGS_AUDIT_LOGS));
	}

	public void gotoSettingsManageSystemHealth() {
		gotoSettingsMenu();
		clickOnWebElement(By.xpath(MENU_SETTINGS_SYSTEM_HEALTH));
	}
}