package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.apache.log4j.Logger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import com.pluribus.vcf.helper.JsonHelper;
import java.util.Iterator;
import static com.pluribus.vcf.helper.PointFeatureConstants.*;

public class PointFeatures extends PageInfra {

	private static final Logger log = Logger.getLogger(PointFeatures.class);
	private JsonHelper jsonHelper;

	public PointFeatures(WebDriver driver) {
		super(driver);
		jsonHelper = new JsonHelper();
	}

	/*
	 * This class contains common methods that can be used by any of the point
	 * features.For example: Create/Delete can use the method createDeletePf. Any of
	 * the input fields can use the "writeTextIntoInputElement" method. Unique
	 * methods for a page will be available in the page itself and not here. All
	 * common functions should be placed in this class and all point feature classes
	 * can use them.
	 */
	public void writeTextIntoInputElement(By elemLocator, String fieldName, String inputValue) {
		String readOnlyValue = getAttributeValue(elemLocator, "ng-readonly");
		String typeProperty = getAttributeValue(elemLocator, "type");
		String multipleProperty = null;
		multipleProperty = getAttributeValue(elemLocator, "multiple");

		String className = DROPDOWN_ARROW_CLASS;
		if (!isElementActive(By.xpath("//button[@class='" + className + "']"))) {
			className = DROPDOWN_ARROW_ADMIN_CLASS;
		}

		String DROPDOWN_ARROW = "//div//label[@for='" + fieldName
				+ "']/following-sibling::div[@class='col-sm-4']//select-drop-down//div//button[@class='" + className
				+ "']";
		if (!isElementActive(By.xpath(DROPDOWN_ARROW))) {
			DROPDOWN_ARROW = "//div//input[@name='" + fieldName + "']/following-sibling::button[@class='" + className
					+ "']";
		}
		if (typeProperty.contains("text") || (typeProperty.contains("number"))) {
			// This a normal text field
			if ((readOnlyValue == null) || (!readOnlyValue.contains("true"))) {
				setValue(elemLocator, inputValue);
			} else {
				// This means it is a dropdown/ select element of some kind. Either multiselect/
				// dropdown/ single select dropdown
				String menuItem = getDropDownMenuItem();
				if ((multipleProperty == null) || (!multipleProperty.contains("multiple"))) {
					selectDropDownValue(By.xpath(DROPDOWN_ARROW), By.cssSelector(DROPDOWN_LIST), menuItem, inputValue);
				} else {
					selectElement(elemLocator, inputValue);
				}
			}
		} else if (typeProperty.contains("checkbox")) {
			// This is to handle a checkbox
			clickOnWebElement(elemLocator);
		}
	}

	public String getDropDownArrow() {
		String dropdownArrow = DROPDOWN_ARROW;
		if (!isElementActive(By.xpath("//div[@class='btn-group dropdown-toggle select-drop-down']"))) {
			dropdownArrow = DROPDOWN_ARROW_ADMIN;
		}
		return dropdownArrow;
	}

	public String getDropDownMenuItem() {
		String dropdownMenuItem = DROPDOWN_MENU_ITEM;
		if (!isElementActive(By.xpath("//div[@class='btn-group dropdown-toggle select-drop-down']"))) {
			dropdownMenuItem = DROPDOWN_MENU_ITEM_ADMIN;
		}
		return dropdownMenuItem;
	}

	public boolean clickOnButtonByText(String buttonName) {
		WebElement createDeleteButton = findElementByText("button", buttonName);
		if (createDeleteButton == null) {
			log.error("Could not locate button with text" + buttonName);
			return false;
		}
		createDeleteButton.click();
		log.info("Clicked on button " + buttonName);
		return true;
	}

	public void enterFormInputs(String[] input_names, String[] input_values) {
		for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
			if (input_names[loopCount].contains("Advanced")) {
				input_names[loopCount] = handleAdvanced(input_names[loopCount]);
			}
			String inputField = "input[name='" + input_names[loopCount] + "']";
			if (!isElementActive(By.cssSelector(inputField))) {
				inputField = "input[id='" + input_names[loopCount] + "']";
			}
			moveToWebElement(By.cssSelector(inputField));
			waitForVisibilityOfElementLocated(By.cssSelector(inputField));
			writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount], input_values[loopCount]);
		}
		log.info("Entered fields in form");
	}

	public boolean createDeletePf(String[] input_names, String[] input_values, String buttonName) {
		boolean status = true;
		clickOnButtonByText(buttonName);
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));
		enterFormInputs(input_names, input_values);
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Save button");
		if (isElementActive(By.xpath(FORM_OK_BUTTON))) {
			clickOnWebElement(By.xpath(FORM_OK_BUTTON));
			log.info("Clicked on Ok button");
		}
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));

		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}

		return status;
	}

	// This method is used wherever deletion is done by clicking on the Settings
	// icon
	public boolean delete(String[] input_names, String[] input_values) {
		boolean status = true;
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		// waitForVisibilityOfElementLocated(By.xpath("//span[contains(text(),'" +
		// input_values[0] + "')]"));
		waitForVisibilityOfElementLocated(By.cssSelector("div.table.my-table"));
		String settings = "//span[contains(text(),'" + input_values[0] + "')]/preceding-sibling::span//span";
		if (!isElementActive(By.xpath(settings))) {
			settings = "//span[contains(text(),'" + input_values[0]
					+ "')]/../..//div//span[@class='action-dropdown dropdown']//span";
		}
		waitForElementToClick(By.xpath(settings));
		retryingFindClick(By.xpath(settings));
		retryingFindClick(By.xpath(DELETE_ICON));
		log.info("Clicked on delete icon");
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Confirm delete button");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			// log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}
		return status;
	}

	public boolean addDelPorts(String[] input_names, String[] input_values, String buttonName) {
		boolean status = true;
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		// Select VLAN ID in dropdown
		int nameIndex = Arrays.asList(input_names).lastIndexOf("name");
		String name = input_values[nameIndex];
		String menuItem = getDropDownMenuItem();
		selectDropDownValue(By.cssSelector(DROPDOWN_ARROW_ADMIN), By.cssSelector(DROPDOWN_LIST), menuItem, name);
		clickOnButtonByText(buttonName);
		log.info("Selected Name " + name + " in dropdown list");

		// Fill out other elements in the form
		for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
			if (loopCount == nameIndex)
				continue;
			String addDelPortsInput = "input[id='" + input_names[loopCount] + "']";
			if (!isElementActive(By.cssSelector(addDelPortsInput))) {
				addDelPortsInput = "input[name='" + input_names[loopCount] + "']";
			}
			waitForVisibilityOfElementLocated(By.cssSelector(addDelPortsInput));
			writeTextIntoInputElement(By.cssSelector(addDelPortsInput), input_names[loopCount],
					input_values[loopCount]);
		}
		log.info("Filled out input fields");
		// Click on save button
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on save button");
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			// log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}
		return status;
	}

	public int selectFieldinDropDown(String fieldName, String[] inputNames, String[] inputValues) {
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		int nameIndex = Arrays.asList(inputNames).lastIndexOf(fieldName);
		String menuItem = getDropDownMenuItem();
		String dropdownArrow = getDropDownArrow();
		selectDropDownValue(By.cssSelector(dropdownArrow), By.cssSelector(DROPDOWN_LIST), menuItem,
				inputValues[nameIndex]);
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		return nameIndex;
	}

	// this method is used when try to edit the input values
	public boolean edit(String[] input_names, String[] input_values, String buttonName) {
		boolean status = true;
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		String settings = "//span/preceding-sibling::span[@class='action-dropdown dropdown']/span";
		if (!isElementActive(By.xpath(settings))) {
			settings = "//span/parent::*/preceding::div//span[@class='action-dropdown dropdown']/span";
		}
		waitForElementToClick(By.xpath(settings));
		retryingFindClick(By.xpath(settings));
		retryingFindClick(By.xpath(EDIT_ICON));
		log.info("Clicked on edit icon");
		waitForVisibilityOfElementLocated(By.cssSelector(MANAGE_FORM));

		if (isElementActive(By.xpath(ADDITIONAL_FIELDS))) {
			clickOnWebElement(By.xpath(ADDITIONAL_FIELDS));

		}
		if (buttonName == "EDIT") {
			for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
				String inputField = "input[name='" + input_names[loopCount] + "']";
				waitForVisibilityOfElementLocated(By.cssSelector(inputField));
				writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount], input_values[loopCount]);
			}
		} else {
			for (int loopCount = 0; loopCount < input_names.length; loopCount++) {
				String inputField = "input[id='" + input_names[loopCount] + "']";
				waitForVisibilityOfElementLocated(By.cssSelector(inputField));
				writeTextIntoInputElement(By.cssSelector(inputField), input_names[loopCount], input_values[loopCount]);
			}
		}
		log.info("Entered fields in form");
		clickOnWebElement(By.cssSelector(FORM_SAVE_BUTTON));
		log.info("Clicked on Save button");
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));

		if (isElementActive(By.cssSelector(ERROR_NOTIFICATION))) {
			log.error(driver.findElement(By.cssSelector(ERROR_NOTIFICATION)).getText());
			status = false;
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
			status = true;
		}

		return status;
	}

	public String handleAdvanced(String inputField) {
		if (isElementActive(By.cssSelector(CREATE_VROUTER_PLUS_ICON))) {
			clickOnWebElement(By.cssSelector(CREATE_VROUTER_PLUS_ICON));
		}
		return replaceSubstring(inputField, '-', "");
	}

	public List<WebElement> checkRowNumber(String rowIdentifier) {
		String className = "') and not(@class='treenode') and not(@class='help-block')]/../..";
		List<WebElement> rows = driver.findElements(By.xpath("//span[contains(text(),' " + rowIdentifier + className));
		return rows;
	}

	public JSONArray extractRowJson(String rowIdentifier) {
		JSONArray rowJson = new JSONArray();
		List<WebElement> rows = checkRowNumber(rowIdentifier);
		String fieldNameLocator = ".//div[contains(@class, 'th') and not(contains(@class,'thead'))  and not(contains(@class,'td'))]";
		List<WebElement> fields = findElementsByText(By.xpath(fieldNameLocator));
		String fieldValueLocator = ".//div[@class='td']";
		List<WebElement> fieldValues;

		for (int rowCount = 0; rowCount < rows.size(); rowCount++) {
			JSONObject guiJson = new JSONObject();
			try {
				waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
				// fields = rows.get(rowCount).findElements(By.xpath(fieldNameLocator));
				if (!isElementActive(By.xpath(fieldValueLocator))) {
					fieldValueLocator = ".//span[not(@class)]";
				}
				fieldValues = rows.get(rowCount).findElements(By.xpath(fieldValueLocator));
			} catch (Exception e) {
				return null;
			}
			for (int i = 0; i < fields.size(); i++) {
				String fieldName = fields.get(i).getText().toLowerCase();
				String fieldValue = fieldValues.get(i).getText();

				if (fieldValue.matches("-?\\d+")) {
					guiJson.put(fieldName, Integer.parseInt(fieldValue));
				} else if ((fieldValue.matches("true")) || (fieldValue.matches("false"))) {
					guiJson.put(fieldName, Boolean.parseBoolean(fieldValue));
				} else if ((fieldName.contains("ports")) && (fieldValue.contains("-"))) {
					guiJson.put(fieldName, handlePortNumbers(fieldValue));
				} else if ((fieldName.contains("switch")) || (fieldName.contains("dead-time"))
						|| (fieldName.contains("up/down"))) {
					continue;
				} else {
					guiJson.put(fieldName, fieldValue);
				}
			}
			rowJson.put(guiJson);
		}
		return rowJson;
	}

	public JSONArray processJson(JSONArray jsonArr) {
		JSONArray modJson = new JSONArray();

		for (int i = 0, size = jsonArr.length(); i < size; i++) {
			JSONObject modJsonObj = new JSONObject();
			JSONObject objectInArray = jsonArr.getJSONObject(i);
			Iterator it = objectInArray.keys();
			while (it.hasNext()) {
				String key = (String) it.next();
				try {
					if (objectInArray.getString(key).matches("-?\\d+")) {
						modJsonObj.put(key, Integer.parseInt(objectInArray.getString(key)));
					} else {
						modJsonObj.put(key, objectInArray.get(key));
					}
				} catch (Exception e) {
					modJsonObj.put(key, objectInArray.get(key));
				}
			}
			modJson.put(modJsonObj);
		}
		return modJson;
	}

	public JSONArray extractGuiJson(String rowIdentifier, String selectValue) {
		JSONArray rowJson = new JSONArray();
		refreshPage();
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		waitForVisibilityOfElementLocated(By.cssSelector(EXISTING_LIST));
		if (selectValue != null) {
			waitForVisibilityOfElementLocated(By.cssSelector(DROPDOWN_BOX));
			String menuItem = getDropDownMenuItem();
			String dropdownArrow = DROPDOWN_ARROW;
			if (!isElementActive(By.cssSelector(DROPDOWN_ARROW))) {
				dropdownArrow = DROPDOWN_ARROW_ADMIN;
			}
			selectDropDownValue(By.cssSelector(dropdownArrow), By.cssSelector(DROPDOWN_LIST), menuItem, selectValue);
		}
		waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		ArrayList<JSONArray> guiJson = new ArrayList<>();
		if (rowIdentifier != null) {
			rowJson = extractRowJson(rowIdentifier);
		} else {
			// Generate page level/ global guiJson (since row Identifier wasn't specified)
			List<WebElement> fields;
			try {
				fields = driver.findElements(By.xpath(ROW_IDENTIFIER_TABLE));
				if (fields.get(0).getText().equals("")) {
					fields = driver.findElements(By.xpath(ROW_IDENTIFIER_TABLE_VRouter));
				}

			} catch (Exception e) {
				return null;
			}
			// checkfor any duplication present or not
			List<String> fieldNames = duplicateCounts(fields);

			for (int i = 0; i < fieldNames.size(); i++) {
				guiJson.add(extractRowJson(fieldNames.get(i).toString()));
				rowJson = jsonHelper.mergeJsonArrays(guiJson);
			}
		}
		return rowJson;
	}

	public static String handlePortNumbers(String portNumbers) {
		char range = '-';
		String outputPortNumbers = "";

		String[] port = portNumbers.split(",");
		for (int x = 0; x < port.length; x++) {
			if (!port[x].contains("-")) {
				outputPortNumbers += port[x] + ",";

			} else {
				String[] portRange = port[x].split("-");
				outputPortNumbers += portRange[0] + ","
						+ expandPortNumbers(Integer.parseInt(portRange[0]), Integer.parseInt(portRange[1]))
						+ portRange[1] + ",";
			}
		}
		if (outputPortNumbers.endsWith(",")) {
			outputPortNumbers = outputPortNumbers.substring(0, outputPortNumbers.length() - 1);
		}
		return (outputPortNumbers);
	}

	public static String expandPortNumbers(int startRange, int endRange) {
		String range = "";

		for (int i = startRange + 1; i < endRange; i++) {
			range += i;
			range += ",";
		}
		// range +=",";

		return range;
	}

	public List<String> duplicateCounts(List<WebElement> fields) {
		int counter = 0;
		List<String> fieldsName = new ArrayList<String>(fields.size());
		for (int i = 0; i < fields.size(); i++) {
			fieldsName.add(fields.get(i).getText());
		}
		fieldsName.stream().distinct().collect(Collectors.toList());
		return fieldsName.stream().distinct().collect(Collectors.toList());
	}

	public void cleanPfSession() {
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		}
		log.info("Cleaned up session before testcase start");
	}

}