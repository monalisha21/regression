package com.pluribus.vcf.pagefactory;

import static com.pluribus.vcf.pagefactory.NavigationMenu.*;
import static com.pluribus.vcf.helper.SkedlerConstants.*;
import static com.pluribus.vcf.helper.NavigationMenuConstants.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import com.pluribus.vcf.helper.PageInfra;

public class SkedlerAlertsPage extends PageInfra {
	private static final Logger log = Logger.getLogger(SkedlerAlertsPage.class);

	public SkedlerAlertsPage(WebDriver driver) {
		super(driver);
	}

	public boolean addTimeZone(String timeZone) {
		boolean status;
		try {
			waitForElementToClick(By.linkText(MENU_ALERT));
			clickOnWebElement(By.linkText(MENU_ALERT));
			/*
			 * Added work around if the Skedler Alerts page is not displayed then go to
			 * License page and come back to Skedler Alerts page
			 */
			if (isElementActive(By.linkText(NO_ACTIVE_LICENSE))) {
				clickOnWebElement(By.linkText(NO_ACTIVE_LICENSE));
				Thread.sleep(10000);
				waitForElementToClick(By.xpath(MENU_NOTIFICATION));
				clickOnWebElement(By.xpath(MENU_NOTIFICATION));
				clickOnWebElement(By.xpath(MENU_NOTIFICATION_CONSTANT + "alerts']"));
			}
			frameToBeAvailable(By.xpath(IFRAME));
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			waitForElementToClick(By.linkText(MENU_ALERT_SETTINGS));
			clickOnWebElement(By.linkText(MENU_ALERT_SETTINGS));
			waitForElementToClick(By.cssSelector(ALERT_TIMEZONE));
			clickOnWebElement(By.cssSelector(ALERT_TIMEZONE));
			// Removed Calendar.getInstance().getTimeZone().getID() and added US/Pacific
			// timeZone
			setValue(driver.findElement(By.cssSelector(ALERT_TIMEZONE)), timeZone);
			sendKeysToElement(By.cssSelector(ALERT_TIMEZONE), Keys.ARROW_DOWN);
			sendKeysToElement(By.cssSelector(ALERT_TIMEZONE), Keys.ARROW_DOWN);
			sendKeysToElement(By.cssSelector(ALERT_TIMEZONE), Keys.ENTER);
			sendKeysToElement(By.cssSelector(ALERT_TIMEZONE), Keys.TAB);
			waitForElementToClick(By.xpath(TIMEZONE_SAVE_BUTTON));
			clickOnWebElement(By.xpath(TIMEZONE_SAVE_BUTTON));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public boolean addEmailNotification(String supportedEmailService, String sendersEmail, String sendersEmailPwd) {
		boolean status;
		try {
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			clickOnWebElement(By.cssSelector(EMAIL_TOGGLE));
			selectElement(driver.findElement(By.xpath(SUPPORTED_EMAIL_SERVICE)), supportedEmailService);
			clickOnWebElement(By.xpath(SENDERS_EMAIL_ID));
			setValue(driver.findElement(By.xpath(SENDERS_EMAIL_ID)), sendersEmail);
			clickOnWebElement(By.xpath(SENDERS_EMAIL_PWD));
			setValue(driver.findElement(By.xpath(SENDERS_EMAIL_PWD)), sendersEmailPwd);
			clickOnWebElement(By.cssSelector(EMAIL_SAVE_BUTTON));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			waitForElementToClick(By.xpath(SEND_TEST_MAIL));
			clickOnWebElement(By.xpath(SEND_TEST_MAIL));
			setValue(driver.findElement(By.xpath(SEND_TEST_MAIL)), sendersEmail);
			clickOnWebElement(By.cssSelector(TEST_MAIL_SEND_BUTTON));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public boolean addWebHook(String webhookName, String webhookURL) {
		boolean status;
		try {
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			waitForVisibilityOfElementLocated(By.cssSelector(CREATE_WEBHOOK));
			clickOnWebElement(By.cssSelector(CREATE_WEBHOOK));
			clickOnWebElement(By.cssSelector(ADD_WEBHOOK));
			clickOnWebElement(By.cssSelector(WEBHOOK_ALIAS));
			setValue(driver.findElement(By.cssSelector(WEBHOOK_ALIAS)), webhookName);
			clickOnWebElement(By.cssSelector(WEBHOOK_URL));
			setValue(driver.findElement(By.cssSelector(WEBHOOK_URL)), webhookURL);
			clickOnWebElement(By.cssSelector(WEBHOOK_SAVE_BUTTON));
			waitForVisibilityOfElementLocated(By.xpath(SUCCESS_GREEN_MSG));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public boolean addIndexPattern(String indexPattern) {
		boolean status;
		try {
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			waitForVisibilityOfElementLocated(By.linkText(MENU_ALERT_INDEX_PATTERN));
			clickOnWebElement(By.linkText(MENU_ALERT_INDEX_PATTERN));
			waitForVisibilityOfElementLocated(By.cssSelector(ADD_INDEX_PATTERN));
			clickOnWebElement(By.cssSelector(ADD_INDEX_PATTERN));
			setValue(By.cssSelector(ADD_INDEX_PATTERN), indexPattern, Keys.TAB);
			if (isElementActive(By.xpath(WAITING_YELLOW_MSG))) {
				log.info(captureSuccessMessage(By.xpath(WAITING_YELLOW_MSG)));
			}
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public boolean addScheduleAlert(String alertName, String indexPattern, String scheduleIndexType,
			String scheduleTimeField, String scheduleDateField, String receiverEmail, String field, String type,
			String condition, String value) {
		boolean status;
		try {
			String[] queryField = field.split(",");
			String[] queryType = type.split(",");
			String[] queryCondition = condition.split(",");
			String[] queryValue = value.split(",");
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			waitForVisibilityOfElementLocated(By.linkText(MENU_ALERT_SCHEDULE_ALERT));
			clickOnWebElement(By.linkText(MENU_ALERT_SCHEDULE_ALERT));
			waitForElementToClick(By.cssSelector(CREATE_ALERT_BUTTON));
			clickOnWebElement(By.cssSelector(CREATE_ALERT_BUTTON));
			waitForElementToClick(By.cssSelector(SCHEDULE_ALERT_NAME));
			setValue(driver.findElement(By.cssSelector(SCHEDULE_ALERT_NAME)), alertName);
			waitForElementPresent(By.xpath(SCHEDULE_ALERTS_DROP_DOWNS_OPTIONS + indexPattern + "']"));
			selectElement(driver.findElement(By.xpath(SCHEDULE_INDEX_PATTERN)), indexPattern);
			waitForElementPresent(By.xpath(SCHEDULE_ALERTS_DROP_DOWNS_OPTIONS + scheduleIndexType + "']"));
			selectElement(driver.findElement(By.xpath(SCHEDULE_INDEX_TYPE)), scheduleIndexType);
			waitForElementPresent(By.xpath(SCHEDULE_ALERTS_DROP_DOWNS_OPTIONS + scheduleTimeField + "']"));
			selectElement(driver.findElement(By.xpath(SCHEDULE_TIME_FIELD)), scheduleTimeField);
			for (int i = 0; i < queryField.length; i++) {
				selectQueryFilters(queryField[i], queryType[i], queryCondition[i], queryValue[i], i);
			}
			waitForElementToClick(By.xpath(SCHEDULE_CHECKBOX));
			clickOnWebElement(By.xpath(SCHEDULE_CHECKBOX));
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mm");
			int dateField = Integer.parseInt(scheduleDateField);
			Calendar getCurrentTime = Calendar.getInstance();
			getCurrentTime.add(Calendar.MINUTE, dateField);
			String dateAsString = simpleDateFormat.format(getCurrentTime.getTime());
			waitForVisibilityOfElementLocated(By.xpath(START_MINUTES));
			setValue(driver.findElement(By.xpath(START_MINUTES)), dateAsString);
			clickOnWebElement(By.xpath(ALERT_ACTION_CHECKBOX));
			waitForElementVisibilityLocatedBy(driver.findElement(By.xpath(EMAIL_TO)));
			clickOnWebElement(By.xpath(EMAIL_TO));
			setValue(driver.findElement(By.xpath(EMAIL_TO)), receiverEmail);
			setElementAttribute(driver.findElement(By.id("showAction")), "style", "min-height:900px");
			for (int i = 0; i < queryField.length; i++) {
				clickOnWebElement(By.xpath(SCHEDULE_ALERT_SELECT_FIELDS_FOR_NOTIFICATIONS));
				driver.findElement(By.xpath(SCHEDULE_ALERT_SELECT_FIELDS_FOR_NOTIFICATIONS)).sendKeys(queryField[i]);
				clickOnWebElement(By.xpath("//span[normalize-space()='" + queryField[i] + "']"));
			}
			switchToParent();
			((JavascriptExecutor) driver).executeScript("scroll(0,0)");
			frameToBeAvailable(By.xpath(IFRAME));
			clickOnWebElement(By.xpath(SCHEDULE_ALERT_SAVE_BUTTON));
			waitForVisibilityOfElementLocated(By.xpath(SUCCESS_GREEN_MSG));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public boolean scheduleDeleteAlert() throws InterruptedException {
		boolean status;
		try {
			if (isElementActive(By.xpath(MODAL_BACKDROP))) {
				waitForInvisibilityOfElementLocated(By.xpath(MODAL_BACKDROP));
			}
			switchToParent();
			frameToBeAvailable(By.xpath(IFRAME));
			clickOnWebElement(By.xpath(SCHEDULE_TIME_WINDOW_CHECKBOX));
			clickOnWebElement(By.xpath(SCHEDULE_DELETE_ALERT_BUTTON));
			waitForVisibilityOfElementLocated(By.xpath(SCHEDULE_ALERT_DELETE_OK_BUTTON));
			clickOnWebElement(By.xpath(SCHEDULE_ALERT_DELETE_OK_BUTTON));
			waitForInvisibilityOfElementLocated(By.xpath(SCHEDULE_ALERT_DELETE_OK_BUTTON));
			log.info(captureSuccessMessage(By.xpath(SUCCESS_GREEN_MSG)));
			status = true;
		} catch (Exception e) {
			log.error(e);
			status = false;
		}
		return status;
	}

	public void selectQueryFilters(String field, String type, String condition, String value, int i) {
		selectElement(driver.findElement(By.xpath(SCHEDULE_ALERT_QUERY_FIELD + (i + 1) + "]")), field);
		selectElement(driver.findElement(By.xpath(SCHEDULE_ALERT_QUERY_TYPE + (i + 1) + "]")), type);
		selectElement(driver.findElement(By.xpath(SCHEDULE_ALERT_QUERY_CONDITION + (i + 1) + "]")), condition);
		clickOnWebElement(By.xpath(SCHEDULE_ALERT_QUERY_VALUE + (i + 1) + "]"));
		driver.findElement(By.xpath(SCHEDULE_ALERT_QUERY_VALUE + (i + 1) + "]")).sendKeys(value);
		clickOnWebElement(By.xpath(SHEDULE_ALERT_PLUS_BUTTON));
	}
}
