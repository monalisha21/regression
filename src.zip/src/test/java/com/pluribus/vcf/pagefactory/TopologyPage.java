package com.pluribus.vcf.pagefactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.helper.SwitchMethods;

import static com.pluribus.vcf.helper.FabricConstants.*;
import static com.pluribus.vcf.helper.TopologyConstants.*;
import static com.pluribus.vcf.helper.JsonHelper.*;

public class TopologyPage extends PageInfra {
	private SwitchMethods switchMethod;
	private static final Logger log = Logger.getLogger(TopologyPage.class);

	@FindBy(how = How.ID, using = "username")
	WebElement username;

	@FindBy(how = How.ID, using = "password")
	WebElement password;

	@FindBy(how = How.ID, using = "host")
	WebElement mgmtIp;

	public TopologyPage(WebDriver driver) {
		super(driver);
	}

	public void handleCancelButtonClick() {
		try {
			waitForElementVisibilityLocatedBy(driver.findElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN)));
			if (isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))) {
				clickOnWebElement(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
				waitForInvisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN));
			}
		} catch (StaleElementReferenceException e) {
		} catch (NoSuchElementException e) {
		} catch (Exception e) {
			log.error(e);
		}
	}

	// For Delete Fabric
	public boolean deleteFabric() throws Exception {
		try {
			// Delete fabric
			if (driver.findElements(By.cssSelector(FABRIC_LIST_ARROW_DOWN)).size() != 0) {
				waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DETAILS_PANEL));
				waitForElementToClick(By.cssSelector(FABRIC_SETTINGS_ICON));
				if (isElementActive(By.cssSelector(FABRIC_DETAILS_PANEL))) {
					if (isElementActive(By.cssSelector(FABRIC_DIALOG_CANCEL_CLOSE_BTN))) {
						handleCancelButtonClick();
					}
					waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DETAILS_PANEL));
					waitForElementToClick(By.cssSelector(FABRIC_SETTINGS_ICON));
					clickOnWebElement(By.cssSelector(FABRIC_SETTINGS_ICON));
					clickOnWebElement(By.cssSelector(FABRIC_SETTINGS_DELETE));
					waitForElementToClick(By.cssSelector(FABIC_DELETE_DIALOG_OK_BTN));
					clickOnWebElement(By.cssSelector(FABIC_DELETE_DIALOG_OK_BTN));
					if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
						log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
						waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
					} else {
						waitForVisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
						log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
						waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
					}
				} else {
					log.info("Fabric panel not open");
				}
			} else {
				log.info("No existing fabric. Skipping delete");
			}
		} catch (TimeoutException e) {
		} catch (Exception e) {
			log.error(e);
		} finally {
			clickOnWebElement(By.xpath("//body"));
		}
		return true;
	}

	public void addFabric(String switchName, String switchMgmtIp, String usrname, String pwd) throws Exception {
		clickOnWebElement(By.cssSelector(ADD_FABRIC));
		clickOnWebElement(By.xpath(FABRIC_DIALOG_ADD_SWITCH));
		setValue(mgmtIp, switchMgmtIp);
		setValue(username, usrname);
		setValue(password, pwd);
		clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
		waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DIALOG_RADIO_BUTTONS));
		waitForElementToClick(By.cssSelector(FABRIC_DIALOG_RADIO_BUTTONS));
		clickOnWebElement(By.cssSelector(FABRIC_DIALOG_NEXT_BTN));
		waitForElementToClick(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
		clickOnWebElement(By.cssSelector(FABRIC_DIALOG_ADD_BTN));
		if (isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
		}
		waitForElementVisibility(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)));
		log.info(driver.findElement(By.cssSelector(ALERT_NOTIFICATION)).getText());
		waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		log.info("fabric Added successful");
	}

	public boolean isSwitchListHidden(String fabricName) {
		boolean status = false;
		String FABRIC_SWITCH_LIST_INVISIBILITY = "//span[text()='" + fabricName
				+ "']/preceding-sibling::i[@class='fa fa- caret-left']";
		if (isElementActive(By.xpath(FABRIC_SWITCH_LIST_INVISIBILITY))) {
			status = true;
		}
		return status;
	}

	public void makeSwitchListVisible(String fabricName) {
		String FABRIC_SWITCH_LIST_INVISIBILITY = "//span[text()='" + fabricName
				+ "']/preceding-sibling::i[@class='fa fa- caret-left']";
		clickOnWebElement(By.xpath(FABRIC_SWITCH_LIST_INVISIBILITY));
	}

	public boolean selectSwitchInMenu(String switchName, String fabricName) {
		boolean status = true;
		String FABRIC_SWITCH_LIST = "//span[text()='" + fabricName + "']";
		waitForVisibilityOfElementLocated(By.xpath(FABRIC_SWITCH_LIST));
		// Check if switch list is hidden
		if (isSwitchListHidden(fabricName)) {
			log.info("Switch list for " + fabricName + " is hidden");
			makeSwitchListVisible(fabricName);
		}
		if (isSwitchListHidden(fabricName)) {
			status = false;
		}
		String FABRIC_SELECT_SWITCH = "//span[text()='" + switchName + "']/preceding-sibling::span";
		retryingFindClick(By.xpath(FABRIC_SELECT_SWITCH));
		return status;
	}

	public boolean selectFabricInMenu(String fabricName) {
		try {
			String FABRIC_SWITCH_LIST = "//span[text()='" + fabricName + "']";
			waitForVisibilityOfElementLocated(By.xpath(FABRIC_SWITCH_LIST));
			retryingFindClick(By.xpath(FABRIC_SWITCH_LIST));
		} catch (Exception e) {
			log.error(e);
			return false;
		}
		return true;

	}

	public boolean verifyFabric(String mgmtIp, String getFabricDetails, String usrname, String pwd) throws Exception {
		boolean verifyFabricDetails = true;
		waitForElementToClick(By.id(CLOSE_FABRIC_DETAILS_WINDOW));
		List<WebElement> switchListUI = driver.findElements(By.xpath(FABRIC_DETAILS_SWITCH_LIST));
		List<WebElement> mgmtIpUI = driver.findElements(By.xpath(MGMT_IP));
		List<WebElement> inBandIpUI = driver.findElements(By.xpath(IN_BAND_IP));
		List<WebElement> stateUI = driver.findElements(By.xpath(STATE));
		List<String> arrayForValuesFromJson = new ArrayList<String>();

		for (WebElement element : stateUI) {
			if (!element.getText().matches("online")) {
				waitForElementVisibility(element.findElement(By.xpath(DISCOVERY_STATUS_ONLINE)));
			}
		}

		for (int i = 0; i < switchListUI.size(); i++) {
			arrayForValuesFromJson.add(switchListUI.get(i).getText() + "," + mgmtIpUI.get(i + 1).getText() + ","
					+ inBandIpUI.get(i + 1).getText() + "," + stateUI.get(i).getText().trim());
		}
		Collections.sort(arrayForValuesFromJson);

		HashMap httpJsonArr = getSwitchHttpResult(mgmtIp, getFabricDetails, usrname, pwd);
		JSONArray jsonArr = new JSONArray();
		List<String> switchListHTTPArray = new ArrayList<String>();
		if (httpJsonArr.get("status").toString().equals("200")) {
			jsonArr = new JSONArray(httpJsonArr.get("data").toString());
			for (int i = 0; i < jsonArr.length(); i++) {
				switchListHTTPArray
				.add(jsonArr.getJSONObject(i).get("name") + "," + jsonArr.getJSONObject(i).get("mgmt-ip")
						+ "/" + String.valueOf(jsonArr.getJSONObject(i).get("mgmt-netmask")) + ","
						+ jsonArr.getJSONObject(i).get("in-band-ip") + "/"
						+ String.valueOf(jsonArr.getJSONObject(i).get("in-band-netmask")) + ","
						+ jsonArr.getJSONObject(i).get("state"));
			}
		} else {
			jsonArr = new JSONArray(httpJsonArr.get("result").toString());
			log.error("HTTP Response failed for switch " + mgmtIp + " with message : "
					+ jsonArr.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + mgmtIp + " with message : "
					+ jsonArr.getJSONObject(0).get("message"));
		}
		Collections.sort(switchListHTTPArray);

		for (int i = 0; i < switchListHTTPArray.size(); i++) {
			if (!switchListHTTPArray.get(i).toString().equalsIgnoreCase(arrayForValuesFromJson.get(i).toString())) {
				log.error("Rest API Fabric Detail (" + switchListHTTPArray.get(i).toString()
						+ ") Does not match with UI Fabric Detail (" + arrayForValuesFromJson.get(i).toString() + ")");
				verifyFabricDetails = false;
				break;
			}
		}
		return verifyFabricDetails;
	}

	public boolean verifySwitch(String mgmtIp, String getFabricDetails, String usrname, String pwd) throws Exception {
		boolean verifySwitchDetails = true;
		waitForElementToClick(By.cssSelector(FABRIC_DETAILS_PANEL));
		retryingFindClick(driver.findElement(By.id(CLOSE_FABRIC_DETAILS_WINDOW)));
		List<WebElement> switchListUI = driver.findElements(By.xpath(TOPOLOGY_SWITCH_LIST));
		List<String> arrayForValuesFromJson = new ArrayList<String>();
		for (WebElement element : switchListUI) {
			arrayForValuesFromJson.add(element.getText().substring(0, 9).toLowerCase());
		}
		Collections.sort(arrayForValuesFromJson);

		HashMap httpJsonArr = getSwitchHttpResult(mgmtIp, getFabricDetails, usrname, pwd);
		JSONArray jsonArr = new JSONArray();
		List<String> switchListHTTPArray = new ArrayList<String>();
		if (httpJsonArr.get("status").toString().equals("200")) {
			jsonArr = new JSONArray(httpJsonArr.get("data").toString());
			for (int i = 0; i < jsonArr.length(); i++) {
				switchListHTTPArray.add(jsonArr.getJSONObject(i).get("name").toString().substring(0, 9));
			}
			Collections.sort(switchListHTTPArray);

			for (int i = 0; i < switchListHTTPArray.size(); i++) {
				if (!arrayForValuesFromJson.contains(switchListHTTPArray.get(i))) {
					log.error("UI Switch List (" + arrayForValuesFromJson + ") Does not contain Rest API Switch ("
							+ switchListHTTPArray.get(i) + ")");
					verifySwitchDetails = false;
					break;
				}
			}
		} else {
			jsonArr = new JSONArray(httpJsonArr.get("result").toString());
			log.error("HTTP Response failed for switch " + mgmtIp + " with message : "
					+ jsonArr.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + mgmtIp + " with message : "
					+ jsonArr.getJSONObject(0).get("message"));
		}
		return verifySwitchDetails;
	}

	public JSONArray getJsonForHwSwGenTabs(String switchName, String invType) throws Exception {
		String clickOnTab = "";
		if (invType.contains("switch-info")) {
			clickOnTab = HARDWARE_DETAILS_TAB;
		}
		if (invType.contains("software")) {
			clickOnTab = SOFTWARE_DETAILS_TAB;
		}
		if (invType.contains("fabric-nodes")) {
			clickOnTab = GENRAL_DETAILS_TAB;
		}
		waitForElementToClick(By.xpath(FABRIC_LIST + switchName + "']"));
		retryingFindClick(driver.findElement(By.xpath(FABRIC_LIST + switchName + "']")));
		waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DETAILS_PANEL));
		clickOnWebElement(By.xpath(clickOnTab));
		List<WebElement> keysForJson = driver.findElements(By.xpath(KEYS_FOR_JSON));
		List<WebElement> valuesForJson = driver.findElements(By.xpath(VALUES_FOR_JSON));
		List<String> arrayForKeysFromJson = new ArrayList<String>();
		List<String> arrayForValuesFromJson = new ArrayList<String>();
		for (WebElement keyElement : keysForJson) {
			if (invType.contains("switch-info")) {
				textToBePresentInElement(keyElement.getTagName());
			}
			arrayForKeysFromJson.add(keyElement.getText().replaceAll("\\s", "").toString().toLowerCase());
		}
		for (WebElement valueElement : valuesForJson) {
			if (invType.contains("switch-info")) {
				textToBePresentInElement(valueElement.getTagName());
			}
			if (valuesForJson.get(0).getText().matches("")) {
				driver.findElement(By.xpath(FABRIC_LIST + switchName + "']")).click();
			}
			arrayForValuesFromJson.add(valueElement.getText().replaceAll("\\s", "").replace("-", ""));
		}
		JSONArray jsonArrayFromUI = new JSONArray();
		JSONObject jsonFromUI = new JSONObject();
		for (int i = 0; i < valuesForJson.size(); i++) {
			if (!arrayForValuesFromJson.get(i).toString().matches("")) {
				String keyUI = arrayForKeysFromJson.get(i);
				String valueUI = arrayForValuesFromJson.get(i);
				if (keyUI.contains("system")) {
					keyUI = keyUI.substring(0, 9);
				}
				if (keyUI.contains("hostid")) {
					keyUI = keyUI.substring(4, 6);
				}
				jsonFromUI.put(keyUI, valueUI);
			}
		}
		jsonArrayFromUI.put(jsonFromUI);
		return jsonArrayFromUI;
	}

	public JSONArray getJsonForLicTransTabs(String switchName, String invType) throws Exception {
		String clickOnTab = "";
		if (invType.contains("software-licenses")) {
			clickOnTab = LICENSE_DETAILS_TAB;
		}
		if (invType.contains("port-xcvrs")) {
			clickOnTab = TRANSCEIVERS_DETAILS_TAB;
		}
		waitForElementToClick(By.xpath(FABRIC_LIST + switchName + "']"));
		retryingFindClick(driver.findElement(By.xpath(FABRIC_LIST + switchName + "']")));
		waitForVisibilityOfElementLocated(By.cssSelector(FABRIC_DETAILS_PANEL));
		clickOnWebElement(By.xpath(clickOnTab));
		JSONArray jsonArrayFromUI = new JSONArray();
		List<WebElement> RowCount = driver.findElements(By.xpath(ROWS_COUNT_FOR_JSON_ARRAY));
		List<WebElement> keysForJson = driver.findElements(By.xpath(KEYS_FOR_JSON_ARRAY));
		for (int i = 2; i <= RowCount.size(); i++) {
			List<WebElement> valuesForJson = driver
					.findElements(By.xpath(VALUES_FOR_JSON_ARRAY1 + i + VALUES_FOR_JSON_ARRAY2));
			List<String> arrayForKeysFromJson = new ArrayList<String>();
			List<String> arrayForValuesFromJson = new ArrayList<String>();
			for (WebElement keyElement : keysForJson) {
				arrayForKeysFromJson.add(keyElement.getText().toLowerCase().replaceAll("\\s", "").replace("-", ""));
			}
			for (WebElement valueElement : valuesForJson) {
				arrayForValuesFromJson.add(valueElement.getText().replaceAll("\\s", "").replace("-", ""));
			}
			JSONObject jsonFromUI = new JSONObject();
			for (int p = 0; p < valuesForJson.size(); p++) {
				String keyUI = arrayForKeysFromJson.get(p);
				String valueUI = String.valueOf(arrayForValuesFromJson.get(p));
				jsonFromUI.put(keyUI, valueUI);
			}
			jsonArrayFromUI.put(jsonFromUI);
		}
		return jsonArrayFromUI;
	}

	public JSONArray getJsonFromSwitch(String mgmtIp, String invType, String usrname, String pwd)
			throws ClientProtocolException, IOException {
		JSONArray jsonArr = new JSONArray();
		JSONArray jsonArrayFromSwitch = new JSONArray();
		JSONObject jsonObj = new JSONObject();
		HashMap httpJsonArr = getSwitchHttpResult(mgmtIp, invType, usrname, pwd);
		if (httpJsonArr.get("status").toString().equals("200")) {
			jsonArr = new JSONArray(httpJsonArr.get("data").toString().replaceAll("\\s", "").replace("-", ""));
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonFromSwitch = new JSONObject();
				jsonObj = jsonArr.getJSONObject(i);
				ObjectMapper mapper = new ObjectMapper();
				Map<Object, String> jsonObjMap = mapper.readValue(jsonObj.toString(), Map.class);
				for (Map.Entry<Object, String> switchObjectKeyPair : jsonObjMap.entrySet()) {
					String key = switchObjectKeyPair.getKey().toString();
					String value = String.valueOf(switchObjectKeyPair.getValue());
					if (key.contains("system")) {
						Long systemMemLongValue = Long.parseLong(value);
						int systemMemIntValue = (int) (systemMemLongValue / 1024);
						float actualSystemMem = (float) (systemMemIntValue / 1024) / 1024;
						double roundOffSystemMem = (double) Math.round(actualSystemMem * 100) / 100;
						jsonFromSwitch.put(key, String.valueOf(roundOffSystemMem) + "GB");
					} else {
						jsonFromSwitch.put(key, value);
					}
				}
				jsonArrayFromSwitch.put(jsonFromSwitch);
			}
		} else {
			jsonArrayFromSwitch = new JSONArray(httpJsonArr.get("result").toString());
		}
		return jsonArrayFromSwitch;
	}

	public boolean verifyDiscoveryStatus() throws Exception {
		waitForElementToClick(By.id(CLOSE_FABRIC_DETAILS_WINDOW));
		List<WebElement> switchListUI = driver.findElements(By.xpath(FABRIC_DETAILS_SWITCH_LIST));
		List<WebElement> stateUI = driver.findElements(By.xpath(DISCOVERY_STATUS_ONLINE));
		for (WebElement element : stateUI) {
			if (!element.getText().matches("online")) {
				waitForElementVisibility(element.findElement(By.xpath(DISCOVERY_STATUS_ONLINE)));
			}
		}

		try {
			for (int i = 0; i < stateUI.size(); i++) {

				stateUI.get(i).click();
				waitForVisibilityOfElementLocated(By.xpath(DISCOVERY_STATUS_POP_UP));
				if (!verifyGreenStatus()) {
					log.error("Status is not online");
					clickOnWebElement(By.cssSelector(DISCOVERY_POP_UP_CLOSE_BUTTON));
					return false;

				}
				log.info("Status verification passed");
				if (!verifyCount(switchListUI.get(i).getText())) {
					log.error("Count does not matched");
					clickOnWebElement(By.cssSelector(DISCOVERY_POP_UP_CLOSE_BUTTON));
					return false;
				}
				clickOnWebElement(By.cssSelector(DISCOVERY_POP_UP_CLOSE_BUTTON));
				waitForElementToClick(By.id(CLOSE_FABRIC_DETAILS_WINDOW));
			}
		} catch (Exception e) {
			JavascriptExecutor js = ((JavascriptExecutor) driver);
			js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}

		return true;

	}

	public boolean verifyGreenStatus() {
		List<WebElement> statusHeaderCircle = driver.findElements(By.xpath(DISCOVERY_POP_UP_STATUS_HEADER));
		for (int i = 0; i < statusHeaderCircle.size(); i++) {
			String color = statusHeaderCircle.get(i).findElement(By.xpath(DISCOVERY_STATUS_ONLINE)).getCssValue("color")
					.trim();

			// RGB to HEX
			String color_hex[];
			color_hex = color.replace("rgba(", "").split(",");
			String actual_hex = String.format("#%02x%02x%02x", Integer.parseInt(color_hex[0].trim()),
					Integer.parseInt(color_hex[1].trim()), Integer.parseInt(color_hex[2].trim()));
			if (!DISCOVERY_POP_UP_GREEN_STATUS.equals(actual_hex)) {
				log.error("The status is not green");
				return false;
			}
		}
		return true;

	}

	public Map uiCount() {
		List<WebElement> statusHeader = driver.findElements(By.xpath(DISCOVERY_POP_UP_STATUS_HEADER));
		List<WebElement> headerCount = driver.findElements(By.xpath(DISCOVERY_POP_UP_COUNT));
		Map<String, String> map = new LinkedHashMap<String, String>();
		for (int i = 0; i < statusHeader.size(); i++) {
			String header = statusHeader.get(i).getText();
			String count = headerCount.get(i).getText();
			map.put(header, count);
		}
		return map;

	}

	public boolean verifyCount(String switchName) throws Exception {
		Map<String, String> map = uiCount();

		if (!verifyHeaderCount("PORT", "port-config", switchName, map)) {
			return false;
		}
		if (!verifyHeaderCount("VLAN", "vlan", switchName, map)) {
			return false;
		}
		if (!verifyHeaderCount("VLAG", "vlag", switchName, map)) {
			return false;
		}
		if (!verifyHeaderCount("TRUNK", "trunk", switchName, map)) {
			return false;
		}
		if (!verifyHeaderCount("TRANSCEIVER", "port-xcvr", switchName, map)) {
			return false;
		}

		return true;

	}

	public boolean verifyHeaderCount(String header, String cmd, String switchName, Map<String, String> map)
			throws Exception {
		switchMethod = new SwitchMethods(switchName);
		String command = "switch-local " + cmd + "-show " + " count-output";
		int expectedCount = 0;
		int actualCount = 0;
		expectedCount = switchMethod.terminalCount(command);
		actualCount = Integer.parseInt(map.get(header).split("\\s+")[0].trim());
		log.info("The actual count from ui is for " + header + actualCount);
		if (expectedCount != actualCount) {
			log.error(header + " count does not matched");
			return false;
		}

		return true;
	}
}
