/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/
package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.PageInfra;
import org.testng.Assert;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class VCFLoginPage extends PageInfra {

	@FindBy(name = "username")
	WebElement userNameVCF;

	@FindBy(name = "password")
	WebElement passwordVCF;

	@FindBy(name = "newPassword")
	WebElement newPassword;

	@FindBy(id = "oldPassword")
	WebElement oldPassword;

	@FindBy(id = "confirmNewPassword")
	WebElement confirmNewPassword;

	@FindBy(css = "button.btn.btn-pn-green")
	WebElement loginBtn;

	@FindBy(how = How.CSS, using = "a.fa.fa-cogs")
	WebElement vcfSettingsIcon;

	@FindBy(how = How.CSS, using = "a.fa.fa-home")
	WebElement vcfHomeIcon;

	private static final Logger log = Logger.getLogger(VCFLoginPage.class);

	public VCFLoginPage(WebDriver driver) {
		super(driver);
	}

	// Set user name in textbox
	public void setUserName(String strUserName) {
		waitForElementVisibility(userNameVCF);
		setValue(userNameVCF, strUserName);
	}

	public boolean logout() {
		boolean status = true;
		new NavigationMenu(driver).gotoLogoutMenu();
		waitForElementVisibility(userNameVCF);
		Assert.assertEquals(true, userNameVCF.isDisplayed());
		return status;
	}

	public void gotoHome() {
		vcfHomeIcon.click();
	}

	public void setPassword(String strPassword) {
		waitForElementVisibility(passwordVCF);
		setValue(passwordVCF, strPassword);
	}

	public void setOldPassword(String strPassword) {
		waitForElementVisibility(oldPassword);
		setValue(oldPassword, strPassword);
	}

	public void setNewPassword(String strPassword) {
		waitForElementVisibility(newPassword);
		setValue(newPassword, strPassword);
	}

	public void setConfirmPassword(String strPassword) {
		waitForElementVisibility(confirmNewPassword);
		setValue(confirmNewPassword, strPassword);
	}

	public void clickLogin() {
		waitForElementVisibility(loginBtn);
		retryingFindClick(loginBtn);
	}

	public void firstlogin(String strUserName, String newPassword) {
		login(strUserName, strUserName);
		this.setOldPassword(strUserName);
		this.setNewPassword(newPassword);
		this.setConfirmPassword(newPassword);
		this.clickLogin();
	}

	public void login(String strUserName, String strPasword) {
		this.setUserName(strUserName);
		this.setPassword(strPasword);
		this.clickLogin();
	}
	public void firstloginasUser(String strUserName, String newPassword) {
		login(strUserName, newPassword);
		this.setOldPassword(newPassword);
		this.setNewPassword(newPassword);
		this.setConfirmPassword(newPassword);
		this.clickLogin();
	}
}