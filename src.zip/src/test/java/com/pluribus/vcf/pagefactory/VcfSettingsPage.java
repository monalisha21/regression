/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/
package com.pluribus.vcf.pagefactory;

import com.pluribus.vcf.helper.NavigationMenuConstants;
import com.pluribus.vcf.helper.PageInfra;

import static com.pluribus.vcf.helper.PointFeatureConstants.DROPDOWN_ARROW_ADMIN;
import static com.pluribus.vcf.helper.PointFeatureConstants.DROPDOWN_LIST;
import static com.pluribus.vcf.helper.PointFeatureConstants.DROPDOWN_MENU_ITEM_ADMIN;
import static com.pluribus.vcf.helper.PointFeatureConstants.ALERT_NOTIFICATION;
import static com.pluribus.vcf.helper.PointFeatureConstants.PLURIBUS_WAIT_ICON;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class VcfSettingsPage extends PageInfra {

	@FindBy(how = How.CSS, using = "button.btn-custom.btn-primary.warning")
	WebElement pncCloudbutton;

	@FindBy(how = How.NAME, using = "name")
	WebElement name;

	@FindBy(how = How.ID, using = "username")
	WebElement username;

	@FindBy(how = How.ID, using = "password")
	WebElement password;

	@FindBy(how = How.NAME, using = "ok")
	WebElement okButton;

	@FindBy(how = How.NAME, using = "cancel")
	WebElement cancelButton;

	@FindBy(how = How.CSS, using = "button.btn.btn-sm.btn-primary")
	WebElement addButton;

	@FindBy(how = How.CSS, using = "a.list-group-item.category.config-menu")
	WebElement switchMenu;

	@FindBy(how = How.CSS, using = "a.list-group-item.category.apps-menu")
	WebElement appsMenu;

	@FindBy(how = How.CSS, using = "button.btn.btn-custom.btn-primary")
	WebElement AddAuthServer;

	@FindBy(how = How.NAME, using = "baseDn")
	WebElement baseDn;

	@FindBy(how = How.ID, using = "ldapManagerDn")
	WebElement ldapManagerDn;

	@FindBy(how = How.NAME, using = "ldapManagerPass")
	WebElement ldapManagerPass;

	@FindBy(how = How.NAME, using = "ldapUserDnPatterns")
	WebElement ldapUserDnPatterns;

	@FindBy(how = How.NAME, using = "ldapUserSearchFilter")
	WebElement ldapUserSearchFilter;

	@FindBy(how = How.NAME, using = "hostName")
	WebElement ldapServerUrl;

	@FindBy(how = How.CSS, using = "div#tr_apps_0")
	WebElement appsDetail;

	@FindBy(how = How.CSS, using = "button.btn.btn-primary.btn-xs")
	WebElement addAdmin;

	@FindBy(how = How.CSS, using = "ng-transclude")
	WebElement listLicense;

	@FindBy(how = How.CSS, using = "button.btn.btn-primary")
	WebElement confirmOkButton;

	/* Widget names for findElement(s) calls */
	String authSeedIcon = "span.icon-img-link.fa.fa-pencil";
	String licenseList = "ng-transclude";
	String licenseName = "ng-transclude div.panel.panel-default";
	String msgPopup = "button.close";
	String licenseActivateButton = "button.btn.btn-xs.btn-primary";
	String seedSwitchAddMsgBox = "div.modal-dialog";

	private NavigationMenu menu;
	private static final String LICENSE_STATUS = "//notifications//p[contains(text(),'License:')]";

	private static final Logger log = Logger.getLogger(VcfSettingsPage.class);

	public VcfSettingsPage(WebDriver driver) {
		super(driver);
		menu = new NavigationMenu(driver);
	}

	public void logintoPnc(String usrname, String pwd) throws Exception {
		menu.gotoSettingsLicenseMenu();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pncCloudbutton.click();
		Thread.sleep(2000);
		setValue(username, usrname);
		Thread.sleep(2000);
		setValue(password, pwd);
		Thread.sleep(2000);
		retryingFindClick(okButton);
		Thread.sleep(2000);
		waitForElementVisibility(driver.findElement(By.tagName(licenseList)));
		waitForElementToClick(By.tagName(licenseList));
	}

	// changed in 3.0
	public boolean activateLicense(String usrname, String pwd, LicenseTypes type) throws Exception {
		boolean status = false;
		if (type.toString().equals("UNUM-LIC")) {
			menu.gotoSettingsLicenseMenu();
		} else {
			logintoPnc(usrname, pwd);
		}
		Thread.sleep(10000);
		waitForElementVisibility(listLicense);
		List<WebElement> rows = new ArrayList<WebElement>();
		rows = driver.findElements(By.cssSelector(licenseName));
		for (int i = 0; i < rows.size(); i++) {
			rows = driver.findElements(By.cssSelector(licenseName));
			if (rows.get(i).getText().contains(type.toString())) {
				log.info("License to be selected:" + type.toString());
				Actions actions = new Actions(driver);
				actions.moveToElement(rows.get(i)).perform();
				retryingFindClick(rows.get(i), By.cssSelector(licenseActivateButton));
				status = true;
				if(isElementActive(By.cssSelector(PLURIBUS_WAIT_ICON))) {
					waitForInvisibilityOfElementLocated(By.cssSelector(PLURIBUS_WAIT_ICON));
				}
				break;
			}
		}
		if (isElementActive(By.cssSelector(ALERT_NOTIFICATION))) {
			waitForInvisibilityOfElementLocated(By.cssSelector(ALERT_NOTIFICATION));
		}

		if (status == false) {
			log.error("Couldn't find license " + type.toString() + " for activation");
		} else {
			Thread.sleep(10000);
		}
		return status;
	}

	public boolean verifyLicense() {
		clickOnWebElement(By.cssSelector(NavigationMenuConstants.MENU_BELL_ICON));
		clickOnWebElement(By.xpath(NavigationMenuConstants.MENU_BELL_ICON_LICENSE));
		if (driver.findElement(By.xpath(LICENSE_STATUS)).isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public void closePopUp() {
		List<WebElement> popout = driver.findElements(By.cssSelector(msgPopup));
		if (popout.size() > 0) {
			driver.findElement(By.cssSelector(msgPopup)).click();
		}
	}

	public void addAuthServer(String pwd, String basedn, String ldapmgmtdn, String ldapuserdnPatterns,
			String ldapuserSearchFilter, String ldapmanagerPass) {
		menu.gotoSettingsAuthServerMenu();
		waitForElementVisibility(AddAuthServer);
		AddAuthServer.click();
		setValue(baseDn, basedn);
		setValue(ldapManagerDn, ldapmgmtdn);
		setValue(ldapManagerPass, ldapmanagerPass);
		setValue(ldapUserDnPatterns, ldapuserdnPatterns);
		setValue(ldapUserSearchFilter, ldapuserSearchFilter);
	}

	public void addAuthServer(String serverUrl, String basedn, String ldapmanagerPass, String type) {
		menu.gotoSettingsAuthServerMenu();
		waitForElementVisibility(AddAuthServer);
		AddAuthServer.click();
		selectDropDownValue(By.cssSelector(DROPDOWN_ARROW_ADMIN), By.cssSelector(DROPDOWN_LIST),
				DROPDOWN_MENU_ITEM_ADMIN, type);
		setValue(ldapServerUrl, serverUrl);
		setValue(baseDn, basedn);
		setValue(ldapManagerDn, basedn);
		setValue(ldapManagerPass, ldapmanagerPass);
		okButton.click();
	}
}