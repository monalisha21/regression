package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.adminSettings.ManageAuditLogs;
import com.pluribus.vcf.adminSettings.ManageSystemHealth;
import com.pluribus.vcf.adminSettings.ManageUser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.LicenseTypes;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;

public class AdminSettingTest extends TestSetup {
	private String vcfUserName = "admin";
	private String pncPwd = "test123";
	private String pncuName = "pn-vcf";
	private String addedUserName = "Test";
	private String addedUserPwd = "Test";
	private String vcfPassword = "test123";
	private String addeduserRole = "User";
	private String vmUser = "vcf";
	private String vmPwd = "changeme";
	private VCFLoginPage login;
	private NavigationMenu menu;
	private ManageUser user;
	private ManageAuditLogs audit;
	private ManageSystemHealth sysHealth;
	private VcfSettingsPage settings;
	private String[] switchArr;

	private static final Logger log = Logger.getLogger(AdminSettingTest.class);

	@Parameters({ "vcfIp" })
	@BeforeClass(alwaysRun = true)
	public void init(String vcfIp) throws Exception {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		user = new ManageUser(getDriver());
		audit = new ManageAuditLogs(getDriver());
		settings = new VcfSettingsPage(getDriver());
		sysHealth = new ManageSystemHealth(getDriver(), vcfIp, vmUser, vmPwd);
		loginAsTest123();

	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "addedUserName", "addedUserPwd", "addeduserRole" })
	@Test(groups = { "smoke", "regression" }, description = "User is added")
	public void addUser() {
		if (user.addUser(addedUserName, addedUserPwd, addeduserRole)) {
			log.info("User is added sucessfully");
		} else {
			log.error("User is not added");
		}

		login.logout();

	}

	@Parameters({ "fabricName", "switchNames" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "addUser" }, description = "verify the user roles")
	public void verifyUserRoles(String fabricName, String switchNames) {
		login.firstlogin(addedUserName, vcfPassword);
		switchArr = switchNames.split(" ");
		if (!user.verifyUserRole(fabricName, switchArr[3])) {
			log.error("verification failed");
		}
		log.info("verification passed");
		login.logout();

	}

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "verifyUserRoles" }, description = "delete the user")
	public void verifyUserRolesDelete() throws InterruptedException {
		login.login(vcfUserName, vcfPassword);

		if (!user.deleteUser()) {
			log.error("user deletion failed");
		}
		log.info("user deletion passed");
	}

	@Parameters({ "CollectorName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyUserRolesDelete" }, description = "audit logs")
	public void verifyAuditLogs(String collectorName) throws Exception {
		if (!settings.activateLicense(pncuName, pncPwd, LicenseTypes.UNUM_LIC)) {
			log.error("License activation failed");
			throw new Exception("Activate License failed");
		} else {
			if (settings.verifyLicense()) {
				log.info("License activation was successful");
			} else {
				log.error("License activation failed");
				throw new Exception("Activate License failed");
			}
		}

		if (!audit.verifyAuditLogs(collectorName)) {
			throw new Exception("audit logs test failed");
		} else {
			log.info("audit logs test passed");
		}
	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyAuditLogs" }, description = "check system Health")
	public void verifySystemHealth() throws Exception {

		log.info("looged in to Vm");
		if (!sysHealth.verifySystemHealthNodeData()) {

			throw new Exception("SystemHealth Node Verification failed");
		} else {
			log.info("SystemHealth Node Verification Passed");
		}
		if (!sysHealth.verifySystemHealthIndicesData()) {

			throw new Exception("SystemHealth Indices Verification failed");
		} else {
			log.info("SystemHealth Indices Verification Passed");
		}
	}
}