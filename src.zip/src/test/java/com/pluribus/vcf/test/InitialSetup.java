/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/

package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.LicenseTypes;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.ManageCollector;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;
import com.pluribus.vcf.helper.RunResetSwitches;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;

public class InitialSetup extends TestSetup {

	private String pncPwd = "test123";
	private String pncuName = "pn-vcf";
	private String vcfUserName = "admin";
	private VCFLoginPage login;
	private VcfSettingsPage settings;
	private NavigationMenu menu;
	private ManageCollector manageCollector;
	private TopologyPage topology;
	private SwitchMethods[] cli;
	private String[] switchArr;

	private static final Logger log = Logger.getLogger(InitialSetup.class);

	@Parameters({ "switchNames", "fabricName", "iperfServerName", "iperfClientName", "enableTraffic" })
	@BeforeTest(alwaysRun = true)
	public boolean loadSmokeConfig(String switchNames, String fabricName, String host1, String host2, @Optional("1") String enableTraffic) throws Exception{
		boolean status = true;
		log.info("Configuring fabric on switches");
		switchArr = switchNames.split(" ");

		//Initializing threads and the cli handles based on # of switches in switchNames parameter
		cli = new SwitchMethods[switchArr.length];

		//Reset on all switches
		for(int i = 0; i < switchArr.length; i++) {
			cli[i] = new SwitchMethods(switchArr[i]);
			status &= cli[i].deleteSnmp(switchArr[i]);
			cli[i].resetSwitch();
		}

		//Fabric create and join on all switches
		cli[0].createFabric(fabricName);
		for(int i = 1; i < switchArr.length; i++) {
			if(!cli[i].joinFabric(fabricName)) {
				log.error("Joining fabric "+fabricName+" failed on switch "+ switchArr[i]);
				throw new Exception("Join fabric on "+ switchArr[i]+" failed");
			}
		}


		//Configuration required for iperf
		if (Integer.parseInt(enableTraffic) == 1) {
			log.info("Configuring switches for iperf traffic");
			//Configuring switch 1
			status &= cli[0].enableWeb();
			status &= cli[0].configSwitchName(switchArr[0]);
			status &= cli[0].clusterConfig(switchArr[1], "spineCluster");
			status &= cli[0].vlanCreate(30);
			status &= cli[0].vrouterCreate(fabricName, 18);
			status &= cli[0].vrouterIfCreate("30.1.1.2/24", "30.1.1.1/24", 30, 18, 110);
			status &= cli[0].vrouterIfCreate("20.1.1.1/30", 49);
			status &= cli[0].vrouterIfCreate("20.1.1.9/30", 53);
			status &= cli[0].configOspf("30.1.1.0/24", 0);
			status &= cli[0].configOspf("20.1.1.0/30", 0);
			status &= cli[0].configOspf("20.1.1.8/30", 0);
			status &= cli[0].vlagCreate("toServer", 1, 1);
			status &= cli[0].createUntaggedPorts(30, 1);
			if(status == false) {
				log.error("Switch configuration on "+ switchArr[0] + " failed");
				throw new Exception("Switch configuration on"+ switchArr[0]+" failed");
			}

			//Configuring switch 2
			status &= cli[1].configSwitchName(switchArr[1]);
			status &= cli[1].vrouterCreate(fabricName, 18);
			status &= cli[1].vrouterIfCreate("30.1.1.3/24", "30.1.1.1/24", 30, 18, 109);
			status &= cli[1].vrouterIfCreate("20.1.1.5/30", 49);
			status &= cli[1].vrouterIfCreate("20.1.1.13/30", 53);
			status &= cli[1].configOspf("30.1.1.0/24", 0);
			status &= cli[1].configOspf("20.1.1.4/30", 0);
			status &= cli[1].configOspf("20.1.1.12/30", 0);
			status &= cli[1].createUntaggedPorts(30, 1);

			if(status == false) {
				log.error("Switch configuration on "+ switchArr[1] + " failed");
				throw new Exception("Switch configuration on"+ switchArr[1]+" failed");
			}

			//Configuring switch 3
			status &= cli[2].clusterConfig(switchArr[3], "leafCluster");
			status &= cli[2].vlanCreate(40);
			status &= cli[2].vrouterCreate(fabricName, 20);
			status &= cli[2].vrouterIfCreate("40.1.1.2/24", "40.1.1.1/24", 40, 20, 110);
			status &= cli[2].vrouterIfCreate("20.1.1.2/30", 49);
			status &= cli[2].vrouterIfCreate("20.1.1.6/30", 53);
			status &= cli[2].configOspf("40.1.1.0/24", 0);
			status &= cli[2].configOspf("20.1.1.0/30", 0);
			status &= cli[2].configOspf("20.1.1.4/30", 0);
			status &= cli[2].vlagCreate("toClient", 5, 5);
			status &= cli[2].createUntaggedPorts(40, 5);

			if(status == false) {
				log.error("Switch configuration on "+ switchArr[2] + " failed");
				throw new Exception("Switch configuration on"+ switchArr[2]+" failed");
			}

			//Configuring switch 4
			status &= cli[3].vrouterCreate(fabricName, 20);
			status &= cli[3].vrouterIfCreate("40.1.1.3/24", "40.1.1.1/24", 40, 20, 109);
			status &= cli[3].vrouterIfCreate("20.1.1.10/30", 49);
			status &= cli[3].vrouterIfCreate("20.1.1.14/30", 53);
			status &= cli[3].configOspf("40.1.1.0/24", 0);
			status &= cli[3].configOspf("20.1.1.8/30", 0);
			status &= cli[3].configOspf("20.1.1.12/30", 0);
			status &= cli[3].createUntaggedPorts(40, 5);
			if(status == false) {
				log.error("Switch configuration on "+ switchArr[3] + " failed");
				throw new Exception("Switch configuration on"+ switchArr[3]+" failed");
			} else {
				log.info("Completed switch configuration for iperf traffic");
			}

			for(int i = 0; i < switchArr.length; i++) {
				cli[i].exitSession();
			}

			//Host1 config
			SwitchMethods hostCli = new SwitchMethods(host1);
			hostCli.configureBondInterface("bond0","p1p1","p1p2");
			hostCli.modifyInterfaceIp("bond0","30.1.1.10/24");
			hostCli.addStaticRouteHost("40.1.1.0/24","30.1.1.1","bond0");
			hostCli.exitSession();

			//Host2 config
			hostCli = new SwitchMethods(host2);
			hostCli.configureBondInterface("bond0","p1p1","p1p2");
			hostCli.modifyInterfaceIp("bond0","40.1.1.10/24");
			hostCli.addStaticRouteHost("30.1.1.0/24","40.1.1.1","bond0");
			hostCli.exitSession();

		} else {
			log.info("Skipping traffic configuration");
		}
		return status;
	}

	@BeforeClass(alwaysRun=true)
	public void init() {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		settings = new VcfSettingsPage(getDriver());
		manageCollector = new ManageCollector(getDriver());
		topology = new TopologyPage(getDriver());
	}

	@Parameters({ "password" })
	@Test(groups = { "smoke", "regression" }, description = "Login to VCF as admin  and Change Password")
	public void loginAsAdmin(@Optional("test123") String password) throws Exception {
		login.firstlogin(vcfUserName, password);
		login.logout();
	}

	@Parameters({ "password" })
	@Test(groups = { "smoke", "regression" },dependsOnMethods = {"loginAsAdmin"}, description = "Login to VCF as test123 After Password Change")
	public void loginAsTest123(@Optional("test123") String password) throws Exception {
		login.login(vcfUserName, password);
	}

	@Parameters({"switchNames","mgmtIp", "switchUserName", "switchPassword"})
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {"activateLicense" }, description = "Add Seed Switch & verify")
	public void addSeedSwitch(String switchNames, String mgmtIp, String switchUserName, String switchPassword) throws Exception {
		topology.addFabric(switchArr[0], mgmtIp, switchUserName, switchPassword);
		log.info("Successfully added & verified seed switch " + switchArr[0]);
	}

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {"loginAsTest123" }, description = "Activate License")
	public void activateLicense() throws Exception {
		if (!settings.activateLicense(pncuName, pncPwd, LicenseTypes.VCFC_DEMO_100M)) {
			log.error("License activation failed");
			throw new Exception("Activate License failed");
		} else {
			if(settings.verifyLicense()){
				log.info("License activation was successful");
			} else {
				log.error("License activation failed");
				throw new Exception("Activate License failed");
			}
		}
	}

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {"addSeedSwitch" }, description = "Logout of VCFC")
	public void logout() throws Exception{
		if(!login.logout()) {
			log.error("Logout test failed");
			throw new Exception("Logout failed");
		} else {
			log.info("Logout test succeeded");
		}
	}

}
