package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.adminSettings.ManageAuditLogs;
import com.pluribus.vcf.adminSettings.ManageLdapUser;
import com.pluribus.vcf.adminSettings.ManageSystemHealth;
import com.pluribus.vcf.adminSettings.ManageUser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;

public class LDAPIntegrationTest extends TestSetup {
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String ldapUserName = "adminuser";
	private String ldapUserPwd = "login1-2";
	private String ldapGroup = "admingrp";
	private VCFLoginPage login;
	private NavigationMenu menu;
	private ManageUser user;
	private String[] switchArr;
	private ManageLdapUser ldapUser;

	private static final Logger log = Logger.getLogger(LDAPIntegrationTest.class);

	@Parameters({ "vcfIp" })
	@BeforeClass(alwaysRun = true)
	public void init(String vcfIp) throws Exception {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		user = new ManageUser(getDriver());
		ldapUser = new ManageLdapUser(getDriver());
		loginAsTest123();

	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "ldapServerIp" })
	@Test(groups = { "smoke", "regression" }, description = "ldap user addition")
	public void AddLdapUser(String ldapServerIp) throws Exception {
		if (ldapUser.addLdapUser(ldapUserName, ldapUserPwd, ldapGroup, ldapServerIp)) {
			log.info("Ldap User is added sucessfully");
		} else {
			log.error("Ldap User is not added");
			throw new Exception("Ldap User is not added");
		}

	}

	@Parameters({ "ldapServerIp" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "AddLdapUser" }, description = "ldap user Test")
	public void TestLdapUser(String ldapServerIp) throws Exception {
		if (ldapUser.testLdapUser(ldapUserName, ldapUserPwd)) {
			log.info("Ldap user test is  sucessfully");
		} else {
			log.error("Ldap user test is failed");
			throw new Exception("Ldap user test is failed");

		}

		login.logout();

	}

	@Parameters({ "fabricName", "switchNames" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"TestLdapUser" }, description = "verify the user roles")
	public void verifyUserRoles(String fabricName, String switchNames) throws Exception {
		login.login(ldapUserName, ldapUserPwd);
		switchArr = switchNames.split(" ");
		if (user.verifyUserRole(fabricName, switchArr[3])) {
			log.info("Ldap user role verification passed");

		} else {
			log.error("verification failed");
			throw new Exception("Ldap user role verification failed");
		}
		login.logout();

	}

	@Parameters({ "ldapServerIp" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyUserRoles" }, description = "ldap user deletion")
	public void DeleteLdapUser(String ldapServerIp) throws Exception {
		login.login(vcfUserName, vcfPassword);
		if (ldapUser.deleteLdapUser()) {
			log.info("Delete ldap user is  sucessfully");
		} else {
			log.error("Delete Ldap user is not failed");
			throw new Exception("Delete Ldap user is not failed");
		}

		login.logout();

	}

}
