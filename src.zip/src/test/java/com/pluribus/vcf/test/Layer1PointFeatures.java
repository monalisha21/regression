package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestDataParser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.ManageLayer1;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.PointFeatures;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;

public class Layer1PointFeatures extends TestSetup {
	com.pluribus.vcf.helper.TestDataParser parser;
	private static final Logger log = Logger.getLogger(Layer1PointFeatures.class);
	private NavigationMenu menu;
	private VCFLoginPage login;
	private TopologyPage topology;
	private ManageLayer1 manageLayer1;
	private PointFeatures pf;
	private PointFeaturesMethod pfm;
	private SwitchMethods switchCli;
	private String[] switchArr;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String switchUser;
	private String switchPwd;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "jsonLayer1", "switchUserName", "switchPassword"})
	public void init(String jsonFile, String switchUserName, String switchPassword) throws Exception {
		switchUser = switchUserName;
		switchPwd = switchPassword;

		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		topology = new TopologyPage(getDriver());
		manageLayer1 = new ManageLayer1(getDriver());

		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		pfm.setupJsonData();
		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "fabricName", "switchNames" })

	@Test(groups = { "smoke", "regression" }, description = "Edit SwitchMode")
	public void ShowPortConfig(String fabricName, String switchNames) throws Exception {
		switchArr = switchNames.split(" ");
		topology.selectSwitchInMenu(switchArr[2], fabricName);
		log.info(switchArr[2] + "switch selected");
		if (menu.gotoMenu("Manage", "Layer 1", "Manage Ports"))
			if (!manageLayer1.verifyPortNos(switchArr[2])) {
				log.info("Show Port_Config Test Failed");
				;
			} else {
				log.info("Show Port_Config Test test passed");
			}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "ShowPortConfig" }, description = "Edit SwitchMode")
	public void EditPortConfig(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "edit_port_config", "PortConfig", switchUser, switchPwd)) {
			throw new Exception("Edit Port_Config Test failed");
		} else {
			log.info("Edit Port_Config Test test passed");
		}
	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout() throws InterruptedException {
		login.logout();
	}
}
