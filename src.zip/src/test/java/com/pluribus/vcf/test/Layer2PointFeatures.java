package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.TestDataParser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.ManageVlan;
import com.pluribus.vcf.pagefactory.ManageVlag;
import com.pluribus.vcf.pagefactory.Trunks;
import com.pluribus.vcf.pagefactory.ManageCluster;
import com.pluribus.vcf.pagefactory.PointFeatures;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import org.testng.annotations.DataProvider;

public class Layer2PointFeatures extends TestSetup {
	com.pluribus.vcf.helper.TestDataParser parser;
	private static final Logger log = Logger.getLogger(Layer2PointFeatures.class);
	private VCFLoginPage login;
	private PointFeaturesMethod pfm;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String switchUser;
	private String switchPwd;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "jsonFile", "switchUserName", "switchPassword" })
	public void init(String jsonFile, String switchUserName, String switchPassword) throws Exception {
		switchUser = switchUserName;
		switchPwd = switchPassword;
		login = new VCFLoginPage(getDriver());
		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		pfm.setupJsonData();

		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create  a new test VLAN")
	public void createVlanTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Create VLAN test failed");
		} else {
			log.info("Create VLAN test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, description = "Fabric level Vlan validation", priority = 1)
	public void fabricLevelVerificationOfVlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_Vlan_Validation", "vlan", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Vlan test failed");
		} else {
			log.info("fabric Validation for Vlan test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVlanTest" }, description = "Add ports to an existing VLAN")
	public void addPortsToVlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "add_ports_vlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Add ports to VLAN test failed");
		} else {
			log.info("Add ports to VLAN test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"addPortsToVlan" }, description = "Remove ports from an existing VLAN")
	public void removePortsFromVlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "remove_ports_vlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Remove ports from VLAN test failed");
		} else {
			log.info("Remove ports from VLAN test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"removePortsFromVlan" }, description = "Delete test-vlan")
	public void deleteVlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Delete VLAN test failed");
		} else {
			log.info("Delete VLAN test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteVlan" }, description = "Create test-trunk")
	public void createTrunk(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_trunk", "trunk", switchUser, switchPwd)) {
			throw new Exception("Create trunk test failed");
		} else {
			log.info("Create trunk test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createTrunk" }, description = "Create a test VLAG")
	public void createVlag(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vlag", "vlag", switchUser, switchPwd)) {
			throw new Exception("Create VLAG test failed");
		} else {
			log.info("Create VLAG test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createTrunk" }, description = "FabricLevel Trunk validation")
	public void fabricLevelVerificationOfTrunk(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_Trunk_Validation", "trunk", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Trunk test failed");
		} else {
			log.info("fabric Validation for Trunk test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVlag" }, description = "fabric level vlag validation")
	public void fabricLevelVerificationOfVlag(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_Vlag_Validation", "vlag", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Vlag test failed");
		} else {
			log.info("fabric Validation for Vlag test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createVlag" }, description = "Delete test VLAG")
	public void deleteVlag(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vlag", "vlag", switchUser, switchPwd)) {
			throw new Exception("Delete VLAG test failed");
		} else {
			log.info("Delete VLAG test passed");
		}
	}

	// Delete trunk
	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteVlag" }, description = "Delete trunk")
	public void deleteTrunk(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_trunk", "trunk", switchUser, switchPwd)) {
			throw new Exception("Delete trunk test failed");
		} else {
			log.info("Delete trunk test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteTrunk" }, description = "Create L2 cluster")
	public void createCluster(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_cluster", "cluster", switchUser, switchPwd)) {
			throw new Exception("Create cluster test failed");
		} else {
			log.info("Create cluster test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createCluster" }, description = "Delete L2 cluster")
	public void deleteCluster(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_cluster", "cluster", switchUser, switchPwd)) {
			throw new Exception("Delete cluster test failed");
		} else {
			log.info("Delete cluster test passed");
		}
	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout() throws InterruptedException {
		login.logout();
	}
}