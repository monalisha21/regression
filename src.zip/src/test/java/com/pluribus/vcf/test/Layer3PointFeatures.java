package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.TestDataParser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.ManagevRouter;
import com.pluribus.vcf.pagefactory.ManageOSPF;
import com.pluribus.vcf.pagefactory.ManageBGP;
import com.pluribus.vcf.pagefactory.PointFeatures;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import org.testng.annotations.DataProvider;
import java.util.Arrays;

public class Layer3PointFeatures extends TestSetup {
	com.pluribus.vcf.helper.TestDataParser parser;
	private static final Logger log = Logger.getLogger(Layer3PointFeatures.class);
	private VCFLoginPage login;
	private PointFeaturesMethod pfm;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String switchUser;
	private String switchPwd;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "layer3JsonFile", "switchUserName", "switchPassword" })
	public void init(String jsonFile, String switchUserName, String switchPassword) throws Exception {
		switchUser = switchUserName;
		switchPwd = switchPassword;
		login = new VCFLoginPage(getDriver());
		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		pfm.setupJsonData();

		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, description = "Fabric level vrouter Validation", priority = 0)
	public void fabricLevelVerificationOfVRouter(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_VRouter_Validation", "vrouter", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Vrouter test failed");
		} else {
			log.info("fabric Validation for Vrouter test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create  a new test vrouter", priority = 1)
	public void createVrouterTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vrouter_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter test failed");
		} else {
			log.info("Create vRouter test passed");
		}
		if (!pfm.executePfTests(fabricName, "create_vrouter_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter test failed");
		} else {
			log.info("Create vRouter test passed");
		}

	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVrouterTest" }, description = "Create  a new test vrouter interface")
	public void addVRouterInterfaceTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vrouter_interfaces_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter interfaces test failed");
		} else {
			log.info("Create vRouter interfaces test passed");
		}
		if (!pfm.executePfTests(fabricName, "create_vrouter_interfaces_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter interfaces test failed");
		} else {
			log.info("Create vRouter interfaces test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"addVRouterInterfaceTest" }, description = "Add OSPF protocol")
	public void addOspfTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "add_ospf_1", "ospf", switchUser, switchPwd)) {
			throw new Exception("Add OSPF test failed");
		} else {
			log.info("Add OSPF test passed");
		}
		if (!pfm.executePfTests(fabricName, "add_ospf_2", "ospf", switchUser, switchPwd)) {
			throw new Exception("Add OSPF test failed");
		} else {
			log.info("Add OSPF test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "addOspfTest" }, description = "Add OSPF protocol")
	public void ospfNeighborVerificationTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "verify_ospf_1", "ospf", switchUser, switchPwd)) {
			throw new Exception("Verify OSPF neighbors test failed");
		} else {
			log.info("OSPF neighbor verification test passed");
		}
		if (!pfm.executePfTests(fabricName, "verify_ospf_2", "ospf", switchUser, switchPwd)) {
			throw new Exception("Verify OSPF neighbors test failed");
		} else {
			log.info("OSPF neighbor verification test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"ospfNeighborVerificationTest" }, description = "Delete OSPF protocol")
	public void deleteOspfTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_ospf_1", "ospf", switchUser, switchPwd)) {
			throw new Exception("Delete OSPF test failed");
		} else {
			log.info("Delete OSPF test passed");
		}
		if (!pfm.executePfTests(fabricName, "delete_ospf_2", "ospf", switchUser, switchPwd)) {
			throw new Exception("Delete OSPF test failed");
		} else {
			log.info("Delete OSPF test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteOspfTest" }, description = "Delete vRouter Interface")
	public void deleteVRouterInterfaceTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vrouter_interfaces_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vRouter interfaces test failed");
		} else {
			log.info("Delete vRouter interfaces test passed");
		}
		if (!pfm.executePfTests(fabricName, "delete_vrouter_interfaces_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vRouter interfaces test failed");
		} else {
			log.info("Delete vRouter interfaces test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteVRouterInterfaceTest" }, description = "Delete vrouter")
	public void deleteVRouterTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vrouter_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vRouter test failed");
		} else {
			log.info("Delete vRouter test passed");
		}
		if (!pfm.executePfTests(fabricName, "delete_vrouter_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vRouter test failed");
		} else {
			log.info("Delete vRouter test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteVRouterTest" }, description = "Create  a new test vrouter")
	public void createBgpVrouter(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_bgp_vrouter_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter for BGP test failed");
		} else {
			log.info("Create vRouter for BGP test passed");
		}

		if (!pfm.executePfTests(fabricName, "create_bgp_vrouter_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter for BGP test failed");
		} else {
			log.info("Create vRouter for BGP test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createBgpVrouter" }, description = "Create vrouter interfaces")
	public void createBgpVrouterInterfaces(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_bgp_vrouter_intf_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter interface for BGP test failed");
		} else {
			log.info("Create vRouter interface for BGP test passed");
		}

		if (!pfm.executePfTests(fabricName, "create_bgp_vrouter_intf_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Create vRouter interface for BGP test failed");
		} else {
			log.info("Create vRouter interface for BGP test passed");
		}

	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createBgpVrouterInterfaces" }, description = "Add BGP configuration")
	public void addBgpConfig(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "add_bgp_1", "bgp", switchUser, switchPwd)) {
			throw new Exception("Configure BGP test failed");
		} else {
			log.info("Configure BGP test passed");
		}

		if (!pfm.executePfTests(fabricName, "add_bgp_2", "bgp", switchUser, switchPwd)) {
			throw new Exception("Configure BGP test failed");
		} else {
			log.info("Configure BGP test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"addBgpConfig" }, description = "Verify BGP Neighbors")
	public void verifyBgpNeighbors(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "verify_bgp_1", "bgp", switchUser, switchPwd)) {
			throw new Exception("BGP neighbors validation failed");
		} else {
			log.info("BGP neighbors validation passed");
		}

		if (!pfm.executePfTests(fabricName, "verify_bgp_2", "bgp", switchUser, switchPwd)) {
			throw new Exception("BGP neighbors validation failed");
		} else {
			log.info("BGP neighbors validation passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyBgpNeighbors" }, description = "Delete BGP configuration")
	public void deleteBgpConfig(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_bgp_1", "bgp", switchUser, switchPwd)) {
			throw new Exception("Delete BGP config failed");
		} else {
			log.info("Delete BGP config passed");
		}

		if (!pfm.executePfTests(fabricName, "delete_bgp_2", "bgp", switchUser, switchPwd)) {
			throw new Exception("Delete BGP config failed");
		} else {
			log.info("Delete BGP config passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteBgpConfig" }, description = "Delete BGP configuration")
	public void deleteBgpVrouterInterfaces(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vrouter_intf_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete BGP vrouter interface config failed");
		} else {
			log.info("Delete BGP vrouter interface config passed");
		}

		if (!pfm.executePfTests(fabricName, "delete_vrouter_intf_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete BGP vrouter interface config failed");
		} else {
			log.info("Delete BGP vrouter interface config passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteBgpVrouterInterfaces" }, description = "Delete BGP configuration")
	public void deleteBgpVrouter(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_bgp_vrouter_1", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vrouter failed");
		} else {
			log.info("Delete vrouter passed");
		}

		if (!pfm.executePfTests(fabricName, "delete_bgp_vrouter_2", "vrouter", switchUser, switchPwd)) {
			throw new Exception("Delete vrouter failed");
		} else {
			log.info("Delete vrouter passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create vrf", priority = 2)
	public void createVRF(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vrf", "vrf", switchUser, switchPwd)) {
			throw new Exception("Create vrf failed");
		} else {
			log.info("Create vrf passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVRF" }, description = "Create  a new test VXLAN")
	public void createVxlanTest(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vxlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Create VXLAN test failed");
		} else {
			log.info("Create VXLAN test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createVxlanTest" }, description = "Create subnet")
	public void createSubnet(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_subnet", "subnet", switchUser, switchPwd)) {
			throw new Exception("Create subnet failed");
		} else {
			log.info("Create subnet passed");
		}
	}
	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createSubnet" }, description = "Create tunnel")
	public void createTunnel(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_tunnel", "tunnel", switchUser, switchPwd)) {
			throw new Exception("Create tunnel failed");
		} else {
			log.info("Create tunnel passed");
		}
	}
	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createTunnel" }, description = "Add tunnel vxlan")
	public void addTunnelVxlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Add_tunnel_vxlan", "tunnel", switchUser, switchPwd)) {
			throw new Exception("Add tunnel_vxlan failed");
		} else {
			log.info("Add tunnel_vxlan passed");
		}
	}
	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "addTunnelVxlan" }, description = "Delete tunnel vxlan")
	public void deleteTunnelVxlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_tunnel_vxlan", "tunnel", switchUser, switchPwd)) {
			throw new Exception("delete tunnel_vxlan failed");
		} else {
			log.info("delete tunnel_vxlan passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteTunnelVxlan" }, description = "Delete subnet")
	public void deleteSubnet(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_subnet", "subnet", switchUser, switchPwd)) {
			throw new Exception("delete subnet failed");
		} else {
			log.info("delete subnet passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteSubnet" }, description = "Delete vrf")
	public void deleteVRF(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vrf", "vrf", switchUser, switchPwd)) {
			throw new Exception("delete vrf failed");
		} else {
			log.info("delete vrf passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteVRF" }, description = "Delete test-vxlan")
	public void deleteVlan(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vxlan", "vlan", switchUser, switchPwd)) {
			throw new Exception("Delete VXLAN test failed");
		} else {
			log.info("Delete VXLAN test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" },dependsOnMethods = { "deleteVlan" },  description = "Delete tunnel")
	public void deleteTunnel(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_tunnel", "tunnel", switchUser, switchPwd)) {
			throw new Exception("delete tunnel failed");
		} else {
			log.info("delete tunnel passed");
		}
	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout() throws InterruptedException {
		login.logout();
	}
}