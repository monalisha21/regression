package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.PlaybookHelper;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;

public class NetvisorEnterprisePlaybooks extends TestSetup {
	private VCFLoginPage login;
	private String vcfUserName = "admin";
	private PlaybookHelper playbookHelper;
	private static final Logger log = Logger.getLogger(NetvisorEnterprisePlaybooks.class);

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		login = new VCFLoginPage(getDriver());
		playbookHelper = new PlaybookHelper(getDriver());
	}

	@Parameters({ "password" })
	@BeforeClass(groups = { "smoke", "regression" }, description = "Login to VCF as test123 After Password Change")
	public void loginTest123(@Optional("test123") String password) throws Exception {
		login.login(vcfUserName, password);
	}

	@Parameters({ "1switchHostFile", "6switchVrrpCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "1switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L2 Single Switch", priority = 7)
	public void runL2SingleSwitchPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L2 Single Switch";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "2switchHostFile", "6switchVrrpCsvFile", "2switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L2 Two Switch Cluster playbook", priority = 8)
	public void runvrrpPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L2 Two Switch Cluster";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "2switchHostFile", "6switchVrrpCsvFile", "2switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L2 Cluster with VRRP playbook", priority = 9)
	public void runL2ClusterPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L2 Cluster with VRRP";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "1switchHostFile", "6switchVrrpCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L3 Single Routed BGP", priority = 10)
	public void runL3SingleRoutedBGPPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L3 Single Routed BGP";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "1switchHostFile", "6switchVrrpCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L3 Single Routed OSPF", priority = 11)
	public void runL3SingleRoutedOSPFPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L3 Single Routed OSPF";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "2switchHostFile", "6switchVrrpCsvFile", "2switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L3 BGP - VRRP playbook", priority = 12)
	public void runvrrpBgpPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L3 BGP with VRRP";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "2switchHostFile", "6switchVrrpCsvFile", "2switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "2switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke", "regression" }, description = "Configure L3 OSPF - VRRP playbook", priority = 13)
	public void runvrrpOspfPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L3 OSPF with VRRP";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "1switchHostFile", "6switchVrrpCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "1switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke",
			"regression" }, description = "Configure L3 Single Routed BGP with L2 playbook", priority = 14)
	public void runL3SingleRoutedBGPwithL2Playbook(String hostFile, String csvFile, String vlanCsvFile,
			String vrrpCsvFile, String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile,
			String vlagCsvFile, @Optional("test123") String password, @Optional("") String playbook,
			String collectorName, String gatewayIp, String inbandIp) throws Exception {
		String testPlaybookName = "L3 Single Routed BGP with L2";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "1switchHostFile", "6switchVrrpCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "1switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "CollectorName", "gatewayIp", "3rdpartyInbandIp" })
	@Test(groups = { "smoke",
			"regression" }, description = "Configure L3 Single Routed OSPF with L2 playbook", priority = 15)
	public void runL3SingleRoutedOSPFwithL2Playbook(String hostFile, String csvFile, String vlanCsvFile,
			String vrrpCsvFile, String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile,
			String vlagCsvFile, @Optional("test123") String password, @Optional("") String playbook,
			String collectorName, String gatewayIp, String inbandIp) throws Exception {
		String testPlaybookName = "L3 Single Routed OSPF with L2";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@AfterClass(groups = { "regression" }, description = "Logout of VCFC")
	public void logout() throws Exception {
		if (!login.logout()) {
			log.error("Logout test failed");
			throw new Exception("Logout failed");
		} else {
			log.info("Logout test succeeded");
		}
	}
}