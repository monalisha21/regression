package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.helper.PlaybookHelper;
import com.pluribus.vcf.helper.RunVerificationPlaybook;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;

public class NetvisorFabricOSPFand3rdPartyPlaybook extends TestSetup {
	private VCFLoginPage login;
	private String vcfUserName = "admin";
	private RunVerificationPlaybook runPlaybook;
	private PlaybookHelper playbookHelper;
	private static final Logger log = Logger.getLogger(NetvisorFabricOSPFand3rdPartyPlaybook.class);

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		login = new VCFLoginPage(getDriver());
		playbookHelper = new PlaybookHelper(getDriver());
	}

	@Parameters({ "password", "vcfIp" })
	@BeforeClass(groups = { "regression" }, description = "Login to VCF as test123 After Password Change")
	public void loginAsTest123(@Optional("test123") String password, String vcfIp) throws Exception {
		login.login(vcfUserName, password);
	}

	@Parameters({ "6switchHostFile", "6switchOspfCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "1switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "vcfIp", "playbookYml", "playbookPy", "vcfPassword", "CollectorName", "gatewayIp",
			"3rdpartyInbandIp" })
	@Test(groups = { "regression" }, description = "Configure L3 VRRP OSPF playbook", priority = 3)
	public void runL3OspfPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String vcfIp, String playbookYml,
			String playbookPy, @Optional("changeme") String vcfPassword, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String verifPlaybookName = "pn_test_l3_vrrp_ospf.yml";
		String testPlaybookName = "L3 VRRP OSPF";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
			// Running playbookVerification
			runPlaybook = new RunVerificationPlaybook(vcfIp, playbookYml, playbookPy, verifPlaybookName, vcfPassword,
					hostFile, csvFile);
			Thread t_verify = new Thread(runPlaybook);
			t_verify.start();
			while (t_verify.isAlive()) {
				keepSessionActive();
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@Parameters({ "6switchHostFile", "6switchOspfCsvFile", "1switchVlanCsvFile", "2switchVrrpCsvFile", "sviCsvFile",
			"2switchBgpCsvFile", "2switchOspfCsvFile", "1switchTrunkCsvFile", "2switchVlagCsvFile", "password",
			"selectedPlaybook", "vcfIp", "playbookYml", "playbookPy", "vcfPassword", "CollectorName", "gatewayIp",
			"3rdpartyInbandIp" })
	@Test(groups = { "regression" }, description = "Configure L3 VRRP OSPF with existing spines playbook", priority = 4)
	public void runL3OSPFThirdPartyPlaybook(String hostFile, String csvFile, String vlanCsvFile, String vrrpCsvFile,
			String sviCsvFile, String bgpCsvFile, String ospfCsvFile, String trunkCsvFile, String vlagCsvFile,
			@Optional("test123") String password, @Optional("") String playbook, String vcfIp, String playbookYml,
			String playbookPy, @Optional("changeme") String vcfPassword, String collectorName, String gatewayIp,
			String inbandIp) throws Exception {
		String testPlaybookName = "L3 VRRP OSPF with existing spines";
		if ((playbook.equals("")) || (playbook.equals(testPlaybookName))) {
			// L3 VRRP OSPF with existing spines playbook execution
			if (playbookHelper.playbookTestHelper(hostFile, password, collectorName, gatewayIp, inbandIp, csvFile,
					vlanCsvFile, vrrpCsvFile, sviCsvFile, bgpCsvFile, ospfCsvFile, trunkCsvFile, vlagCsvFile,
					testPlaybookName)) {
				log.info("Playbook " + testPlaybookName + " passed successfully");
			} else {
				log.error("Playbook " + testPlaybookName + " failed");
			}
		} else {
			log.info("Skipping " + testPlaybookName + " playbook as it is not required by configuration");
		}
	}

	@AfterClass(groups = { "regression" }, description = "Logout of VCFC")
	public void logout() throws Exception {
		if (!login.logout()) {
			log.error("Logout test failed");
			throw new Exception("Logout failed");
		} else {
			log.info("Logout test succeeded");
		}
	}
}