/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/

package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.AnalyticsFlowPage;
import com.pluribus.vcf.pagefactory.LicenseTypes;
import com.pluribus.vcf.pagefactory.ManagePCAP;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.test.InitialSetup;
import org.testng.annotations.AfterClass;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import static com.pluribus.vcf.helper.AnalyticsConstants.*;

public class PcapTestSetup extends TestSetup {

	private String pncPwd = "test123";
	private String pncuName = "pn-vcf";
	private String vcfUserName = "admin";
	private VCFLoginPage login;
	private NavigationMenu menu;
	private TopologyPage topology;
	private VcfSettingsPage settings;
	private SwitchMethods[] cli;
	private PointFeaturesMethod pfm;
	private String[] switchArr;
	private String eth1Ip;
	private AnalyticsFlowPage analytic;
	private ManagePCAP managePCAP;

	private static final Logger log = Logger.getLogger(PcapTestSetup.class);

	@Parameters({ "switchNames", "fabricName", "iperfServerName", "iperfClientName" })
	@BeforeTest(alwaysRun = true)
	public boolean loadMirrorConfig(String switchNames, String fabricName, String host1, String host2)
			throws Exception {
		boolean status = true;
		log.info("Configuring fabric on switches");
		switchArr = switchNames.split(" ");

		// Initializing threads and the cli handles based on # of switches in
		// switchNames parameter
		cli = new SwitchMethods[switchArr.length];

		// Reset on all switches
		for (int i = 0; i < switchArr.length; i++) {
			cli[i] = new SwitchMethods(switchArr[i]);
			cli[i].resetSwitch();
		}

		// Fabric create and join on all switches
		cli[0].createFabric(fabricName);
		Thread.sleep(30000);
		for (int i = 1; i < switchArr.length; i++) {
			if (!cli[i].joinFabric(fabricName)) {
				log.error("Joining fabric " + fabricName + " failed on switch " + switchArr[i]);
				throw new Exception("Join fabric on " + switchArr[i] + " failed");
			}
		}

		// Host 1 config
		SwitchMethods hostCli = new SwitchMethods(host1);
		hostCli.deleteBondIf("bond0");
		hostCli.modifyInterfaceIp("p1p1", "30.1.1.10/24");
		hostCli.addStaticRouteHost("40.1.1.0/24", "30.1.1.1", "p1p1");
		hostCli.exitSession();

		// Host 2 config
		hostCli = new SwitchMethods(host2);
		hostCli.deleteBondIf("bond0");
		hostCli.modifyInterfaceIp("p1p1", "40.1.1.10/24");
		hostCli.addStaticRouteHost("30.1.1.0/24", "40.1.1.1", "p1p1");
		hostCli.exitSession();

		status &= cli[1].enableWeb();
		status &= cli[1].vrouterCreate(fabricName);
		status &= cli[1].vrouterIfCreate("40.1.1.1/24", 5);
		status &= cli[1].vrouterIfCreate("10.1.1.1/24", 49);
		status &= cli[1].addStaticRoute(fabricName, "30.1.1.0/24", "10.1.1.2");
		cli[1].exitSession();
		if (status == false) {
			log.error("Switch configuration on " + switchArr[1] + " failed");
			throw new Exception("Switch configuration on" + switchArr[1] + " failed");
		}

		status &= cli[0].vrouterCreate(fabricName);
		status &= cli[0].vrouterIfCreate("30.1.1.1/24", 1);
		status &= cli[0].vrouterIfCreate("10.1.1.2/24", 49);
		status &= cli[0].vrouterIfCreate("20.1.1.1/24", 57);
		status &= cli[0].addStaticRoute(fabricName, "40.1.1.0/24", "10.1.1.1");
		cli[0].restartTomcat();
		cli[0].exitSession();

		if (status == false) {
			log.error("Switch configuration on " + switchArr[0] + " failed");
			throw new Exception("Switch configuration on" + switchArr[0] + " failed");
		}

		status &= cli[2].vrouterCreate(fabricName);
		status &= cli[2].vrouterIfCreate("20.1.1.2/24", 49);
		cli[2].exitSession();
		if (status == false) {
			log.error("Switch configuration on " + switchArr[2] + " failed");
			throw new Exception("Switch configuration on" + switchArr[2] + " failed");
		}

		return status;
	}

	public boolean loadRspanConfig(String switchNames, String fabricName) throws Exception {
		boolean status = true;
		switchArr = switchNames.split(" ");

		cli = new SwitchMethods[switchArr.length];

		// Get switch handles
		for (int i = 0; i < switchArr.length; i++) {
			cli[i] = new SwitchMethods(switchArr[i]);
		}

		// status &= cli[0].vlanCreate(20);
		status &= cli[0].vrouterIfDelete(fabricName, 57);
		status &= cli[0].vrouterIfCreate("20.1.1.1/24", 57, 20);
		cli[0].exitSession();
		if (status == false) {
			log.error("Switch configuration on " + switchArr[0] + " failed");
			throw new Exception("Switch configuration on" + switchArr[0] + " failed");
		}

		status = true;
		// status &= cli[2].vlanCreate(20);
		status &= cli[2].vrouterIfDelete("20.1.1.2/24", 49);
		status &= cli[2].vrouterIfCreate("20.1.1.2/24", 49, 20);
		cli[2].exitSession();
		if (status == false) {
			log.error("Switch configuration on " + switchArr[2] + " failed");
			throw new Exception("Switch configuration on" + switchArr[2] + " failed");
		}

		return status;
	}

	@BeforeClass(alwaysRun = true)
	@Parameters({ "jsonPcap", "switchUserName", "switchPassword", "password", "vcfIp", "fabricName", "mgmtIp" })
	public void init(String jsonFile, String switchUserName, String switchPassword,
			@Optional("test123") String password, String vcfIp, String fabricName, String mgmtIp) throws Exception {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		topology = new TopologyPage(getDriver());
		settings = new VcfSettingsPage(getDriver());
		analytic = new AnalyticsFlowPage(getDriver());
		managePCAP = new ManagePCAP(getDriver());
		login.firstlogin(vcfUserName, password);
		login.logout();
		// Login
		login.login(vcfUserName, password);
		// Add license
		settings.activateLicense(pncuName, pncPwd, LicenseTypes.IA_MOD_LIC);
		// Add necessary fabric
		topology.addFabric(switchArr[0], mgmtIp, switchUserName, switchPassword);
		topology.refreshPage();
		menu.gotoMenu("Overview", "Overview", "Topology");

		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		eth1Ip = getEth1IpAddr(vcfIp, "vcf", "changeme");
		pfm.setupJsonData(vcfIp, fabricName, eth1Ip);
	}

	// Port mirroring testcase
	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createLocalPcap" }, description = "Create port mirror")
	public void createMirror(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_mirror_port", "Mirror", switchUser, switchPwd)) {
			throw new Exception("Create Mirror test failed");
		} else {
			log.info("Create mirror test passed");
		}
	}

	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, priority = 1, description = "Create local pcap")
	public void createLocalPcap(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_local_pcap", "Pcap", switchUser, switchPwd)) {
			throw new Exception("Create local pcap test failed");
		} else {
			log.info("Create local pcap test passed");
		}
	}

	@Parameters({ "switchNames", "customTagFileValid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createLocalPcap" }, description = "Upload the valid CSV file")
	public void verifyCustomizationOfValidCSVFile(String switchNames, String customTagFileValid) throws Exception {

		log.info("uploading the valid CSV file and customizing the dashboard");
		if (menu.gotoMenu("Analytics", "Insight Analytics Packet", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileValid, CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME_PCAP)) {
				log.error("Custom Tag File is not uploaded sucessfully");
				throw new Exception("Custom Tag File is not uploaded and sucessfully");
			} else {
				log.info("Custom Tag File is uploaded and dashboard customized sucessfully");
			}
		}
	}

	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyCustomizationOfValidCSVFile" }, description = "upload pcap file")
	public void uploadPCAPFile(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "upload_PCAP_File", "Pcap", switchUser, switchPwd)) {
			log.error("Upload pcap file test failed");
			throw new Exception("Upload pcap file test failed");

		} else {
			log.info("Upload pcap file test passed");
		}
	}

	@Parameters({ "PCAP_Http", "prtocolType" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"uploadPCAPFile" }, description = "Verify PacketCount")
	public void verifyPacketCount(String PCAP_Http) throws Exception {
		if (menu.gotoMenu("Manage", "Security/Monitoring", "Manage PCAP")) {
			log.info("Verifying PacketCount");
			if (!managePCAP.waitForPacketCount(PCAP_Http)) {
				log.error("PackageCount verification failed");
				throw new Exception("PackageCount verification test failed");

			} else {
				log.info("PackageCount verification test passed");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileValid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyPacketCount" }, description = "Validate CustomTag values in dashboard for CSV file")
	public void verifyCustomtagsValueofValidCSVFile(String switchNames, String customTagFileValid) throws Exception {
		if (menu.gotoMenu("Analytics", "Insight Analytics Packet", "Custom Tags")) {
			analytic.waitForAnalyticsConnectionPageLoad();
			log.info("Verifying Custom Tag for valid CSV file");
			if (!analytic.validatetheCustomizedtag(customTagFileValid)) {
				log.error("Validation of Customization tag is failed");
				throw new Exception("Validation of Customization tag is failed");
			} else {
				log.info("validation of Customization tag is sucessfull");
			}
		}
		if (!analytic.clearTag()) {
			log.error("clear tag validation is failed");
			throw new Exception("Clear tag validation is failed");
		} else {
			log.info("clear tag validation is sucessfull");
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLValid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyCustomtagsValueofValidCSVFile" }, description = "Upload the valid XML file")
	public void verifyCustomizationOfValidXMLFile(String switchNames, String customTagFileXMLValid) throws Exception {
		log.info("uploading the  valid XML file and customizing the dashboard");
		if (menu.gotoMenu("Analytics", "Insight Analytics Packet", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileXMLValid,
					CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME_PCAP)) {
				log.error("Custom Tag File is not uploaded sucessfully");
				throw new Exception("Custom Tag File is not uploaded and sucessfully");
			} else {
				log.info("Custom Tag File is uploaded and dashboard customized sucessfully");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLValid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyCustomizationOfValidXMLFile" }, description = "Validate CustomTag values in dashboard for XMLfile")
	public void verifyCustomtagsValueofValidXMLFile(String switchNames, String customTagFileXMLValid) throws Exception {
		analytic.waitForAnalyticsConnectionPageLoad();
		log.info("Verifying Custom Tag for valid XML file");

		if (!analytic.validatetheCustomizedtag(customTagFileXMLValid)) {
			log.error("Validation of Customization tag is failed");
			throw new Exception("Validation of Customization tag is failed");
		} else {
			log.info("validation of Customization tag is sucessfull");
		}
		if (!analytic.clearTag()) {
			log.error("clear tag validation is failed");
			throw new Exception("Clear tag validation is failed");
		} else {
			log.info("clear tag validation is sucessfull");
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLInvalid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyCustomtagsValueofValidXMLFile" }, description = "uploading the invalid xml file")
	public void verifyCustomizationOfInvalidXMLFile(String switchNames, String customTagFileXMLInvalid)
			throws Exception {
		log.info("uploading the invalid XML file");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileXMLInvalid,
					CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME_PCAP)) {
				log.error("File is  uploaded ");
				throw new Exception("File is  uploaded");
			} else {
				log.info("File is not uploaded");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileInvalid" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"verifyCustomizationOfInvalidXMLFile" }, description = "uploading the invalid csv file")
	public void verifyCustomizationOfInvalidCSVFile(String switchNames, String customTagFileInvalid) throws Exception {
		log.info("uploading the invalid CSV file");
		if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileInvalid, CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME_PCAP)) {
			log.error("File is  uploaded ");
			throw new Exception("File is  uploaded  ");
		} else {
			log.info("File is is not uploaded");
		}
	}

	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createMirror" }, description = "Create matching vflow filter, send traffic and validate")
	public void createVflowFilters(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vflow_filter", "Mirror", switchUser, switchPwd)) {
			throw new Exception("Create vflow Filter test failed");
		} else {
			log.info("Create vflow filter passed");
		}
	}

	// Similarly create another test for non-matching vflow filter and add traffic
	// validation
	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVflowFilters" }, description = "Create mirror with ERSPAN encap")
	public void createMirrorERSpan(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_mirror_erspan", "Mirror", switchUser, switchPwd)) {
			throw new Exception("Create & Enable mirror test failed");
		} else {
			log.info("Create mirror test passed");
		}
	}

	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createMirrorERSpan" }, description = "delete mirror wirh erspan encap")
	public void deleteMirrorERSpan(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_mirror_erspan", "Mirror", switchUser, switchPwd)) {
			throw new Exception("Disable & delete mirror test failed");
		} else {
			log.info("Disable & Delete mirror test passed");
		}
	}

	@Parameters({ "switchNames", "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteMirrorERSpan" }, description = "Create RSPAN mirror without pcap engine")
	public void createRSpanMirror(String switchNames, String fabricName, String switchUser, String switchPwd)
			throws Exception {
		if (loadRspanConfig(switchNames, fabricName)) {
			if (!pfm.executePfTests(fabricName, "create_mirror_rspan", "Mirror", switchUser, switchPwd)) {
				throw new Exception("Create rspan mirror test failed");
			} else {
				log.info("Create rspan mirror test passed");
			}
		} else {
			throw new Exception("Configuration for RSPAN test failed");
		}
	}

	@Parameters({ "fabricName", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createRSpanMirror" }, description = "Delete mirror with rspan encap")
	public void deleteRSpanMirror(String fabricName, String switchUser, String switchPwd) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_mirror_rspan", "Mirror", switchUser, switchPwd)) {
			throw new Exception("Disable & delete mirror test failed");
		} else {
			log.info("Disable & Delete mirror test passed");
		}
	}

	@Parameters({ "vcfIp", "fabricName" })
	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout(String vcfIp, String fabricName) throws InterruptedException {
		pfm.setupJsonData(vcfIp, fabricName, eth1Ip, 1);
		login.logout();
	}
}
