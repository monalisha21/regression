package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestDataParser;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.ManageCluster;
import com.pluribus.vcf.pagefactory.ManageSNMP;
import com.pluribus.vcf.pagefactory.ManageSyslog;
import com.pluribus.vcf.pagefactory.ManageVflow;
import com.pluribus.vcf.pagefactory.ManageVlag;
import com.pluribus.vcf.pagefactory.ManageVlan;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.PointFeatures;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.Trunks;
import com.pluribus.vcf.pagefactory.VCFLoginPage;

public class Security_Monitoring extends TestSetup {
	private static final Logger log = Logger.getLogger(Security_Monitoring.class);
	private VCFLoginPage login;
	private PointFeaturesMethod pfm;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String switchUser;
	private String switchPwd;
	private String eth1Ip;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "jsonSM", "switchUserName", "switchPassword", "vcfIp", "fabricName" })
	public void init(String jsonFile, String switchUserName, String switchPassword, String vcfIp, String fabricName)
			throws Exception {
		switchUser = switchUserName;
		switchPwd = switchPassword;
		login = new VCFLoginPage(getDriver());
		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		eth1Ip = getEth1IpAddr(vcfIp, "vcf", "changeme");
		pfm.setupJsonData(vcfIp, fabricName, eth1Ip);
		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create Vflow", priority = 1)
	public void createVflowWithCopytoCPU(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vflow_CopyToCPU", "vflow", switchUser, switchPwd)) {
			throw new Exception("Create vflow test_CopyToCPU failed");
		} else {
			log.info("Create vflow_CopyToCPU test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVflowWithCopytoCPU" }, description = "Fabric level v flow validation")
	public void fabricLevelVerificationOfVflow(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_vflow_Validation", "vflow", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Vflow test failed");
		} else {
			log.info("fabric Validation for Vflow test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, description = "Create Vflow", priority = 2)
	public void createVflowWithDrop(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vflow_Drop", "vflow", switchUser, switchPwd)) {
			throw new Exception("Create vflow_Drop test failed");
		} else {
			log.info("Create vflow_Drop test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"fabricLevelVerificationOfVflow" }, description = "Fabric level Vflow validation")
	public void deleteVflowCopytoCPU(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vflow_CopyToCPU", "vflow", switchUser, switchPwd)) {
			throw new Exception("Delete vflow_CopyToCPU test failed");
		} else {
			log.info("Delete vflow_CopyToCPU test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createVflowWithDrop" }, description = "Delete Vflow")
	public void deleteVflowDrop(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vflow_Drop", "vflow", switchUser, switchPwd)) {
			throw new Exception("Delete vflowDrop test failed");
		} else {
			log.info("Delete vflow_Drop test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create Syslog", priority = 3)
	public void createSyslog(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_Syslog", "Syslog", switchUser, switchPwd)) {
			throw new Exception("Create syslog test failed");
		} else {
			log.info("Create syslog test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSyslog" }, description = "Fabric level Syslog validation")
	public void fabricLevelVerificationOfSyslog(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_syslog_Validation", "syslog", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for Syslog test failed");
		} else {
			log.info("fabric Validation for Syslog test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createSyslog" }, description = "Create Syslog")
	public void generateSyslogEvents(String fabricName) throws Exception {
		if (!pfm.generateEvents(fabricName, "test_syslog_events")) {
			throw new Exception("Syslog Events test failed");
		} else {
			log.info("Syslog events test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"generateSyslogEvents" }, description = "Create Syslog Match")
	public void createSyslogMatch(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_Syslog_Matches", "Syslog", switchUser, switchPwd)) {
			throw new Exception("Create SyslogMatch test failed");
		} else {
			log.info("Create SyslogMatch test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSyslogMatch" }, description = "edit Syslog Match")
	public void editSyslogMatch(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "edit_Syslog_Matches", "Syslog", switchUser, switchPwd)) {
			throw new Exception("Edit SyslogMatch test failed");
		} else {
			log.info("Edit SyslogMatch test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"editSyslogMatch" }, description = "Fabric level syslog match validation")
	public void fabricLevelVerificationOfSyslogMatch(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_syslogMatch_Validation", "syslog", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for SyslogMatch test failed");
		} else {
			log.info("fabric Validation for SyslogMatch test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"editSyslogMatch" }, description = "Turn on Log Event")
	public void onLogEvent(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "On_Log_Events", "LogEvent", switchUser, switchPwd)) {
			throw new Exception("Turn on Log Event test failed");
		} else {
			log.info("Turn on Log Event test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "onLogEvent" }, description = "Turn off Log Event")
	public void offLogEvent(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Off_Log_Events", "LogEvent", switchUser, switchPwd)) {
			throw new Exception("Turn off Log Event test failed");
		} else {
			log.info("Turn off Log Event test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "offLogEvent" }, description = "delete Syslog Match")
	public void deleteSyslogMatch(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_Syslog_Matches", "Syslog", switchUser, switchPwd)) {
			throw new Exception("Delete SyslogMatch test failed");
		} else {
			log.info("Delete SyslogMatch test passed");
		}
	}

	@Parameters({ "fabricName" })
	// @Test(groups = { "smoke", "regression" }, dependsOnMethods = {
	// "generateSyslogEvents" }, description = "delete Syslog")
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "deleteSyslogMatch" }, description = "delete Syslog")
	public void deleteSyslog(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_Syslog", "Syslog", switchUser, switchPwd)) {
			throw new Exception("Delete Syslog test failed");
		} else {
			log.info("Delete Syslog test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create SNMP community string")
	public void createSNMPString(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_SNMP_CommunitiesString", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMP STRING test failed");
		} else {
			log.info("Create SNMP STRING test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPString" }, description = "Fabric level SNMP String validation")
	public void fabricLevelVerificationOfSNMPString(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_SNMP_CommunityString_Validation", "SNMP", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for SNMP String test failed");
		} else {
			log.info("fabric Validation for SNMP String test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPString" }, description = "Create SNMP TRAP")
	public void createSNMPTrap(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_SNMP_Trap", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMP Trap test failed");
		} else {
			log.info("Create SNMP Trap test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPTrap" }, description = "fabric level SNMP trap validation")
	public void fabricLevelVerificationOfSNMPTrap(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "Fabric_SNMP_Trap_Validation", "SNMP", switchUser, switchPwd)) {
			throw new Exception("fabric Validation for SNMP Trap test failed");
		} else {
			log.info("fabric Validation for SNMP Trap test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPTrap" }, description = "Turn on SNMP Trap")
	public void enableSNMPTrap(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "enable_SNMP_Trap", "SNMP Trap Enable/Disable", switchUser, switchPwd)) {
			throw new Exception("Turn on SNMP Trap test failed");
		} else {
			log.info("Turn on SNMP Trap test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"enableSNMPTrap" }, description = "Turn off SNMP Trap")
	public void disableSNMPTrap(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "disable_SNMP_Trap", "SNMP Trap Enable/Disable", switchUser, switchPwd)) {
			throw new Exception("Turn off SNMP Trap test failed");
		} else {
			log.info("Turn off SNMP Trap test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"disableSNMPTrap" }, description = "delete SNMP Trap")
	public void deleteSNMPTrap(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_SNMP_Trap", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete SNMP Trap test failed");
		} else {
			log.info("Delete SNMP Trap test passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteSNMPTrap" }, description = "delete SNMP community String")
	public void deleteSNMPString(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_SNMP_CommunitiesString", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete SNMP STRING test failed");
		} else {
			log.info("Delete SNMP STRING test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, description = "Create SNMP User")
	public void createSNMPUser(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_SNMP_User", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMP User failed");
		} else {
			log.info("Create SNMP User test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPUser" }, description = "Create SNMPV3 trap receiver")
	public void createSNMPV3_trap_receiver(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_SNMPV3_trap_receiver", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMPV3 trap receiver failed");
		} else {
			log.info("Create SNMPV3 trap receiver test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"createSNMPV3_trap_receiver" }, description = "delete SNMPV3 trap receiver")
	public void deleteNMPV3_trap_receiver(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_SNMPV3_trap_receiver", "SNMP", switchUser, switchPwd)) {
			throw new Exception("delete SNMPV3 trap receiver failed");
		} else {
			log.info("delete SNMPV3 trap receiver test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteNMPV3_trap_receiver" }, description = "delete SNMP User")
	public void deleteSNMPUser(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_SNMP_User", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete SNMP User test failed");
		} else {
			log.info("Delete SNMP User test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createSNMPUser" }, description = "Create VACMs")
	public void create_VACMs(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_VACM_Using_SNMP_User", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create VACMs failed");
		} else {
			log.info("Create VACMS test passed");
		}
	}

	@Parameters({ "fabricName" })

	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "create_VACMs" }, description = "delete VACMs")
	public void delete_VACMs(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_VACMs", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete VACMS failed");
		} else {
			log.info("delete VACMs test passed");
		}
	}

	@Parameters({ "vcfIp", "fabricName" })
	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout(String vcfIp, String fabricName) throws InterruptedException {
		pfm.setupJsonData(vcfIp, fabricName, eth1Ip, 1);
		login.logout();
	}
}