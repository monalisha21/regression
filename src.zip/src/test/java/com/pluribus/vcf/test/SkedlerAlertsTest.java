package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.helper.EmailHelper;
import com.pluribus.vcf.helper.PageInfra;
import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.SshClient;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.SkedlerAlertsPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;

public class SkedlerAlertsTest extends TestSetup {

	private VCFLoginPage login;
	private PageInfra pageInfra;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private NavigationMenu menu;
	private SkedlerAlertsPage skedlerAlerts;
	private EmailHelper emailHelper;
	private static boolean verifyEmailAlert;
	private String switchUser;
	private String switchPwd;
	private String eth1Ip;
	private PointFeaturesMethod pfm;
	private SshClient sshSession;
	private static final Logger log = Logger.getLogger(SkedlerAlertsTest.class);

	@BeforeClass(alwaysRun = true)
	@Parameters({ "timeZone", "supportedEmailService", "sendersEmail", "sendersEmailPwd", "webhookName", "webhookURL", "jsonSA",
			"switchUserName", "switchPassword", "vcfIp", "fabricName" })
	public void init(String timeZone, String supportedEmailService, String sendersEmail, String sendersEmailPwd, String webhookName,
			String webhookURL, String jsonFile, String switchUserName, String switchPassword, String vcfIp,
			String fabricName) throws Exception {
		login = new VCFLoginPage(getDriver());
		pageInfra = new PageInfra(getDriver());
		menu = new NavigationMenu(getDriver());
		skedlerAlerts = new SkedlerAlertsPage(getDriver());
		emailHelper = new EmailHelper();
		switchUser = switchUserName;
		switchPwd = switchPassword;
		login = new VCFLoginPage(getDriver());
		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		eth1Ip = getEth1IpAddr(vcfIp, "vcf", "changeme");
		pfm.setupJsonData(vcfIp, fabricName, eth1Ip);
		loginTest123();
		// Create SNMP community string
		if (!pfm.executePfTests(fabricName, "create_SNMP_CommunitiesString", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMP STRING test failed");
		} else {
			log.info("Create SNMP STRING test passed");
		}
		// Create SNMP TRAP
		if (!pfm.executePfTests(fabricName, "create_SNMP_Trap", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Create SNMP Trap test failed");
		} else {
			log.info("Create SNMP Trap test passed");
		}
		// Turn on SNMP Trap
		if (!pfm.executePfTests(fabricName, "enable_SNMP_Trap", "SNMP Trap Enable/Disable", switchUser, switchPwd)) {
			throw new Exception("Turn on SNMP Trap test failed");
		} else {
			log.info("Turn on SNMP Trap test passed");
		}
		menu.gotoNotifications("alerts");
		if (skedlerAlerts.addTimeZone(timeZone)) {
		} else {
			log.error("Time Zone was not added successfully");
			throw new Exception("Time Zone was not added successfully");
		}
		if (skedlerAlerts.addEmailNotification(supportedEmailService, sendersEmail, sendersEmailPwd)) {
		} else {
			log.error("Email Notification was not configured successfully");
			throw new Exception("Email Notification was not configured successfully");
		}
		if (skedlerAlerts.addWebHook(webhookName, webhookURL)) {
		} else {
			log.error("Webhook was not added successfully");
			throw new Exception("Webhook was not added successfully");
		}
	}

	public void loginTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "connectionPattern", "alertName", "connectionscheduleIndexType", "connectionscheduleTimeField",
			"scheduleDateField", "receiverEmail", "receiverEmailPwd", "allConnectionsQueryField",
			"allConnectionsQueryType", "allConnectionsQueryCondition", "allConnectionsQueryValue" })
	@Test(groups = { "smoke", "regression" }, description = "all-connections", priority = 1)
	public void createAlertforAllconnecions(String indexPattern, String alertName, String scheduleIndexType,
			String scheduleTimeField, String scheduleDateField, String receiverEmail, String receiverEmailPwd,
			String allConnectionsQueryField, String allConnectionsQueryType, String allConnectionsQueryCondition,
			String allConnectionsQueryValue) throws Exception {
		if (skedlerAlerts.addIndexPattern(indexPattern)) {
		} else {
			log.error("Index Pattern was not added successfully");
			throw new Exception("Index Pattern was not added successfully");
		}
		if (skedlerAlerts.addScheduleAlert(alertName, indexPattern, scheduleIndexType, scheduleTimeField,
				scheduleDateField, receiverEmail, allConnectionsQueryField, allConnectionsQueryType,
				allConnectionsQueryCondition, allConnectionsQueryValue)) {
		} else {
			log.error("Schedule Alert was not added successfully");
			throw new Exception("Schedule Alert was not added successfully");
		}
		verifyEmailAlert = emailHelper.verifyEmailAlert(receiverEmail, receiverEmailPwd, scheduleDateField, alertName,
				indexPattern);
		if (skedlerAlerts.scheduleDeleteAlert()) {
			Assert.assertEquals(verifyEmailAlert, true, "Email Alert was not generated successfuly");
		} else {
			log.error("Schedule Alert was not deleted successfully");
			throw new Exception("Schedule Alert was not deleted successfully");
		}
	}

	@Parameters({ "portstatsPattern", "alertName", "portstatsscheduleIndexType", "portstatsscheduleTimeField",
			"scheduleDateField", "receiverEmail", "receiverEmailPwd", "allPortStatsQueryField", "allPortStatsQueryType",
			"allPortStatsQueryCondition", "allPortStatsQueryValue" })
	@Test(groups = { "smoke", "regression" }, description = "all-portstatss", priority = 2)
	public void createAlertforAllPortstatss(String indexPattern, String alertName, String scheduleIndexType,
			String scheduleTimeField, String scheduleDateField, String receiverEmail, String receiverEmailPwd,
			String allPortStatsQueryField, String allPortStatsQueryType, String allPortStatsQueryCondition,
			String allPortStatsQueryValue) throws Exception {
		if (skedlerAlerts.addIndexPattern(indexPattern)) {
		} else {
			log.error("Index Pattern was not added successfully");
			throw new Exception("Index Pattern was not added successfully");
		}
		if (skedlerAlerts.addScheduleAlert(alertName, indexPattern, scheduleIndexType, scheduleTimeField,
				scheduleDateField, receiverEmail, allPortStatsQueryField, allPortStatsQueryType,
				allPortStatsQueryCondition, allPortStatsQueryValue)) {
		} else {
			log.error("Schedule Alert was not added successfully");
			throw new Exception("Schedule Alert was not added successfully");
		}
		verifyEmailAlert = emailHelper.verifyEmailAlert(receiverEmail, receiverEmailPwd, scheduleDateField, alertName,
				indexPattern);
		if (skedlerAlerts.scheduleDeleteAlert()) {
			Assert.assertEquals(verifyEmailAlert, true, "Email Alert was not generated successfuly");
		} else {
			log.error("Schedule Alert was not deleted successfully");
			throw new Exception("Schedule Alert was not deleted successfully");
		}
	}

	@Parameters({ "snmpPattern", "alertName", "snmpscheduleIndexType", "snmpscheduleTimeField", "scheduleDateField",
			"receiverEmail", "receiverEmailPwd", "snmpQueryField", "snmpQueryType", "snmpQueryCondition",
			"snmpQueryValue", "mgmtIp" })
	@Test(groups = { "smoke", "regression" }, description = "all-portstatss", priority = 3)
	public void createAlertforAllSNMP(String indexPattern, String alertName, String scheduleIndexType,
			String scheduleTimeField, String scheduleDateField, String receiverEmail, String receiverEmailPwd,
			String snmpQueryField, String snmpQueryType, String snmpQueryCondition, String snmpQueryValue,
			String mgmtIp) throws Exception {
		if (skedlerAlerts.addIndexPattern(indexPattern)) {
		} else {
			log.error("Index Pattern was not added successfully");
			throw new Exception("Index Pattern was not added successfully");
		}
		if (skedlerAlerts.addScheduleAlert(alertName, indexPattern, scheduleIndexType, scheduleTimeField,
				scheduleDateField, receiverEmail, snmpQueryField, snmpQueryType, snmpQueryCondition, snmpQueryValue)) {
		} else {
			log.error("Schedule Alert was not added successfully");
			throw new Exception("Schedule Alert was not added successfully");
		}
		// Code to login switch with wrong credentials
		sshSession = new SshClient();
		try {
			sshSession.establishConnection(mgmtIp, switchUser, switchPwd.substring(1, 4));
		} catch (Exception e) {
			log.info("Invalid attempt on switch");
		}
		// Waiting to generate data for invalid login attempt on SNMP dashboard
		Thread.sleep(Integer.parseInt(scheduleDateField) * 60 * 1000);
		clickOnBody();
		verifyEmailAlert = emailHelper.verifyEmailAlert(receiverEmail, receiverEmailPwd, scheduleDateField, alertName,
				indexPattern);
		if (skedlerAlerts.scheduleDeleteAlert()) {
			Assert.assertEquals(verifyEmailAlert, true, "Email Alert was not generated successfuly");
		} else {
			log.error("Schedule Alert was not deleted successfully");
			throw new Exception("Schedule Alert was not deleted successfully");
		}
	}

	@Parameters({ "fabricName" })
	@AfterClass(alwaysRun = true, groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout(String fabricName) throws Exception {
		pageInfra.switchToParent();
		// Turn off SNMP Trap
		if (!pfm.executePfTests(fabricName, "disable_SNMP_Trap", "SNMP Trap Enable/Disable", switchUser, switchPwd)) {
			throw new Exception("Turn off SNMP Trap test failed");
		} else {
			log.info("Turn off SNMP Trap test passed");
		}
		// delete SNMP Trap
		if (!pfm.executePfTests(fabricName, "delete_SNMP_Trap", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete SNMP Trap test failed");
		} else {
			log.info("Delete SNMP Trap test passed");
		}
		// delete SNMP community String
		if (!pfm.executePfTests(fabricName, "delete_SNMP_CommunitiesString", "SNMP", switchUser, switchPwd)) {
			throw new Exception("Delete SNMP STRING test failed");
		} else {
			log.info("Delete SNMP STRING test passed");
		}
		if (!login.logout()) {
			log.error("Logout test failed");
			throw new Exception("Logout failed");
		} else {
			log.info("Logout test succeeded");
		}
	}
}
