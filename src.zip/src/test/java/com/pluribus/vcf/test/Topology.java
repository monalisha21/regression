package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.helper.JsonHelper;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;

public class Topology extends TestSetup {
	private TopologyPage topology;
	private JsonHelper jsonHelper;
	private VCFLoginPage login;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String[] switchArr;
	private String switchName;
	private static String getFabricDetails = "/vRest/fabric-nodes";
	private static String getHardwareDetails = "/vRest/switch-info";
	private static String getSoftwareDetails = "/vRest/software";
	private static String getLicenseDetails = "/vRest/software-licenses";
	private static String getTransceiversDetails = "/vRest/port-xcvrs";
	private static final Logger log = Logger.getLogger(Topology.class);

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		login = new VCFLoginPage(getDriver());
		topology = new TopologyPage(getDriver());
		jsonHelper = new JsonHelper();
		loginTest123();
	}

	public void loginTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "switchNames", "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Fabric details match with Rest Output", priority = 1)
	public void verifyFabricDetails(String switchNames, String mgmtIp, String switchUserName, String switchPwd)
			throws Exception {
		switchArr = switchNames.split(" ");
		switchName = switchArr[0];
		// topology.addFabric(switchName, mgmtIp, switchUserName, vcfPassword);
		if (topology.verifyFabric(mgmtIp, getFabricDetails, switchUserName, switchPwd)) {
			log.info("Successfully verified Fabric details from switch : " + switchName);
		} else {
			log.error("Fabric Details verification from Rest failed to match with UI from switch : " + switchName);
			throw new Exception(
					"Fabric Details verification from Rest failed to match with UI from switch : " + switchName);
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Switch details match with Rest Output", priority = 2)
	public void verifySwitchDetails(String mgmtIp, String switchUserName, String switchPwd) throws Exception {
		if (topology.verifySwitch(mgmtIp, getFabricDetails, switchUserName, switchPwd)) {
			log.info("Successfully verified Switch details from switch : " + switchName);
		} else {
			log.error("Switch Details verification from Rest failed to match with UI from switch : " + switchName);
			throw new Exception(
					"Switch Details verification from Rest failed to match with UI from switch : " + switchName);
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Hardware details match with Rest output for all switches from host file", priority = 3)
	public void verifySwitchHardwareTabDetails(String mgmtIp, String switchUserName, String switchPwd)
			throws Exception {
		JSONArray jsonArrayFromUI = topology.getJsonForHwSwGenTabs(switchName, getHardwareDetails);
		JSONArray jsonArrayFromSwitch = topology.getJsonFromSwitch(mgmtIp, getHardwareDetails, switchUserName,
				switchPwd);
		if (!jsonArrayFromSwitch.getJSONObject(0).has("message")) {
			if (jsonHelper.assertTwoJsons(jsonArrayFromUI, jsonArrayFromSwitch)) {
				log.info("Successfully verified Hardware details from switch : " + switchName);
			} else {
				log.error(
						"Hardware Details verification from Rest failed to match with UI from switch : " + switchName);
				throw new Exception(
						"Hardware Details verification from Rest failed to match with UI from switch : " + switchName);
			}
		} else {
			log.error("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Software details match with Rest output for all switches from host file", priority = 4)
	public void verifySwitchSoftwareTabDetails(String mgmtIp, String switchUserName, String switchPwd)
			throws Exception {
		JSONArray jsonArrayFromUI = topology.getJsonForHwSwGenTabs(switchName, getSoftwareDetails);
		JSONArray jsonArrayFromSwitch = topology.getJsonFromSwitch(mgmtIp, getSoftwareDetails, switchUserName,
				switchPwd);
		if (!jsonArrayFromSwitch.getJSONObject(0).has("message")) {
			if (jsonHelper.assertTwoJsons(jsonArrayFromUI, jsonArrayFromSwitch)) {
				log.info("Successfully verified Software details from switch : " + switchName);
			} else {
				log.error(
						"Software Details verification from Rest failed to match with UI from switch : " + switchName);
				throw new Exception(
						"Software Details verification from Rest failed to match with UI from switch : " + switchName);
			}
		} else {
			log.error("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify License details match with Rest output for all switches from host file", priority = 5)
	public void verifySwitchLicenseTabDetails(String mgmtIp, String switchUserName, String switchPwd) throws Exception {
		JSONArray jsonArrayFromUI = topology.getJsonForLicTransTabs(switchName, getLicenseDetails);
		JSONArray jsonArrayFromSwitch = topology.getJsonFromSwitch(mgmtIp, getLicenseDetails, switchUserName,
				switchPwd);
		if (!jsonArrayFromSwitch.getJSONObject(0).has("message")) {
			if (jsonHelper.assertTwoJsons(jsonArrayFromUI, jsonArrayFromSwitch)) {
				log.info("Successfully verified License details from switch : " + switchName);
			} else {
				log.error("License Details verification from Rest failed to match with UI from switch : " + switchName);
				throw new Exception(
						"License Details verification from Rest failed to match with UI from switch : " + switchName);
			}
		} else {
			log.error("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Transceivers details match with Rest output for all switches from host file", priority = 6)
	public void verifySwitchTransceiversTabDetails(String mgmtIp, String switchUserName, String switchPwd)
			throws Exception {
		JSONArray jsonArrayFromUI = topology.getJsonForLicTransTabs(switchName, getTransceiversDetails);
		JSONArray jsonArrayFromSwitch = topology.getJsonFromSwitch(mgmtIp, getTransceiversDetails, switchUserName,
				switchPwd);
		if (!jsonArrayFromSwitch.getJSONObject(0).has("message")) {
			if (jsonHelper.assertTwoJsons(jsonArrayFromUI, jsonArrayFromSwitch)) {
				log.info("Successfully verified Transceivers details from switch : " + switchName);
			} else {
				log.error("Transceivers Details verification from Rest failed to match with UI from switch : "
						+ switchName);
				throw new Exception("Transceivers Details verification from Rest failed to match with UI from switch : "
						+ switchName);
			}
		} else {
			log.error("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
		}
	}

	@Parameters({ "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke",
			"regression" }, description = "Verify Genral details match with Rest output for all switches from host file", priority = 7)
	public void verifySwitchGenralTabDetails(String mgmtIp, String switchUserName, String switchPwd) throws Exception {
		String oneSwitchURI = "?name=" + switchName;
		JSONArray jsonArrayFromUI = topology.getJsonForHwSwGenTabs(switchName, getFabricDetails);
		JSONArray jsonArrayFromSwitch = topology.getJsonFromSwitch(mgmtIp, getFabricDetails + oneSwitchURI,
				switchUserName, switchPwd);
		if (!jsonArrayFromSwitch.getJSONObject(0).has("message")) {
			if (jsonHelper.assertTwoJsons(jsonArrayFromUI, jsonArrayFromSwitch)) {
				log.info("Successfully verified Genral details from switch : " + switchName);
			} else {
				log.error("Genral Details verification from Rest failed to match with UI from switch : " + switchName);
				throw new Exception(
						"Genral Details verification from Rest failed to match with UI from switch : " + switchName);
			}
		} else {
			log.error("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
			throw new Exception("HTTP Response failed for switch " + switchName + " with message : "
					+ jsonArrayFromSwitch.getJSONObject(0).get("message"));
		}
	}

	@Parameters({ "switchNames", "mgmtIp", "switchUserName", "switchPassword" })
	@Test(groups = { "smoke", "regression" }, description = "Verify Discovery Status", priority = 8)
	public void verifyDiscoveryStatus(String switchNames, String mgmtIp, String switchUserName, String switchPwd)
			throws Exception {
		if (topology.verifyDiscoveryStatus()) {
			log.info("Successfully verified Discovery Status");
		} else {
			log.error("Discovery status verification failed");
			throw new Exception("Discovery status verification failed");
		}
	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout() throws Exception {
		if (!login.logout()) {
			log.error("Logout test failed");
			throw new Exception("Logout failed");
		} else {
			log.info("Logout test succeeded");
		}
	}
}
