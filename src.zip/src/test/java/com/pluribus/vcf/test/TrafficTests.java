package com.pluribus.vcf.test;

import com.pluribus.vcf.helper.AnalyticsMethods;
import com.pluribus.vcf.helper.IperfSetup;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.AnalyticsFlowPage;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import static com.pluribus.vcf.helper.AnalyticsConstants.*;

public class TrafficTests extends TestSetup {
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private VCFLoginPage login;
	private NavigationMenu menu;
	private AnalyticsFlowPage analytic;
	private IperfSetup Iperf;
	private String[] switchArr;
	private static final Logger log = Logger.getLogger(TrafficTests.class);

	@BeforeClass(alwaysRun = true)
	public void init() throws Exception {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		analytic = new AnalyticsFlowPage(getDriver());
		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "iperfClientName", "iperfServerName", "trafficDestIp", "trafficNumSessions", "trafficInterval" })
	@Test(groups = { "smoke", "regression" }, priority = 0, description = "Iperf Server starts and send the traffic")
	public void serverStartsAndSendtheTraffic(String iperfClientName, String iperfServerName, String trafficDestIp,
			int trafficNumSessions, int trafficInterval) throws Exception {
		Iperf = new IperfSetup(iperfClientName, iperfServerName);
		Iperf.startServer(iperfServerName);
		log.info("connection established to" + iperfServerName);
		log.info("Connecting to Host1");
		Iperf.sendTraffic(trafficDestIp, trafficNumSessions, trafficInterval);
	}

	@Parameters({ "trafficSrcIp", "trafficDestIp", "switchNames" })
	@Test(groups = { "smoke",
			"regression" }, priority = 1, description = "Get the traffic connection count and verify it with the UI count based on SrcIp and DestIp")
	public void verifyTrafficConnectionCount(String trafficSrcIp, String trafficDestIp, String switchNames)
			throws Exception {
		switchArr = switchNames.split(" ");
		log.info("Verifying the connection count with SrcIp and DestIp.");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Connections")) {
			log.info("started");
			analytic.waitForAnalyticsConnectionPageLoad();
			log.info("page is loaded");
			String filter = "src-ip:40.1.1.10::dst-ip:30.1.1.10";
			if (analytic.trafficCountVerification(filter, switchArr[0])) {
				log.info("count matched");
			} else {
				log.error("Count does not match");
				throw new Exception("Traffic Connection count verification failed");
			}
		} else {
			log.error("Page not found");
		}
	}

	@Parameters({ "trafficSrcIp", "trafficDestIp", "switchNames" })
	@Test(groups = { "smoke",
			"regression" }, priority = 2, description = "Get the traffic totalBytes count and verify it with the UI Bytes count based on SrcIp and DestIp")
	public void verifyTrafficTotalBytesCount(String trafficSrcIp, String trafficDestIp, String switchNames)
			throws Exception {
		log.info("Verifying the connection count with SrcIp and DestIp.");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Traffic")) {
			analytic.waitForAnalyticsTrafficPageLoad();
			log.info("page is loaded");
			if (analytic.trafficBytesCountVerification(switchArr[0])) {
				log.info("count matched");
			} else {
				log.error("Count does not match");
				throw new Exception("Traffic total bytes count verification failed");
			}
		} else {
			log.error("Page not found");
		}
	}

	@Parameters({ "switchNames", "customTagFileValid" })
	@Test(groups = { "smoke", "regression" }, priority = 3, description = "Upload the valid CSV file")
	public void verifyCustomizationOfValidCSVFile(String switchNames, String customTagFileValid) throws Exception {

		log.info("uploading the valid CSV file and customizing the dashboard");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileValid,CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME)) {
				log.error("File is not uploaded sucessfully");
				throw new Exception("File is not uploaded and sucessfully");
			} else {
				log.info("File is uploaded and dashboard customized sucessfully");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileValid", "trafficDestIp", "trafficNumSessions", "trafficInterval" })
	@Test(groups = { "smoke",
			"regression" }, priority = 4, description = "Validate CustomTag values in dashboard for CSV file")
	public void verifyCustomtagsValueofValidCSVFile(String switchNames, String customTagFileValid, String trafficDestIp,
			int trafficNumSessions, int trafficInterval) throws Exception {
		Iperf.sendTraffic(trafficDestIp, trafficNumSessions, trafficInterval);
		analytic.waitForAnalyticsConnectionPageLoad();
		log.info("Verifying Custom Tag for valid CSV file");
		if (!analytic.validatetheCustomizedtag(customTagFileValid)) {
			log.error("Validation of Customization tag is failed");
			throw new Exception("Validation of Customization tag is failed");
		} else {
			log.info("validation of Customization tag is sucessfull");
		}
		if (!analytic.clearTag()) {
			log.error("clear tag validation is failed");
			throw new Exception("Clear tag validation is failed");
		} else {
			log.info("clear tag validation is sucessfull");
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLValid" })
	@Test(groups = { "smoke", "regression" }, priority = 5, description = "Upload the valid XML file")
	public void verifyCustomizationOfValidXMLFile(String switchNames, String customTagFileXMLValid) throws Exception {
		log.info("uploading the  valid XML file and customizing the dashboard");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileXMLValid,CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME)) {
				log.error("File is not uploaded sucessfully");
				throw new Exception("File is not uploaded and sucessfully");
			} else {
				log.info("File is uploaded and dashboard customized sucessfully");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLValid", "trafficDestIp", "trafficNumSessions", "trafficInterval" })
	@Test(groups = { "smoke",
			"regression" }, priority = 6, description = "Validate CustomTag values in dashboard for XMLfile")
	public void verifyCustomtagsValueofValidXMLFile(String switchNames, String customTagFileXMLValid,
			String trafficDestIp, int trafficNumSessions, int trafficInterval) throws Exception {
		Iperf.sendTraffic(trafficDestIp, trafficNumSessions, trafficInterval);
		analytic.waitForAnalyticsConnectionPageLoad();
		log.info("Verifying Custom Tag for valid XML file");

		if (!analytic.validatetheCustomizedtag(customTagFileXMLValid)) {
			log.error("Validation of Customization tag is failed");
			throw new Exception("Validation of Customization tag is failed");
		} else {
			log.info("validation of Customization tag is sucessfull");
		}
		if (!analytic.clearTag()) {
			log.error("clear tag validation is failed");
			throw new Exception("Clear tag validation is failed");
		} else {
			log.info("clear tag validation is sucessfull");
		}
	}

	@Parameters({ "switchNames", "customTagFileXMLInvalid" })
	@Test(groups = { "smoke", "regression" }, priority = 7, description = "uploading the invalid xml file")
	public void verifyCustomizationOfInvalidXMLFile(String switchNames, String customTagFileXMLInvalid)
			throws Exception {
		log.info("uploading the invalid XML file");
		if (menu.gotoMenu("Analytics", "Insight Analytics Flow", "Custom Tags")) {
			if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileXMLInvalid,CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME)) {
				log.error("File is  uploaded ");
				throw new Exception("File is  uploaded");
			} else {
				log.info("File is not uploaded");
			}
		}
	}

	@Parameters({ "switchNames", "customTagFileInvalid" })
	@Test(groups = { "smoke", "regression" }, priority = 8, description = "uploading the invalid csv file")
	public void verifyCustomizationOfInvalidCSVFile(String switchNames, String customTagFileInvalid) throws Exception {
		log.info("uploading the invalid CSV file");
		if (!analytic.uploadAndCustomizeCustomTagFile(customTagFileInvalid,CUSTOM_TAGS_CUSTOMIZE_FIELD_NAME)) {
			log.error("File is  uploaded ");
			throw new Exception("File is  uploaded  ");
		} else {
			log.info("File is is not uploaded");
		}
	}
}