package com.pluribus.vcf.test;

import java.io.File;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.adminSettings.ManageUnumSetUp;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import static com.pluribus.vcf.adminSettings.UNUMSetUP.*;

public class UnumSetUpTest extends TestSetup {
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private ManageUnumSetUp unumSetup;
	private VCFLoginPage login;
	public String eth1Ip;
	private static final Logger log = Logger.getLogger(UnumSetUpTest.class);

	@Parameters({ "vcfIp", "imageNameUpgrade", "imageUrl", "configFile" })
	@BeforeClass(alwaysRun = true)
	public void init(String vcfIp, String imageNameUpgrade, String imageUrl, String configFile) throws Exception {

		login = new VCFLoginPage(getDriver());
		unumSetup = new ManageUnumSetUp(getDriver(), vcfIp, imageNameUpgrade, imageUrl, configFile);
		loginAsTest123();

	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 0, description = "UNUM Status check")
	public void verifyUnumVersionCheck(String vcfIp) throws Exception {
		log.info("version Id and machine Id match test Started");
		if (!unumSetup.verifyUNUMSetUpOption(versionCheck)) {
			throw new Exception("Machine id and version validation failed");
		} else {
			log.info("Machine id and version validation sucessfull");

		}
		log.info("version Id and machine Id match test End");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 1, description = "UNUM Status check")
	public void verifyUnumStatusCheck(String vcfIp) throws Exception {
		log.info("UNUM Status check test started");
		if (!unumSetup.verifyUNUMSetUpOption(statusCheck)) {
			throw new Exception("UNUM Status Check validation failed");
		} else {
			log.info("UNUM Status Check validation is sucessfull Expected value is all pass and we got that");

		}
		log.info("UNUM Status check test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 2, description = "stop UNUM")
	public void verifyUnumStopCheck(String vcfIp) throws Exception {
		log.info("UNUM Stop Test started");
		if (!unumSetup.verifyUNUMSetUpOption(stopUnum)) {
			throw new Exception("UNUM stop Check failed");
		} else {
			log.info("UNUM stop Check  is sucessfull expected is all services should be Stopped");
		}
		log.info("UNUM Stop Test Ended");
	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 3, description = "start UNUM")
	public void verifyUnumStartCheck(String vcfIp) throws Exception {
		log.info("UNUM start option check is started");
		if (!unumSetup.verifyUNUMSetUpOption(startUnum)) {
			throw new Exception("UNUM start Check  failed");
		} else {
			log.info("UNUM start Check  is sucessfull Expected is all the services should be started");
		}
		log.info("UNUM start option check is Ended ");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 4, description = "Tech support Check")
	public void verifyUnumTechSupportCheck(String vcfIp) throws Exception {
		log.info("UNUM TechSupport option check is statred");
		if (!unumSetup.verifyUNUMSetUpOption(techSup)) {
			throw new Exception("UNUM TechSupport TarFile Check  failed");
		} else {
			log.info(
					"UNUM TechSupport TarFile Check is sucessfull Expected that all directories and files are present");
		}
		log.info("UNUM TechSupport option check is Ended");

	}

	@Parameters({ "vcfIp", "configFile" })
	@Test(groups = { "smoke", "regression" }, priority = 5, description = "Host Config Check")
	public void verifyUnumHostConfigCheck(String vcfIp, String configFile) throws Exception {
		log.info("UNUM HostConfig option check is statred");
		if (!unumSetup.verifyUNUMSetUpOption(configHostIp)) {
			throw new Exception("UNUM HostConfig Check  failed");
		} else {
			log.info("UNUM HostConfig Check is sucessfull Expected is eth2 has new config");
		}
		log.info("UNUM HostConfig option check is Ended");

	}

	@Parameters({ "vcfIp", "configFile" })
	@Test(groups = { "smoke", "regression" }, priority = 6, description = "Host Config Check")
	public void verifyUnumDockerConfigCheck(String vcfIp, String configFile) throws Exception {
		log.info("UNUM dockerIp option check is statred");
		if (!unumSetup.verifyUNUMSetUpOption("configVcfNetIp:configDockerIp")) {
			throw new Exception("UNUM dockerip Check  failed");
		} else {
			log.info("UNUM docker ip Check is sucessfull Expected is docker0 ip has new config");
		}
		log.info("UNUM dockerip option check is Ended");

	}

	@Parameters({ "vcfIp", "configFile" })
	@Test(groups = { "smoke", "regression" }, priority = 7, description = "Host Config Check")
	public void verifyUnumVcfNetConfigCheck(String vcfIp, String configFile) throws Exception {
		log.info("UNUM HostConfig option check is statred");
		if (!unumSetup.verifyUNUMSetUpOption("configVcfNetIp:configVcfNetIp")) {
			throw new Exception("UNUM vcfNetIp Check  failed");
		} else {
			log.info("UNUM vcfNetIp Check is sucessfull Expected is vcfNetIp has new config");
		}
		log.info("UNUM vcfNetIp option check is Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 8, description = "NTP status Check")
	public void verifyUnumNtpStatusCheck(String vcfIp) throws Exception {
		log.info("UNUM NTP Status option check is started");
		if (!unumSetup.verifyUNUMSetUpOption("configDateTime:ntpstatusCheck")) {
			throw new Exception("UNUM NTP status Check  failed");
		} else {
			log.info("UNUM Ntp Status Check is sucessfull Expectec is All Pass");
		}
		log.info("UNUM NTP Status option check is Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 9, description = "debugMode Check")
	public void verifyUnumEnableDeBugCheck(String vcfIp) throws Exception {
		log.info("Enable Debug Mode Test Started");
		if (!unumSetup.verifyUNUMSetUpOption(debugEnable)) {
			throw new Exception("UNUM Debug Mode Enable Check  failed");
		} else {
			log.info("UNUM Debug Mode Enable Check is sucessfull Expected is Debug count should not 0");
		}
		log.info("Enable Debug Mode Test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 10, description = "debugMode Check")
	public void verifyUnumDisableDeBugCheck(String vcfIp) throws Exception {
		log.info("Disable Debug Mode Test Started");
		if (!unumSetup.verifyUNUMSetUpOption(debugDisable)) {
			throw new Exception("UNUM Debug Mode Disable Check  failed");
		} else {
			log.info("UNUM Debug Mode Disable Check is sucessfull Expected is Debug count should be 0");
		}
		log.info("Disable Debug Mode Test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 11, description = "Backup creation Check")
	public void verifyUnumBackupCheck(String vcfIp) throws Exception {
		log.info("Creating Backup Test Started");
		if (!unumSetup.verifyUNUMSetUpOption("advancedSetting:backupConfig")) {
			throw new Exception("Backup creation is failed");
		} else {
			log.info("Backup Creation  is sucessfull Expected is we should get message created sucessfully");
		}
		log.info("Creating Backup Test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 12, description = "Restore backup Check")
	public void verifyUnumRestoreBackupCheck(String vcfIp) throws Exception {
		log.info("Restoring Backup Test Started");
		if (!unumSetup.verifyUNUMSetUpOption("advancedSetting:restoreConfig")) {
			throw new Exception("Backup restore is failed");
		} else {
			log.info("Backup restore is sucessfull Expected is UI validation should be sucessfull");
		}
		log.info("Restoring Backup Test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 13, description = "Delete backup Check")
	public void verifyUnumDeleteBackupCheck(String vcfIp) throws Exception {
		log.info("Delete Backup Test Started");
		if (!unumSetup.verifyUNUMSetUpOption("advancedSetting:deleteConfig")) {
			throw new Exception("Backup deletion is failed");
		} else {
			log.info("Backup deletion is sucessfull Expected is we should get  sucess message after deletion");
		}
		log.info("Delete Backup Test Ended");

	}

	@Parameters({ "vcfIp" })
	@Test(groups = { "smoke", "regression" }, priority = 14, description = "Update Check")
	public void verifyUnumUpdateCheck(String vcfIp) throws Exception {
		log.info("Update Test Started");
		if (!unumSetup.verifyUNUMSetUpOption(updateUnum)) {
			throw new Exception("UNUM Update Check  failed");
		} else {
			log.info("UNUM Updates Check is sucessfull Expected the version should change");
		}
		log.info("Update Test Ended");

	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Stopping the thread")
	public void stopTheThread() throws InterruptedException {
		unumSetup.stopThread();
	}

}