package com.pluribus.vcf.test;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pluribus.vcf.helper.PointFeaturesMethod;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.VCFLoginPage;

public class VLEPointFeatures extends TestSetup {
	com.pluribus.vcf.helper.TestDataParser parser;
	private static final Logger log = Logger.getLogger(VLEPointFeatures.class);
	private VCFLoginPage login;
	private PointFeaturesMethod pfm;
	private String vcfUserName = "admin";
	private String vcfPassword = "test123";
	private String switchUser;
	private String switchPwd;

	@BeforeClass(alwaysRun = true)
	@Parameters({ "vleJsonFile", "switchUserName", "switchPassword" })
	public void init(String jsonFile, String switchUserName, String switchPassword) throws Exception {
		switchUser = switchUserName;
		switchPwd = switchPassword;
		login = new VCFLoginPage(getDriver());
		pfm = new PointFeaturesMethod(getDriver(), jsonFile);
		pfm.setupJsonData();

		// Login to UNUM
		loginAsTest123();
	}

	public void loginAsTest123() throws Exception {
		login.login(vcfUserName, vcfPassword);
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, description = "Create vle")
	public void createVLE(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "create_vle", "vle", switchUser, switchPwd)) {
			throw new Exception("Create vle failed");
		} else {
			log.info("Create vle passed");
		}
	}

	@Parameters({ "fabricName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = { "createVLE" }, description = "Delete tunnel")
	public void deleteVLE(String fabricName) throws Exception {
		if (!pfm.executePfTests(fabricName, "delete_vle", "vle", switchUser, switchPwd)) {
			throw new Exception("delete vle failed");
		} else {
			log.info("delete vle passed");
		}
	}

	@AfterClass(groups = { "smoke", "regression" }, description = "Logout of VCFC")
	public void logout() throws InterruptedException {
		login.logout();
	}
}
