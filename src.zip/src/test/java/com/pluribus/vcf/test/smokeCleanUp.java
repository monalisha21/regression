/**
* COPYRIGHT 2012-2017 Pluribus Networks Inc.
*
* All rights reserved. This copyright notice is Copyright Management
* Information under 17 USC 1202 and is included to protect this work and
* deter copyright infringement.  Removal or alteration of this Copyright
* Management Information without the express written permission from
* Pluribus Networks Inc is prohibited, and any such unauthorized removal
* or alteration will be a violation of federal law.
*/

package com.pluribus.vcf.test;

import com.pluribus.vcf.adminSettings.ManageUnumSetUp;
import com.pluribus.vcf.helper.SwitchMethods;
import com.pluribus.vcf.helper.TestSetup;
import com.pluribus.vcf.pagefactory.LicenseTypes;
import com.pluribus.vcf.pagefactory.NavigationMenu;
import com.pluribus.vcf.pagefactory.TopologyPage;
import com.pluribus.vcf.pagefactory.VCFLoginPage;
import com.pluribus.vcf.pagefactory.ManageCollector;
import com.pluribus.vcf.pagefactory.VcfSettingsPage;
import static com.pluribus.vcf.adminSettings.UNUMSetUP.*;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;

public class smokeCleanUp extends TestSetup {

	private String pncPwd = "test123";
	private String pncuName = "pn-vcf";
	private String vcfUserName = "admin";
	private String switchUserName = "network-admin";
	private String switchPassword = "test123";
	private SwitchMethods cli1;
	private SwitchMethods cli2;
	private SwitchMethods cli3;
	private SwitchMethods cli4;
	private SwitchMethods cli5;
	private SwitchMethods cli6;
	private VCFLoginPage login;
	private VcfSettingsPage settings;
	private NavigationMenu menu;
	private ManageCollector manageCollector;
	private TopologyPage topology;
	private ManageUnumSetUp unumSetup;
	private UnumSetUpTest unum;
	private static final Logger log = Logger.getLogger(smokeCleanUp.class);

	@Parameters({ "vcfIp", "imageNameUpgrade", "imageUrl", "configResetFile" })
	@BeforeClass(alwaysRun = true)
	public void init(String vcfIp, String imageNameUpgrade, String imageUrl, String configFile) throws Exception {
		login = new VCFLoginPage(getDriver());
		menu = new NavigationMenu(getDriver());
		settings = new VcfSettingsPage(getDriver());
		manageCollector = new ManageCollector(getDriver());
		topology = new TopologyPage(getDriver());
		unumSetup = new ManageUnumSetUp(getDriver(), vcfIp, imageNameUpgrade, imageUrl, configFile);
	}

	@Parameters({ "password" })
	@BeforeClass(groups = { "smoke", "regression" }, description = "Login to VCF as test123 After Password Change")
	public void loginTest123(@Optional("test123") String password) throws Exception {
		login.login(vcfUserName, password);
	}

	@Parameters({ "mgmtIp", "CollectorName" })
	@Test(groups = { "smoke", "regression" }, description = "Edit collector and update switch information")
	public void stopCollector(String switchName, String CollectorName) throws Exception {
		try {
			log.info("Running stopCollector Test");
			// check Collector Management tab and current status of collector.
			if (menu.gotoMenu("Manage", "Fabric", "Manage Collector")) {
				manageCollector.waitForPageLoad();
				manageCollector.stopCollector(CollectorName);
				return;
			} else {
				log.info("Collector not found");
			}
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Parameters({ "mgmtIp", "CollectorName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"stopCollector" }, description = "Delete collector Test")
	public void deleteCollector(String switchName, String CollectorName) throws Exception {
		// check Collector Management tab and current status of collector.
		if (menu.gotoMenu("Manage", "Fabric", "Manage Collector")) {
			manageCollector.waitForPageLoad();
			// Delete the collector.
			manageCollector.deleteCollector(CollectorName);
		}
	}

	@Parameters({ "mgmtIp", "CollectorName" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteCollector" }, description = "Delete fabric Test")
	public void deleteFabric() throws Exception {
		if (menu.gotoMenu("Overview", "Overview", "Topology")) {
			// Delete the fabric.
			topology.deleteFabric();
		}
	}

	@Parameters({ "vcfIp", "configResetFile" })
	@Test(groups = { "smoke", "regression" }, dependsOnMethods = {
			"deleteFabric" }, description = "Host Config Reset Check")
	public void verifyUnumHostConfigResetCheck(String vcfIp, String configFile) throws Exception {
		log.info("UNUM HostConfig option check is statred");
		if (!unumSetup.verifyUNUMSetUpOption("restHostIp")) {
			throw new Exception("UNUM HostConfig Reset Check  failed");
		} else {
			log.info("UNUM HostConfig Reset Check is sucessfull Expected is eth2 has new config");
		}
		log.info("UNUM HostConfig Reset option check is Ended");

	}

	@AfterClass(groups = { "smoke,regression" }, description = "Logout of VCFC")
	public void logout() throws InterruptedException {
		login.logout();
	}
}